package com.meira.assistant.phonefinder

import android.app.NotificationManager
import android.content.Context
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

/**
 * High-Priority Phone Finder Alert for Meira Assistant.
 * Capabilities:
 * 1. Bypasses DND / Silent / Vibrate mode (when DND policy access granted).
 * 2. Overrides volume to 100% on STREAM_ALARM.
 * 3. Plays loud alarm ringtone on loop + heavy vibration pulse.
 * 4. Strobe blinks the rear camera flashlight at 120ms intervals.
 * 5. Announces Hindi + English vocal beacon: "Main yahan hoon! Aapka phone yahan hai!"
 */
class FindMyPhoneManager(private val context: Context) {

    companion object {
        private const val TAG = "MeiraFindPhone"
        var isAlertActive = false
            private set
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var alarmRingtone: Ringtone? = null
    private var isStrobeRunning = false
    private var originalVolume = 7
    private var originalRingerMode = AudioManager.RINGER_MODE_NORMAL
    private var tts: TextToSpeech? = null

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
    }

    fun triggerFindPhoneAlert() {
        if (isAlertActive) return
        isAlertActive = true
        Log.i(TAG, "FIND MY PHONE TRIGGERED: Starting sirens, max volume, vibration, and torch strobe!")

        originalVolume = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)
        originalRingerMode = audioManager.ringerMode

        try {
            if (notificationManager.isNotificationPolicyAccessGranted) {
                notificationManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
            }
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            audioManager.setStreamVolume(
                AudioManager.STREAM_ALARM,
                maxVolume,
                AudioManager.FLAG_REMOVE_SOUND_AND_VIBRATE
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not override DND completely: ${e.message}")
        }

        startLoudAlarm()
        startFlashlightStrobe()
        startVibrationBeacon()
        speakVoiceBeacon()
    }

    private fun startLoudAlarm() {
        try {
            val alarmUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

            alarmRingtone = RingtoneManager.getRingtone(context, alarmUri)?.apply {
                audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                    .build()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    isLooping = true
                }
                play()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start alarm ringtone", e)
        }
    }

    private fun startFlashlightStrobe() {
        isStrobeRunning = true
        val cameraId = getBackCameraId() ?: return

        val strobeRunnable = object : Runnable {
            private var torchState = false
            override fun run() {
                if (!isStrobeRunning) {
                    try { cameraManager.setTorchMode(cameraId, false) } catch (_: Exception) {}
                    return
                }
                try {
                    torchState = !torchState
                    cameraManager.setTorchMode(cameraId, torchState)
                } catch (e: CameraAccessException) {
                    Log.w(TAG, "Camera strobe error: ${e.message}")
                }
                mainHandler.postDelayed(this, 150L)
            }
        }
        mainHandler.post(strobeRunnable)
    }

    @Suppress("DEPRECATION")
    private fun startVibrationBeacon() {
        try {
            val pattern = longArrayOf(0, 500, 200, 500)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(VibrationEffect.createWaveform(pattern, 0))
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0))
                } else {
                    vibrator.vibrate(pattern, 0)
                }
            }
        } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun stopVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.cancel()
            } else {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                vibrator.cancel()
            }
        } catch (_: Exception) {}
    }

    private fun speakVoiceBeacon() {
        com.meira.assistant.service.MeiraWakeWordService.pauseBrieflyForExternalTts(4500L)
        mainHandler.postDelayed({
            if (isAlertActive) {
                tts?.speak(
                    "Main yahan hoon! Aapka phone yahan hai!",
                    TextToSpeech.QUEUE_FLUSH,
                    null,
                    "MeiraBeacon"
                )
            }
        }, 1200)
    }

    fun stopAlert() {
        if (!isAlertActive) return
        Log.i(TAG, "Stopping Find My Phone alert.")
        isAlertActive = false
        isStrobeRunning = false

        try {
            alarmRingtone?.stop()
            alarmRingtone = null
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping ringtone: ${e.message}")
        }

        stopVibration()

        val cameraId = getBackCameraId()
        if (cameraId != null) {
            try {
                cameraManager.setTorchMode(cameraId, false)
            } catch (_: Exception) {}
        }

        try {
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, originalVolume, 0)
            if (notificationManager.isNotificationPolicyAccessGranted) {
                audioManager.ringerMode = originalRingerMode
            }
        } catch (_: Exception) {}

        tts?.stop()
    }

    private fun getBackCameraId(): String? {
        return try {
            cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList.firstOrNull()
        } catch (e: Exception) {
            null
        }
    }
}
