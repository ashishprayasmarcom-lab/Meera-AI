package com.meira.assistant.control

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import com.jarvis.assistant.ai.JarvisCommandResult
import com.jarvis.assistant.control.SystemControlManager
import com.jarvis.assistant.security.KillSwitchManager
import com.jarvis.assistant.service.VoiceAutomationService
import com.meira.assistant.phonefinder.FindMyPhoneManager

/**
 * Unified command executor shared between MainActivity (foreground)
 * and MeiraWakeWordService (hands-free background voice listener).
 */
object MeeraCommandExecutor {

    private val mainHandler = Handler(Looper.getMainLooper())

    fun execute(
        context: Context,
        result: JarvisCommandResult,
        systemControl: SystemControlManager,
        findMyPhoneManager: FindMyPhoneManager,
        onFeedback: ((String) -> Unit)? = null
    ) {
        if (KillSwitchManager.isEmergencyKilled) {
            onFeedback?.invoke("Blocked: Kill-Switch active")
            return
        }

        val service = VoiceAutomationService.instance

        when (result.intent) {
            "FIND_MY_PHONE" -> findMyPhoneManager.triggerFindPhoneAlert()
            "STOP_ALARM" -> findMyPhoneManager.stopAlert()

            "FIX_SETTING" -> {
                val repaired = systemControl.fixBrokenSettings()
                onFeedback?.invoke("Repaired: ${repaired.joinToString(", ")}")
            }

            "APP_SETTINGS_FIX" -> {
                val appName = result.parameters?.get("appName")?.toString() ?: "Meera AI"
                systemControl.openAppSettingsFix(appName)
            }

            "OPEN_SETTINGS_SECTION" -> {
                val section = result.parameters?.get("settingsSection")?.toString() ?: "network"
                systemControl.openSettingsSection(section)
            }

            "TOGGLE_SETTING" -> {
                val setting = result.parameters?.get("setting")?.toString()
                val state = result.parameters?.get("state") as? Boolean ?: true
                when (setting) {
                    "flashlight" -> systemControl.setFlashlight(state)
                    "wifi" -> systemControl.setWifi(state)
                    "bluetooth" -> systemControl.setBluetooth(state)
                    "mobile_data" -> systemControl.openMobileDataSettings()
                    "hotspot" -> systemControl.openHotspotSettings()
                    "location" -> systemControl.openLocationSettings()
                    "airplane_mode" -> systemControl.openAirplaneModeSettings()
                    "dnd" -> systemControl.setDnd(state)
                    "auto_rotate" -> systemControl.setAutoRotate(state)
                    "battery_saver" -> systemControl.openBatterySaverSettings()
                }
            }

            "ADJUST_VOLUME" -> {
                val delta = (result.parameters?.get("delta") as? Number)?.toInt() ?: 0
                val value = (result.parameters?.get("value") as? Number)?.toInt() ?: 70
                val stream = result.parameters?.get("volumeStream")?.toString() ?: "media"
                if (delta != 0) {
                    systemControl.adjustRelativeVolume(delta, stream)
                } else {
                    systemControl.setVolume(value, stream)
                }
            }

            "ADJUST_BRIGHTNESS" -> {
                val isAuto = result.parameters?.get("auto") as? Boolean ?: false
                if (isAuto) {
                    systemControl.setBrightnessAuto()
                } else {
                    val value = (result.parameters?.get("value") as? Number)?.toInt() ?: 70
                    val ok = systemControl.setBrightness(value)
                    if (!ok) {
                        onFeedback?.invoke("Allow 'Modify System Settings' permission for brightness")
                    }
                }
            }

            "LAUNCH_APP" -> {
                val appName = result.parameters?.get("appName")?.toString() ?: result.targetApp ?: ""
                val launched = systemControl.launchApp(appName) ||
                    (service?.universalController?.launchAppByVoice(context, appName) == true)
                if (!launched) {
                    onFeedback?.invoke("App not found: $appName")
                }
            }

            "OPEN_FEED" -> {
                val appName = result.targetApp ?: "instagram"
                if (!systemControl.launchApp(appName)) {
                    service?.universalController?.launchAppByVoice(context, appName)
                }
            }

            "OPEN_PROFILE" -> {
                val handle = result.parameters?.get("profileHandle")?.toString() ?: "instagram"
                val url = if (result.targetApp == "facebook") {
                    "https://www.facebook.com/$handle"
                } else {
                    "https://www.instagram.com/$handle"
                }
                systemControl.openUrl(url)
            }

            "OPEN_CHAT" -> {
                val contact = result.parameters?.get("contact")?.toString() ?: "Friend"
                if (service != null) {
                    service.openWhatsAppChat(contact) { status ->
                        mainHandler.post { onFeedback?.invoke(status) }
                    }
                } else {
                    systemControl.openWhatsAppDirect(contact)
                }
            }

            "READ_MESSAGES" -> {
                val contact = result.parameters?.get("contact")?.toString() ?: "Friend"
                if (service != null) {
                    service.readLatestMessages(contact) { msgs ->
                        val summary = if (msgs.isEmpty()) "No recent messages found" else msgs.joinToString(" | ")
                        mainHandler.post { onFeedback?.invoke("$contact: $summary") }
                    }
                } else {
                    onFeedback?.invoke("Enable Accessibility Service to read WhatsApp messages")
                    systemControl.openWhatsAppDirect(contact)
                }
            }

            "MAKE_CALL" -> {
                val target = result.parameters?.get("contact")?.toString() ?: ""
                if (target.isNotEmpty()) {
                    val ok = systemControl.makeCall(target)
                    if (!ok) {
                        onFeedback?.invoke("Opened dialer (grant Contacts & Phone permissions for 1-tap calls)")
                    }
                }
            }

            "SET_ALARM" -> {
                val hour = (result.parameters?.get("hour") as? Number)?.toInt() ?: 6
                val minute = (result.parameters?.get("minute") as? Number)?.toInt() ?: 30
                systemControl.setAlarm(hour, minute, "Meera Voice Alarm")
            }

            "SET_REMINDER" -> {
                val title = result.parameters?.get("reminderText")?.toString() ?: "Reminder"
                systemControl.setReminder(title)
            }

            "SEARCH_IN_APP" -> {
                val query = result.parameters?.get("searchQuery")?.toString() ?: ""
                when (result.targetApp) {
                    "youtube" -> systemControl.openYouTubeSearch(query)
                    "spotify" -> systemControl.openSpotifySearch(query)
                    "facebook" -> systemControl.openUrl("https://www.facebook.com/search/top?q=${Uri.encode(query)}")
                    else -> systemControl.openWebSearch(query)
                }
            }

            "GESTURE_SWIPE" -> {
                if (service != null) {
                    val dir = result.parameters?.get("direction")?.toString() ?: "up"
                    service.swipeVertical(directionUp = dir == "up")
                } else {
                    onFeedback?.invoke("Enable Accessibility Service for hands-free swipe")
                }
            }

            "GLOBAL_ACTION" -> {
                if (service != null) {
                    when (result.parameters?.get("type")?.toString()) {
                        "back" -> service.universalController.goBack()
                        "home" -> service.universalController.goHome()
                        "screenshot" -> service.universalController.takeScreenshot()
                    }
                } else {
                    onFeedback?.invoke("Enable Accessibility Service for Back/Home/Screenshot")
                }
            }

            "SEND_MESSAGE" -> {
                val contact = result.parameters?.get("contact")?.toString() ?: "Friend"
                val msg = result.parameters?.get("messageText")?.toString() ?: "Hello"
                if (result.targetApp == "instagram" || result.targetApp == "facebook") {
                    systemControl.launchApp(result.targetApp ?: "instagram")
                    onFeedback?.invoke("${result.targetApp} opened for $contact")
                } else if (service != null) {
                    service.automateWhatsAppMessage(contact, msg) { status ->
                        mainHandler.post { onFeedback?.invoke(status) }
                    }
                } else {
                    systemControl.openWhatsAppDirect(contact, msg)
                    onFeedback?.invoke("Opened WhatsApp chat for $contact (enable Accessibility for auto-send)")
                }
            }
        }
    }
}
