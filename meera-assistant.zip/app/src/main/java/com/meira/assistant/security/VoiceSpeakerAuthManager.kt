package com.meira.assistant.security

import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.os.Build
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.R
import java.util.Locale

/**
 * Hands-Free Voice-Secured Authentication Manager for Meira.
 * - Unlocks device hands-free ONLY on VERIFIED Owner voice match.
 * - Preserves existing Face Lock & Fingerprint completely untouched.
 * - Blocks all execution and sends instant alert on UNVERIFIED / UNKNOWN voice.
 */
class VoiceSpeakerAuthManager(private val context: Context) {

    companion object {
        private const val TAG = "MeiraVoiceAuth"
        private const val ALERT_CHANNEL_ID = "meira_security_alert"
        private const val ALERT_NOTIFICATION_ID = 3009
    }

    private val keyguardManager = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
            }
        }
    }

    fun getBiometricCoexistenceStatus(): String {
        val isSecure = keyguardManager.isDeviceSecure
        val biometricReady = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bm = context.getSystemService(BiometricManager::class.java)
            bm?.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        } else {
            isSecure
        }
        return if (biometricReady || isSecure) {
            "Face Lock & Fingerprint: ACTIVE (Untouched)"
        } else {
            "Voice Lock Ready (Biometric Coexistence Safe)"
        }
    }

    fun unlockKeyguardForVerifiedVoice(activity: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                activity.setShowWhenLocked(true)
                activity.setTurnScreenOn(true)
                keyguardManager.requestDismissKeyguard(activity, null)
            } else {
                @Suppress("DEPRECATION")
                activity.window.addFlags(
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
            }
            Log.i(TAG, "VERIFIED Owner Voice -> Device unlocked hands-free (Face Lock & Fingerprint intact).")
        } catch (e: Exception) {
            Log.w(TAG, "Keyguard unlock note: ${e.message}")
        }
    }

    fun dispatchUnverifiedVoiceAlert(attemptedCommand: String) {
        val alertMessage = "अलर्ट: अनजान आवाज़ पहचानी गई। आपकी अनुमति के बिना फ़ोन अनलॉक और किसी भी कार्य को रोक दिया गया है।"
        Log.e(TAG, "SECURITY ALERT: Unverified speaker attempted '$attemptedCommand'. Action blocked!")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALERT_CHANNEL_ID,
                "Meera Security Alerts",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_meira_orb)
            .setContentTitle("Meera Security Alert: Unverified Voice")
            .setContentText(alertMessage)
            .setStyle(NotificationCompat.BigTextStyle().bigText(alertMessage))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(ALERT_NOTIFICATION_ID, notification)
        tts?.speak(alertMessage, TextToSpeech.QUEUE_FLUSH, null, "MeiraUnverifiedAlert")
    }
}
