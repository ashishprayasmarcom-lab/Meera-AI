package com.meira.assistant.service

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.ai.IntentParser
import com.jarvis.assistant.ai.JarvisCommandResult
import com.jarvis.assistant.control.SystemControlManager
import com.jarvis.assistant.overlay.JarvisOverlayManager
import com.jarvis.assistant.security.KillSwitchManager
import com.meira.assistant.control.MeeraCommandExecutor
import com.meira.assistant.phonefinder.FindMyPhoneManager
import com.meira.assistant.security.VoiceSpeakerAuthManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Always-On Hands-Free Voice Service for Meera (मीरा).
 * - Continuously listens in the background without requiring screen touch.
 * - Executes ALL voice commands (Apps, Calls, WhatsApp, Settings, Find My Phone).
 * - Pauses microphone cleanly while TTS is speaking so Meera never hears herself.
 */
class MeiraWakeWordService : Service() {

    companion object {
        private const val TAG = "MeiraWakeService"
        private const val CHANNEL_ID = "meira_wake_channel"
        private const val NOTIFICATION_ID = 2001
        const val ACTION_STOP_ALARM = "com.meira.assistant.ACTION_STOP_ALARM"
        const val ACTION_TRIGGER_FIND_PHONE = "com.meira.assistant.ACTION_TRIGGER_FIND_PHONE"
        const val ACTION_LISTEN_NOW = "com.meira.assistant.ACTION_LISTEN_NOW"
        const val ACTION_SYNC_ORB = "com.meira.assistant.ACTION_SYNC_ORB"

        @Volatile var isServiceRunning = false
            private set
        @Volatile var requireWakeWord = false
        @Volatile var isOwnerVoiceVerified = true
        @Volatile var airGapLocalOnly = true
        @Volatile var enableFloatingOrb = true
        @Volatile var isOverlayVisible = false
            private set
        @Volatile var lastHeardPhrase = ""
            private set
        @Volatile var lastExecutedSummary = "Starting hands-free mic..."
            private set
        var onLiveUpdate: (() -> Unit)? = null
        @Volatile private var activeInstance: MeiraWakeWordService? = null

        fun pauseForExternalMic() {
            activeInstance?.let { svc ->
                svc.mainHandler.post {
                    svc.isPausedExternal = true
                    svc.isListening = false
                    try { svc.speechRecognizer?.cancel() } catch (_: Exception) {}
                }
            }
        }

        fun resumeAfterExternalMic() {
            activeInstance?.let { svc ->
                svc.mainHandler.post {
                    svc.isPausedExternal = false
                    svc.scheduleRestart(450L)
                }
            }
        }

        fun syncOverlayFromSettings(context: Context) {
            if (isServiceRunning) {
                try {
                    context.startService(Intent(context, MeiraWakeWordService::class.java).apply {
                        action = ACTION_SYNC_ORB
                    })
                } catch (_: Exception) {}
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var findMyPhoneManager: FindMyPhoneManager
    private lateinit var systemControl: SystemControlManager
    private lateinit var voiceAuthManager: VoiceSpeakerAuthManager
    private lateinit var overlayManager: JarvisOverlayManager
    private val intentParser = IntentParser(airGapLocalOnly = airGapLocalOnly)

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isDestroyed = false
    private var isSpeaking = false
    private var isListening = false
    private var isPausedExternal = false
    private var lastMicCallbackAt = 0L
    private var consecutiveErrors = 0
    private var bgMicBlockedByRom = false
    private var preferOnDevice = false

    private val screenWakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (isDestroyed || isPausedExternal || KillSwitchManager.isEmergencyKilled) return
            when (intent?.action) {
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    Log.i(TAG, "Screen woke/unlocked — re-arming hands-free speech recognizer")
                    consecutiveErrors = 0
                    syncOverlayWindow()
                    mainHandler.postDelayed({ initAndStartSpeechLoop() }, 350L)
                }
            }
        }
    }

    private val restartMicRunnable = Runnable {
        startListeningOnce()
    }

    private val watchdogRunnable = object : Runnable {
        override fun run() {
            if (isDestroyed) return
            val elapsed = SystemClock.elapsedRealtime() - lastMicCallbackAt
            if (!isSpeaking && !isPausedExternal && (!isListening && elapsed > 10_000L || elapsed > 22_000L)) {
                Log.w(TAG, "Watchdog recovering background SpeechRecognizer (elapsed=${elapsed}ms)")
                isListening = false
                initAndStartSpeechLoop()
            }
            mainHandler.postDelayed(this, 10_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        isServiceRunning = true
        lastMicCallbackAt = SystemClock.elapsedRealtime()
        findMyPhoneManager = FindMyPhoneManager(this)
        systemControl = SystemControlManager(this)
        voiceAuthManager = VoiceSpeakerAuthManager(this)
        overlayManager = JarvisOverlayManager(this)
        initTts()

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Meira::ContinuousWakeWordLock"
        ).apply {
            acquire(12 * 60 * 60 * 1000L)
        }

        createNotificationChannel()
        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildForegroundNotification(), fgsType)
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed: ${e.message}")
            lastExecutedSummary = "FGS Error: ${e.message}"
        }

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(screenWakeReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(screenWakeReceiver, filter)
            }
        } catch (_: Exception) {}

        syncOverlayWindow()
        Log.i(TAG, "Meira Hands-Free Always-On Service started.")
        onLiveUpdate?.invoke()

        mainHandler.postDelayed({ initAndStartSpeechLoop() }, 250L)
        mainHandler.postDelayed(watchdogRunnable, 10_000L)
    }

    private fun syncOverlayWindow() {
        mainHandler.post {
            try {
                if (enableFloatingOrb && Settings.canDrawOverlays(this) && !KillSwitchManager.isEmergencyKilled) {
                    overlayManager.showOverlay {
                        if (bgMicBlockedByRom) {
                            // Launch translucent/quick mic trigger if OEM ROM blocks background SpeechRecognizer
                            try {
                                val micTrigger = Intent(this, MainActivity::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    putExtra("EXTRA_TRIGGER_MIC", true)
                                }
                                startActivity(micTrigger)
                            } catch (_: Exception) {}
                        } else {
                            lastExecutedSummary = "🎤 Listening now (Orb tapped)..."
                            onLiveUpdate?.invoke()
                            updateLiveNotification()
                            isPausedExternal = false
                            isSpeaking = false
                            initAndStartSpeechLoop()
                        }
                    }
                    isOverlayVisible = true
                } else {
                    overlayManager.removeOverlay()
                    isOverlayVisible = false
                }
                onLiveUpdate?.invoke()
            } catch (e: Exception) {
                Log.w(TAG, "Overlay sync skipped: ${e.message}")
            }
        }
    }

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                    }
                    override fun onDone(utteranceId: String?) {
                        isSpeaking = false
                        scheduleRestart(450L)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeaking = false
                        scheduleRestart(500L)
                    }
                })
            }
        }
    }

    private fun speakReply(text: String) {
        if (text.isBlank()) return
        try {
            isSpeaking = true
            try { speechRecognizer?.cancel() } catch (_: Exception) {}
            isListening = false
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MeeraReply_${System.currentTimeMillis()}")
            // Safety fallback in case TTS callback doesn't fire
            mainHandler.postDelayed({
                if (isSpeaking) {
                    isSpeaking = false
                    scheduleRestart(300L)
                }
            }, 5000L)
        } catch (_: Exception) {
            isSpeaking = false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> findMyPhoneManager.stopAlert()
            ACTION_TRIGGER_FIND_PHONE -> findMyPhoneManager.triggerFindPhoneAlert()
            ACTION_SYNC_ORB -> syncOverlayWindow()
            ACTION_LISTEN_NOW -> {
                isPausedExternal = false
                isSpeaking = false
                initAndStartSpeechLoop()
                return START_STICKY
            }
        }
        syncOverlayWindow()
        if (!isListening && !isSpeaking && !isDestroyed) {
            scheduleRestart(350L)
        }
        return START_STICKY
    }

    private fun updateLiveNotification() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, buildForegroundNotification())
        } catch (_: Exception) {}
    }

    private fun initAndStartSpeechLoop() {
        if (isDestroyed || isPausedExternal) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastExecutedSummary = "Mic permission missing — grant Mic access"
            onLiveUpdate?.invoke()
            updateLiveNotification()
            scheduleRestart(3000L)
            return
        }
        val canOnDevice = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        if (!SpeechRecognizer.isRecognitionAvailable(this) && !canOnDevice) {
            Log.w(TAG, "SpeechRecognizer not available on this device.")
            lastExecutedSummary = "Google Speech Service unavailable — install/enable Google App"
            onLiveUpdate?.invoke()
            updateLiveNotification()
            return
        }

        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}

        speechRecognizer = (if (preferOnDevice && canOnDevice && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    consecutiveErrors = 0
                    bgMicBlockedByRom = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                    if (lastExecutedSummary.startsWith("Starting") || lastExecutedSummary.startsWith("Mic Err")) {
                        lastExecutedSummary = "🎤 Listening hands-free (बोलें)..."
                        onLiveUpdate?.invoke()
                        updateLiveNotification()
                    }
                }
                override fun onBeginningOfSpeech() {
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListening = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onResults(results: Bundle?) {
                    isListening = false
                    consecutiveErrors = 0
                    bgMicBlockedByRom = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        .orEmpty()
                    if (matches.isNotEmpty()) {
                        handleSpokenCandidates(matches)
                    } else {
                        scheduleRestart(350L)
                    }
                }
                override fun onError(error: Int) {
                    isListening = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                    if (isPausedExternal || isSpeaking || isDestroyed) return

                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        scheduleRestart(350L)
                        return
                    }

                    consecutiveErrors++
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS || error == SpeechRecognizer.ERROR_AUDIO) {
                        bgMicBlockedByRom = consecutiveErrors >= 2
                    }
                    val errLabel = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio busy"
                        SpeechRecognizer.ERROR_CLIENT -> "Client reset"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ROM bg mic guard — tap Floating Orb"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                        SpeechRecognizer.ERROR_SERVER, 11 -> "Speech server reset"
                        else -> "Code $error"
                    }
                    lastExecutedSummary = "Mic Err ($errLabel) — retrying..."
                    onLiveUpdate?.invoke()
                    updateLiveNotification()

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                        SpeechRecognizer.isOnDeviceRecognitionAvailable(this@MeiraWakeWordService)) {
                        preferOnDevice = !preferOnDevice
                    }

                    val backoff = (1000L * consecutiveErrors.coerceAtMost(4))
                    mainHandler.removeCallbacks(restartMicRunnable)
                    mainHandler.postDelayed({ initAndStartSpeechLoop() }, backoff)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        startListeningOnce()
    }

    private fun startListeningOnce() {
        if (isDestroyed || isSpeaking || isListening || isPausedExternal) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            scheduleRestart(3000L)
            return
        }
        try {
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            }
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            Log.w(TAG, "Failed starting listener: ${e.message}")
            mainHandler.postDelayed({ initAndStartSpeechLoop() }, 1200L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || isSpeaking || isPausedExternal) return
        mainHandler.removeCallbacks(restartMicRunnable)
        mainHandler.postDelayed(restartMicRunnable, delayMs)
    }

    private fun stripWakeWord(phrase: String): String {
        return phrase
            .replace(Regex("^(hey|ok|hi|hello|अरे|हे|ओके)?\\s*(meera|meira|mira|mera|मीरा|मेरा|मिरा)(?:\\s*जी)?[,:\\s]*", RegexOption.IGNORE_CASE), "")
            .trim()
            .ifEmpty { phrase }
    }

    private fun handleSpokenCandidates(matches: List<String>) {
        val primaryPhrase = matches.first()
        lastHeardPhrase = primaryPhrase
        onLiveUpdate?.invoke()

        if (KillSwitchManager.isEmergencyKilled) {
            lastExecutedSummary = "Blocked: Kill-Switch active"
            onLiveUpdate?.invoke()
            scheduleRestart(1000L)
            return
        }

        val wakeWords = listOf("meera", "meira", "mira", "mera", "मीरा", "मेरा", "मिरा")
        val hasWakeWord = matches.any { cand ->
            val l = cand.lowercase()
            wakeWords.any { l.contains(it) }
        }
        val isUrgentFinder = matches.any { cand ->
            val l = cand.lowercase()
            l.contains("kahan ho") || l.contains("कहाँ हो") ||
                l.contains("find my phone") || l.contains("stop alarm") || l.contains("अलार्म बंद")
        }

        if (requireWakeWord && !hasWakeWord && !isUrgentFinder) {
            lastExecutedSummary = "Waiting for 'Meera' (Heard: $primaryPhrase)"
            onLiveUpdate?.invoke()
            scheduleRestart(300L)
            return
        }

        intentParser.airGapLocalOnly = airGapLocalOnly
        serviceScope.launch {
            var chosenResult: JarvisCommandResult? = null
            var chosenPhrase = primaryPhrase

            for (cand in matches) {
                val cleaned = stripWakeWord(cand)
                val res = intentParser.parseCommand(cleaned, isSpeakerVerified = isOwnerVoiceVerified)
                if (chosenResult == null) {
                    chosenResult = res
                    chosenPhrase = cand
                }
                if (res.intent != "UNKNOWN") {
                    chosenResult = res
                    chosenPhrase = cand
                    break
                }
            }

            val result = chosenResult ?: return@launch
            lastHeardPhrase = chosenPhrase

            if (result.intent == "VOICE_SECURITY_ALERT") {
                lastExecutedSummary = "UNVERIFIED VOICE BLOCKED!"
                onLiveUpdate?.invoke()
                voiceAuthManager.dispatchUnverifiedVoiceAlert(chosenPhrase)
                scheduleRestart(1800L)
                return@launch
            }

            if (result.intent == "UNKNOWN") {
                lastExecutedSummary = "Ignored non-command: $primaryPhrase"
                onLiveUpdate?.invoke()
                scheduleRestart(300L)
                return@launch
            }

            lastExecutedSummary = "${result.moduleAction} → ${result.targetPayload}"
            onLiveUpdate?.invoke()
            updateLiveNotification()

            MeeraCommandExecutor.execute(
                context = this@MeiraWakeWordService,
                result = result,
                systemControl = systemControl,
                findMyPhoneManager = findMyPhoneManager
            ) { extraMsg ->
                lastExecutedSummary = extraMsg
                onLiveUpdate?.invoke()
                updateLiveNotification()
            }

            speakReply(result.spokenFeedback)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAlarmIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MeiraWakeWordService::class.java).apply { action = ACTION_STOP_ALARM },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Meera Hands-Free Active (मीरा)")
            .setContentText(lastExecutedSummary)
            .setSmallIcon(R.drawable.ic_meira_orb)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_meira_orb, "Stop Alarm", stopAlarmIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Meera Background Listening",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Meera listening hands-free for voice commands"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        if (!KillSwitchManager.isEmergencyKilled) {
            try {
                val restartIntent = Intent(applicationContext, MeiraWakeWordService::class.java)
                val pi = PendingIntent.getForegroundService(
                    applicationContext,
                    2099,
                    restartIntent,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
                val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 800L, pi)
            } catch (e: Exception) {
                Log.w(TAG, "onTaskRemoved restart skipped: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        isDestroyed = true
        isServiceRunning = false
        isOverlayVisible = false
        activeInstance = null
        super.onDestroy()
        try { unregisterReceiver(screenWakeReceiver) } catch (_: Exception) {}
        try { overlayManager.removeOverlay() } catch (_: Exception) {}
        serviceScope.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        findMyPhoneManager.stopAlert()
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        onLiveUpdate?.invoke()
        Log.i(TAG, "Meira Wake Word Service destroyed.")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
