package com.meira.assistant.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.ai.IntentParser
import com.jarvis.assistant.control.SystemControlManager
import com.jarvis.assistant.security.KillSwitchManager
import com.meira.assistant.control.MeeraCommandExecutor
import com.meira.assistant.phonefinder.FindMyPhoneManager
import com.meira.assistant.security.VoiceSpeakerAuthManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Always-On Hands-Free Voice Service for Meera (मीरा).
 * - Continuously listens in the background without requiring screen touch.
 * - Executes ALL voice commands (Apps, Calls, WhatsApp, Settings, Find My Phone).
 * - Pauses microphone cleanly while TTS is speaking so Meera never hears herself.
 */
class MeiraWakeWordService : Service() {

    companion object {
        private const val TAG = "MeiraWakeService"
        private const val CHANNEL_ID = "meira_wake_channel"
        private const val NOTIFICATION_ID = 2001
        const val ACTION_STOP_ALARM = "com.meira.assistant.ACTION_STOP_ALARM"
        const val ACTION_TRIGGER_FIND_PHONE = "com.meira.assistant.ACTION_TRIGGER_FIND_PHONE"

        @Volatile var isServiceRunning = false
            private set
        @Volatile var requireWakeWord = false
        @Volatile var isOwnerVoiceVerified = true
        @Volatile var airGapLocalOnly = true
        @Volatile var lastHeardPhrase = ""
            private set
        @Volatile var lastExecutedSummary = "Listening hands-free..."
            private set
        var onLiveUpdate: (() -> Unit)? = null
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var findMyPhoneManager: FindMyPhoneManager
    private lateinit var systemControl: SystemControlManager
    private lateinit var voiceAuthManager: VoiceSpeakerAuthManager
    private val intentParser = IntentParser(airGapLocalOnly = airGapLocalOnly)

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isDestroyed = false
    private var isSpeaking = false
    private var isListening = false

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        findMyPhoneManager = FindMyPhoneManager(this)
        systemControl = SystemControlManager(this)
        voiceAuthManager = VoiceSpeakerAuthManager(this)
        initTts()

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Meira::ContinuousWakeWordLock"
        ).apply {
            acquire(12 * 60 * 60 * 1000L)
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        Log.i(TAG, "Meira Hands-Free Always-On Service started.")
        onLiveUpdate?.invoke()

        mainHandler.postDelayed({ initAndStartSpeechLoop() }, 350L)
    }

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        isSpeaking = true
                    }
                    override fun onDone(utteranceId: String?) {
                        isSpeaking = false
                        scheduleRestart(450L)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        isSpeaking = false
                        scheduleRestart(500L)
                    }
                })
            }
        }
    }

    private fun speakReply(text: String) {
        if (text.isBlank()) return
        try {
            isSpeaking = true
            try { speechRecognizer?.cancel() } catch (_: Exception) {}
            isListening = false
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MeeraReply_${System.currentTimeMillis()}")
            // Safety fallback in case TTS callback doesn't fire
            mainHandler.postDelayed({
                if (isSpeaking) {
                    isSpeaking = false
                    scheduleRestart(300L)
                }
            }, 5000L)
        } catch (_: Exception) {
            isSpeaking = false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> findMyPhoneManager.stopAlert()
            ACTION_TRIGGER_FIND_PHONE -> findMyPhoneManager.triggerFindPhoneAlert()
        }
        if (!isListening && !isSpeaking && !isDestroyed) {
            scheduleRestart(400L)
        }
        return START_STICKY
    }

    private fun initAndStartSpeechLoop() {
        if (isDestroyed) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastExecutedSummary = "Mic permission missing — grant Mic access"
            onLiveUpdate?.invoke()
            scheduleRestart(3000L)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "SpeechRecognizer not available on this device.")
            lastExecutedSummary = "Google Speech Service unavailable"
            onLiveUpdate?.invoke()
            return
        }

        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListening = false
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onResults(results: Bundle?) {
                    isListening = false
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val heard = matches?.firstOrNull()?.trim().orEmpty()
                    if (heard.isNotEmpty()) {
                        handleSpokenPhrase(heard)
                    } else {
                        scheduleRestart(350L)
                    }
                }
                override fun onError(error: Int) {
                    isListening = false
                    val needsRecreate = (error == SpeechRecognizer.ERROR_CLIENT ||
                        error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ||
                        error == SpeechRecognizer.ERROR_AUDIO)
                    if (needsRecreate) {
                        mainHandler.removeCallbacksAndMessages(null)
                        mainHandler.postDelayed({ initAndStartSpeechLoop() }, 1000L)
                    } else {
                        scheduleRestart(450L)
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        startListeningOnce()
    }

    private fun startListeningOnce() {
        if (isDestroyed || isSpeaking || isListening) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            scheduleRestart(3000L)
            return
        }
        try {
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            Log.w(TAG, "Failed starting listener: ${e.message}")
            mainHandler.postDelayed({ initAndStartSpeechLoop() }, 1500L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || isSpeaking) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({ startListeningOnce() }, delayMs)
    }

    private fun handleSpokenPhrase(phrase: String) {
        lastHeardPhrase = phrase
        onLiveUpdate?.invoke()

        if (KillSwitchManager.isEmergencyKilled) {
            lastExecutedSummary = "Blocked: Kill-Switch active"
            onLiveUpdate?.invoke()
            scheduleRestart(1000L)
            return
        }

        val lower = phrase.lowercase().trim()
        val hasWakeWord = listOf("meera", "meira", "mira", "mera", "मीरा", "मेरा", "मिरा")
            .any { lower.contains(it) }
        val isUrgentFinder = lower.contains("kahan ho") || lower.contains("कहाँ हो") ||
            lower.contains("find my phone") || lower.contains("stop alarm") || lower.contains("अलार्म बंद")

        if (requireWakeWord && !hasWakeWord && !isUrgentFinder) {
            lastExecutedSummary = "Waiting for 'Meera' (Heard: $phrase)"
            onLiveUpdate?.invoke()
            scheduleRestart(350L)
            return
        }

        // Strip wake-word prefix if present
        val cleanedCommand = phrase
            .replace(Regex("^(hey|ok|hi|hello|अरे|हे|ओके)?\\s*(meera|meira|mira|mera|मीरा|मेरा|मिरा)(?:\\s*जी)?[,:\\s]*", RegexOption.IGNORE_CASE), "")
            .trim()
            .ifEmpty { phrase }

        intentParser.airGapLocalOnly = airGapLocalOnly
        serviceScope.launch {
            val result = intentParser.parseCommand(cleanedCommand, isSpeakerVerified = isOwnerVoiceVerified)

            if (result.intent == "VOICE_SECURITY_ALERT") {
                lastExecutedSummary = "UNVERIFIED VOICE BLOCKED!"
                onLiveUpdate?.invoke()
                voiceAuthManager.dispatchUnverifiedVoiceAlert(cleanedCommand)
                scheduleRestart(1800L)
                return@launch
            }

            if (result.intent == "UNKNOWN") {
                // Strict NO COMMAND, NO ACTION: ignore background chatter silently
                lastExecutedSummary = "Ignored non-command: $phrase"
                onLiveUpdate?.invoke()
                scheduleRestart(350L)
                return@launch
            }

            lastExecutedSummary = "${result.moduleAction} → ${result.targetPayload}"
            onLiveUpdate?.invoke()

            MeeraCommandExecutor.execute(
                context = this@MeiraWakeWordService,
                result = result,
                systemControl = systemControl,
                findMyPhoneManager = findMyPhoneManager
            ) { extraMsg ->
                lastExecutedSummary = extraMsg
                onLiveUpdate?.invoke()
            }

            speakReply(result.spokenFeedback)
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAlarmIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MeiraWakeWordService::class.java).apply { action = ACTION_STOP_ALARM },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Meera Hands-Free Active (मीरा)")
            .setContentText("बोलें: 'YouTube खोलो', 'Wi-Fi बंद करो', 'राहुल को कॉल करो'")
            .setSmallIcon(R.drawable.ic_meira_orb)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_meira_orb, "Stop Alarm", stopAlarmIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Meera Background Listening",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Meera listening hands-free for voice commands"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        isDestroyed = true
        isServiceRunning = false
        super.onDestroy()
        serviceScope.cancel()
        mainHandler.removeCallbacksAndMessages(null)
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        findMyPhoneManager.stopAlert()
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        onLiveUpdate?.invoke()
        Log.i(TAG, "Meira Wake Word Service destroyed.")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
