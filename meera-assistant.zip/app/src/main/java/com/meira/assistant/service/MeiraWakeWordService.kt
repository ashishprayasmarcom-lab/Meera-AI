package com.meira.assistant.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.ai.IntentParser
import com.jarvis.assistant.ai.JarvisCommandResult
import com.jarvis.assistant.control.SystemControlManager
import com.jarvis.assistant.overlay.JarvisOverlayManager
import com.jarvis.assistant.security.KillSwitchManager
import com.meira.assistant.control.MeeraCommandExecutor
import com.meira.assistant.phonefinder.FindMyPhoneManager
import com.meira.assistant.security.VoiceSpeakerAuthManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sqrt

/**
 * Always-On 24x7 Foreground Voice Service for Meera (मीरा).
 * - Keeps recognition active continuously in background AND when screen is locked (SCREEN_OFF).
 * - Dual Engine: Continuous SpeechRecognizer + Silent Low-Power AudioRecord VAD monitor on lockscreen/OEM guard.
 * - Executes lock-screen-safe controls directly and unlocks Keyguard seamlessly for Verified Owner Voice.
 */
class MeiraWakeWordService : Service() {

    companion object {
        private const val TAG = "MeiraWakeService"
        private const val CHANNEL_ID = "meira_wake_channel"
        private const val NOTIFICATION_ID = 2001
        private const val PREFS_NAME = "meera_prefs"
        const val ACTION_STOP_ALARM = "com.meira.assistant.ACTION_STOP_ALARM"
        const val ACTION_TRIGGER_FIND_PHONE = "com.meira.assistant.ACTION_TRIGGER_FIND_PHONE"
        const val ACTION_LISTEN_NOW = "com.meira.assistant.ACTION_LISTEN_NOW"
        const val ACTION_SYNC_ORB = "com.meira.assistant.ACTION_SYNC_ORB"
        const val ACTION_KEEP_ALIVE = "com.meira.assistant.ACTION_KEEP_ALIVE"

        @Volatile var isServiceRunning = false
            private set
        @Volatile var requireWakeWord = true
        @Volatile var silentExecutionMode = true
        @Volatile var isOwnerVoiceVerified = true
        @Volatile var airGapLocalOnly = false
        @Volatile var enableFloatingOrb = true
        @Volatile var isOverlayVisible = false
            private set
        @Volatile var isLockScreenVadActive = false
            private set
        @Volatile var lastHeardPhrase = ""
            private set
        @Volatile var lastExecutedSummary = "Waiting for 'मीरा' wake word (Silent Mode)..."
            private set
        var onLiveUpdate: (() -> Unit)? = null
        @Volatile private var activeInstance: MeiraWakeWordService? = null

        fun loadPrefs(context: Context) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            requireWakeWord = prefs.getBoolean("require_wake_word_strict", true)
            silentExecutionMode = prefs.getBoolean("silent_execution_mode", true)
            isOwnerVoiceVerified = prefs.getBoolean("owner_voice_verified", true)
            airGapLocalOnly = prefs.getBoolean("air_gap_local", false)
            enableFloatingOrb = prefs.getBoolean("enable_floating_orb", true)
        }

        fun savePrefs(context: Context) {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putBoolean("require_wake_word_strict", requireWakeWord)
                .putBoolean("silent_execution_mode", silentExecutionMode)
                .putBoolean("owner_voice_verified", isOwnerVoiceVerified)
                .putBoolean("air_gap_local", airGapLocalOnly)
                .putBoolean("enable_floating_orb", enableFloatingOrb)
                .apply()
        }

        fun pauseForExternalMic() {
            activeInstance?.let { svc ->
                svc.mainHandler.post {
                    svc.isPausedExternal = true
                    svc.isListening = false
                    svc.stopLockScreenVadMonitor()
                    try { svc.speechRecognizer?.cancel() } catch (_: Exception) {}
                }
            }
        }

        fun resumeAfterExternalMic() {
            activeInstance?.let { svc ->
                svc.mainHandler.post {
                    svc.isPausedExternal = false
                    svc.scheduleRestart(450L)
                }
            }
        }

        fun pauseBrieflyForExternalTts(durationMs: Long = 4500L) {
            activeInstance?.let { svc ->
                svc.mainHandler.post {
                    svc.isSpeaking = true
                    svc.isListening = false
                    svc.stopLockScreenVadMonitor()
                    try { svc.speechRecognizer?.cancel() } catch (_: Exception) {}
                    svc.mainHandler.postDelayed({
                        if (!svc.isDestroyed && svc.isSpeaking) {
                            svc.isSpeaking = false
                            svc.scheduleRestart(350L)
                        }
                    }, durationMs)
                }
            }
        }

        fun syncOverlayFromSettings(context: Context) {
            savePrefs(context)
            if (isServiceRunning) {
                try {
                    context.startService(Intent(context, MeiraWakeWordService::class.java).apply {
                        action = ACTION_SYNC_ORB
                    })
                } catch (_: Exception) {}
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var powerManager: PowerManager
    private lateinit var keyguardManager: KeyguardManager
    private lateinit var audioManager: AudioManager
    private lateinit var findMyPhoneManager: FindMyPhoneManager
    private lateinit var systemControl: SystemControlManager
    private lateinit var voiceAuthManager: VoiceSpeakerAuthManager
    private lateinit var overlayManager: JarvisOverlayManager
    private val intentParser = IntentParser(airGapLocalOnly = airGapLocalOnly)

    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isDestroyed = false
    private var isSpeaking = false
    private var isListening = false
    private var isPausedExternal = false
    private var manualListenTrigger = false
    private var lastMicCallbackAt = 0L
    private var consecutiveErrors = 0
    private var bgMicBlockedByRom = false
    private var preferOnDevice = false
    private var vadJob: Job? = null
    private var vadWakeWindowUntilMs = 0L
    private var wakeSessionUntilMs = 0L
    private var pendingDisambigResult: JarvisCommandResult? = null
    private var pendingDisambigOptions: List<String> = emptyList()
    private var pendingDisambigUntilMs = 0L

    private fun isExternalMediaPlaying(): Boolean {
        return try {
            audioManager.isMusicActive
        } catch (_: Exception) {
            false
        }
    }

    private val screenWakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (isDestroyed || isPausedExternal || KillSwitchManager.isEmergencyKilled) return
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    Log.i(TAG, "Screen LOCKED/OFF — ensuring continuous lock-screen voice monitor stays active")
                    lastExecutedSummary = "🔒 Screen Locked Listener ACTIVE (बोलें)..."
                    onLiveUpdate?.invoke()
                    updateLiveNotification()
                    if (bgMicBlockedByRom) {
                        startLockScreenVadMonitor()
                    } else {
                        mainHandler.postDelayed({ initAndStartSpeechLoop() }, 300L)
                    }
                }
                Intent.ACTION_SCREEN_ON, Intent.ACTION_USER_PRESENT -> {
                    Log.i(TAG, "Screen woke/unlocked — re-arming SpeechRecognizer loop")
                    stopLockScreenVadMonitor()
                    consecutiveErrors = 0
                    syncOverlayWindow()
                    mainHandler.postDelayed({ initAndStartSpeechLoop() }, 300L)
                }
            }
        }
    }

    private val restartMicRunnable = Runnable {
        startListeningOnce()
    }

    private val watchdogRunnable = object : Runnable {
        override fun run() {
            if (isDestroyed) return
            try {
                if (wakeLock?.isHeld == false) {
                    wakeLock?.acquire(12 * 60 * 60 * 1000L)
                }
            } catch (_: Exception) {}

            val elapsed = SystemClock.elapsedRealtime() - lastMicCallbackAt
            val inVadMode = vadJob?.isActive == true
            if (!isSpeaking && !isPausedExternal && !inVadMode && (!isListening && elapsed > 8_000L || elapsed > 18_000L)) {
                Log.w(TAG, "Watchdog recovering background/lockscreen SpeechRecognizer (elapsed=${elapsed}ms)")
                isListening = false
                initAndStartSpeechLoop()
            }
            mainHandler.postDelayed(this, 8_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        activeInstance = this
        isServiceRunning = true
        loadPrefs(this)
        lastMicCallbackAt = SystemClock.elapsedRealtime()
        powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            findMyPhoneManager = FindMyPhoneManager(this)
            systemControl = SystemControlManager(this)
            voiceAuthManager = VoiceSpeakerAuthManager(this)
            overlayManager = JarvisOverlayManager(this)
            initTts()
        } catch (t: Throwable) {
            Log.e(TAG, "Non-fatal component init error: ${t.message}")
        }

        try {
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "Meira::ContinuousWakeWordLock"
            ).apply {
                setReferenceCounted(false)
                acquire(12 * 60 * 60 * 1000L)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "WakeLock skipped: ${t.message}")
        }

        createNotificationChannel()
        val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }
        var startedForeground = false
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildForegroundNotification(), fgsType)
            startedForeground = true
        } catch (t: Throwable) {
            Log.w(TAG, "Mic FGS start restricted in bg (${t.message}) — falling back to specialUse FGS")
            val fallbackType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                0
            }
            try {
                ServiceCompat.startForeground(this, NOTIFICATION_ID, buildForegroundNotification(), fallbackType)
                startedForeground = true
                lastExecutedSummary = "24x7 Standby Active (Tap Orb or open Meera to arm mic)"
            } catch (t2: Throwable) {
                Log.e(TAG, "Fallback startForeground failed safely: ${t2.message}")
                lastExecutedSummary = "FGS Error: ${t2.message}"
            }
        }

        if (!startedForeground) {
            isServiceRunning = false
            activeInstance = null
            try { wakeLock?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
            stopSelf()
            return
        }

        try {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
                addAction(Intent.ACTION_USER_PRESENT)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(screenWakeReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(screenWakeReceiver, filter)
            }
        } catch (_: Throwable) {}

        syncOverlayWindow()
        Log.i(TAG, "Meira 24x7 Lock-Screen & Background Foreground Service started.")
        onLiveUpdate?.invoke()

        mainHandler.postDelayed({ initAndStartSpeechLoop() }, 250L)
        mainHandler.postDelayed(watchdogRunnable, 8_000L)
    }

    private fun promoteMicForegroundIfPossible() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            try {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    buildForegroundNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } catch (_: Throwable) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun wakeScreenBriefly(durationMs: Long = 7000L) {
        try {
            val screenLock = powerManager.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "Meira::LockScreenCommandWake"
            )
            screenLock.acquire(durationMs)
        } catch (_: Exception) {}
    }

    @SuppressLint("MissingPermission")
    private fun startLockScreenVadMonitor() {
        if (isDestroyed || isPausedExternal || isSpeaking || KillSwitchManager.isEmergencyKilled) return
        if (isExternalMediaPlaying() && !manualListenTrigger && SystemClock.elapsedRealtime() >= wakeSessionUntilMs) {
            scheduleRestart(2500L)
            return
        }
        if (vadJob?.isActive == true) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return

        try { speechRecognizer?.cancel(); speechRecognizer?.destroy(); speechRecognizer = null } catch (_: Exception) {}
        isListening = false
        isLockScreenVadActive = true
        lastExecutedSummary = "🔒 Lock-Screen Voice Guard ACTIVE (बोलने पर तुरंत जागेगी)..."
        onLiveUpdate?.invoke()
        updateLiveNotification()

        vadJob = serviceScope.launch(Dispatchers.IO) {
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(2048)

            var recorder: AudioRecord? = null
            try {
                recorder = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf
                )
                if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                    isLockScreenVadActive = false
                    return@launch
                }
                recorder.startRecording()
                val buf = ShortArray(1024)
                var speechFrames = 0

                while (isActive && !isDestroyed && !isPausedExternal && !isSpeaking) {
                    val read = recorder.read(buf, 0, buf.size)
                    if (read > 0) {
                        var sum = 0.0
                        for (i in 0 until read) {
                            val s = buf[i].toDouble()
                            sum += s * s
                        }
                        val rms = sqrt(sum / read)
                        if (rms > 850.0) {
                            speechFrames++
                            if (speechFrames >= 3) {
                                Log.i(TAG, "Lock-Screen VAD detected voice (rms=$rms) — waking recognizer!")
                                break
                            }
                        } else {
                            speechFrames = (speechFrames - 1).coerceAtLeast(0)
                        }
                    } else {
                        delay(40)
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "VAD monitor note: ${e.message}")
            } finally {
                try { recorder?.stop() } catch (_: Exception) {}
                try { recorder?.release() } catch (_: Exception) {}
                isLockScreenVadActive = false
                if (!isDestroyed && !isPausedExternal && !isSpeaking && vadJob?.isCancelled != true) {
                    mainHandler.post {
                        vadWakeWindowUntilMs = SystemClock.elapsedRealtime() + 10_000L
                        wakeScreenBriefly(8000L)
                        consecutiveErrors = 0
                        initAndStartSpeechLoop()
                    }
                }
            }
        }
    }

    private fun stopLockScreenVadMonitor() {
        vadJob?.cancel()
        vadJob = null
        isLockScreenVadActive = false
    }

    private fun syncOverlayWindow() {
        mainHandler.post {
            try {
                if (enableFloatingOrb && Settings.canDrawOverlays(this) && !KillSwitchManager.isEmergencyKilled) {
                    overlayManager.showOverlay {
                        if (bgMicBlockedByRom) {
                            try {
                                val micTrigger = Intent(this, MainActivity::class.java).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    putExtra("EXTRA_TRIGGER_MIC", true)
                                }
                                startActivity(micTrigger)
                            } catch (_: Exception) {}
                        } else {
                            stopLockScreenVadMonitor()
                            lastExecutedSummary = "🎤 Listening now (Orb tapped)..."
                            onLiveUpdate?.invoke()
                            updateLiveNotification()
                            isPausedExternal = false
                            isSpeaking = false
                            manualListenTrigger = true
                            wakeSessionUntilMs = SystemClock.elapsedRealtime() + 8_000L
                            initAndStartSpeechLoop()
                        }
                    }
                    isOverlayVisible = true
                } else {
                    overlayManager.removeOverlay()
                    isOverlayVisible = false
                }
                onLiveUpdate?.invoke()
            } catch (e: Exception) {
                Log.w(TAG, "Overlay sync skipped: ${e.message}")
            }
        }
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("hi", "IN")
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            isSpeaking = true
                        }
                        override fun onDone(utteranceId: String?) {
                            isSpeaking = false
                            scheduleRestart(450L)
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            isSpeaking = false
                            scheduleRestart(500L)
                        }
                    })
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "TTS init skipped: ${t.message}")
        }
    }

    private fun speakReply(text: String) {
        if (text.isBlank()) return
        try {
            isSpeaking = true
            stopLockScreenVadMonitor()
            try { speechRecognizer?.cancel() } catch (_: Exception) {}
            isListening = false
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "MeeraReply_${System.currentTimeMillis()}")
            mainHandler.postDelayed({
                if (isSpeaking) {
                    isSpeaking = false
                    scheduleRestart(300L)
                }
            }, 4500L)
        } catch (_: Exception) {
            isSpeaking = false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                ACTION_STOP_ALARM -> findMyPhoneManager.stopAlert()
                ACTION_TRIGGER_FIND_PHONE -> findMyPhoneManager.triggerFindPhoneAlert()
                ACTION_SYNC_ORB -> syncOverlayWindow()
                ACTION_LISTEN_NOW -> {
                    promoteMicForegroundIfPossible()
                    stopLockScreenVadMonitor()
                    isPausedExternal = false
                    isSpeaking = false
                    manualListenTrigger = true
                    wakeSessionUntilMs = SystemClock.elapsedRealtime() + 8_000L
                    initAndStartSpeechLoop()
                    return START_STICKY
                }
                ACTION_KEEP_ALIVE -> {
                    if (wakeLock?.isHeld == false) {
                        try { wakeLock?.acquire(12 * 60 * 60 * 1000L) } catch (_: Throwable) {}
                    }
                }
                else -> promoteMicForegroundIfPossible()
            }
            syncOverlayWindow()
            if (!isListening && !isSpeaking && !isDestroyed && vadJob?.isActive != true) {
                scheduleRestart(350L)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "onStartCommand recovered cleanly: ${t.message}")
        }
        return START_STICKY
    }

    private fun updateLiveNotification() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.notify(NOTIFICATION_ID, buildForegroundNotification())
        } catch (_: Exception) {}
    }

    private fun initAndStartSpeechLoop() {
        if (isDestroyed || isPausedExternal || isSpeaking) return
        stopLockScreenVadMonitor()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastExecutedSummary = "Mic permission missing — grant Mic access"
            onLiveUpdate?.invoke()
            updateLiveNotification()
            scheduleRestart(3000L)
            return
        }
        val canOnDevice = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)
        if (!SpeechRecognizer.isRecognitionAvailable(this) && !canOnDevice) {
            Log.w(TAG, "SpeechRecognizer not available — keeping VAD lock-screen monitor active.")
            startLockScreenVadMonitor()
            return
        }

        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {}

        speechRecognizer = (if (preferOnDevice && canOnDevice && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else {
            SpeechRecognizer.createSpeechRecognizer(this)
        }).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    isListening = true
                    consecutiveErrors = 0
                    bgMicBlockedByRom = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                    val lockedLabel = if (!powerManager.isInteractive || keyguardManager.isKeyguardLocked) {
                        "🔒 Listening on Lock Screen (बोलें)..."
                    } else {
                        "🎤 Listening hands-free (बोलें)..."
                    }
                    if (lastExecutedSummary.startsWith("Starting") ||
                        lastExecutedSummary.startsWith("Mic Err") ||
                        lastExecutedSummary.startsWith("🔒")
                    ) {
                        lastExecutedSummary = lockedLabel
                        onLiveUpdate?.invoke()
                        updateLiveNotification()
                    }
                }
                override fun onBeginningOfSpeech() {
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    isListening = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onResults(results: Bundle?) {
                    isListening = false
                    consecutiveErrors = 0
                    bgMicBlockedByRom = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.map { it.trim() }
                        ?.filter { it.isNotEmpty() }
                        .orEmpty()
                    if (matches.isNotEmpty()) {
                        handleSpokenCandidates(matches)
                    } else {
                        if (!powerManager.isInteractive && SystemClock.elapsedRealtime() > vadWakeWindowUntilMs) {
                            startLockScreenVadMonitor()
                        } else {
                            scheduleRestart(350L)
                        }
                    }
                }
                override fun onError(error: Int) {
                    isListening = false
                    lastMicCallbackAt = SystemClock.elapsedRealtime()
                    if (isPausedExternal || isSpeaking || isDestroyed) return

                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        if (!powerManager.isInteractive && SystemClock.elapsedRealtime() > vadWakeWindowUntilMs) {
                            startLockScreenVadMonitor()
                        } else {
                            scheduleRestart(350L)
                        }
                        return
                    }

                    consecutiveErrors++
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS || error == SpeechRecognizer.ERROR_AUDIO) {
                        bgMicBlockedByRom = consecutiveErrors >= 2
                        if (!powerManager.isInteractive || consecutiveErrors >= 2) {
                            startLockScreenVadMonitor()
                            return
                        }
                    }
                    val errLabel = when (error) {
                        SpeechRecognizer.ERROR_AUDIO -> "Audio busy"
                        SpeechRecognizer.ERROR_CLIENT -> "Client reset"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ROM bg mic guard — VAD active"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
                        SpeechRecognizer.ERROR_SERVER, 11 -> "Speech server reset"
                        else -> "Code $error"
                    }
                    lastExecutedSummary = "Mic Err ($errLabel) — retrying..."
                    onLiveUpdate?.invoke()
                    updateLiveNotification()

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                        SpeechRecognizer.isOnDeviceRecognitionAvailable(this@MeiraWakeWordService)) {
                        preferOnDevice = !preferOnDevice
                    }

                    val backoff = (900L * consecutiveErrors.coerceAtMost(4))
                    mainHandler.removeCallbacks(restartMicRunnable)
                    mainHandler.postDelayed({ initAndStartSpeechLoop() }, backoff)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        startListeningOnce()
    }

    private fun startListeningOnce() {
        if (isDestroyed || isSpeaking || isListening || isPausedExternal || vadJob?.isActive == true) return
        if (isExternalMediaPlaying() && !manualListenTrigger && SystemClock.elapsedRealtime() >= wakeSessionUntilMs) {
            // Media Safety: Do NOT trigger SpeechRecognizer automatically during active audio/video playback
            if (!lastExecutedSummary.startsWith("🎵")) {
                lastExecutedSummary = "🎵 Media active — audio untouched (say 'मीरा' via Orb when needed)"
                onLiveUpdate?.invoke()
            }
            scheduleRestart(2500L)
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            scheduleRestart(3000L)
            return
        }
        try {
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            }
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            Log.w(TAG, "Failed starting listener: ${e.message}")
            mainHandler.postDelayed({ initAndStartSpeechLoop() }, 1200L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed || isSpeaking || isPausedExternal) return
        mainHandler.removeCallbacks(restartMicRunnable)
        mainHandler.postDelayed(restartMicRunnable, delayMs)
    }

    private fun stripWakeWord(phrase: String): String {
        return phrase
            .replace(
                Regex("^(?:hey|ok|hi|hello|अरे|हे|ओके|सुनो|जी)?\\s*(?:meera|meira|mira|mera|mehra|मीरा|मिरा|मेरा|मेहरा)(?:\\s*जी)?[,:\\s]*", RegexOption.IGNORE_CASE),
                ""
            )
            .replace(
                Regex("[,:\\s]*(?:meera|meira|mira|mera|mehra|मीरा|मिरा|मेरा|मेहरा)(?:\\s*जी)?[.!?]*$", RegexOption.IGNORE_CASE),
                ""
            )
            .trim()
    }

    private fun handleSpokenCandidates(matches: List<String>) {
        val primaryPhrase = matches.first()
        val wasManualTrigger = manualListenTrigger
        manualListenTrigger = false
        lastHeardPhrase = primaryPhrase
        onLiveUpdate?.invoke()

        if (KillSwitchManager.isEmergencyKilled) {
            lastExecutedSummary = "Blocked: Kill-Switch active"
            onLiveUpdate?.invoke()
            scheduleRestart(1000L)
            return
        }

        // Check if waiting on a disambiguation reply (e.g. "पहला", "दूसरा", or contact name)
        if (SystemClock.elapsedRealtime() < pendingDisambigUntilMs && pendingDisambigOptions.isNotEmpty()) {
            val lowerReply = primaryPhrase.lowercase().trim()
            val picked = when {
                lowerReply == "1" || lowerReply.contains("पहला") || lowerReply.contains("first") -> pendingDisambigOptions.firstOrNull()
                lowerReply == "2" || lowerReply.contains("दूसरा") || lowerReply.contains("second") -> pendingDisambigOptions.getOrNull(1)
                else -> pendingDisambigOptions.firstOrNull { opt ->
                    opt.lowercase().contains(lowerReply) || lowerReply.split(Regex("\\s+")).any { it.length > 2 && opt.lowercase().contains(it) }
                }
            }
            if (picked != null && pendingDisambigResult != null) {
                val base = pendingDisambigResult!!
                pendingDisambigResult = null
                pendingDisambigOptions = emptyList()
                pendingDisambigUntilMs = 0L
                val msg = base.parameters?.get("messageText")?.toString() ?: "नमस्ते"
                val resolvedIntent = if (base.action == "DISAMBIGUATE_CALL") "MAKE_CALL" else "SEND_MESSAGE"
                val resolved = base.copy(
                    intent = resolvedIntent,
                    parameters = mapOf("contact" to picked, "messageText" to msg),
                    spokenFeedback = "$picked को पूरा किया गया।",
                    moduleAction = if (resolvedIntent == "MAKE_CALL") "phone.make_call" else "whatsapp.send_message",
                    targetPayload = "Contact: $picked"
                )
                MeeraCommandExecutor.execute(this, resolved, systemControl, findMyPhoneManager) { extra ->
                    lastExecutedSummary = extra
                    onLiveUpdate?.invoke()
                    updateLiveNotification()
                }
                scheduleRestart(250L)
                return
            }
        }

        val wakeWords = listOf("मीरा", "मिरा", "मेरा", "मेहरा", "meera", "meira", "mira", "mera", "mehra")
        val hasWakeWord = matches.any { cand ->
            val l = cand.lowercase()
            wakeWords.any { l.contains(it) }
        }
        val inWakeWindow = SystemClock.elapsedRealtime() < wakeSessionUntilMs

        if (requireWakeWord && !hasWakeWord && !inWakeWindow && !wasManualTrigger) {
            lastExecutedSummary = "⏳ Waiting for 'मीरा' (Ignored ambient voice)"
            onLiveUpdate?.invoke()
            scheduleRestart(250L)
            return
        }

        // If user said ONLY 'मीरा' without a command yet, silently open a 7-second command window
        val strippedPrimary = stripWakeWord(primaryPhrase)
        if (hasWakeWord && strippedPrimary.isEmpty() && matches.all { stripWakeWord(it).isEmpty() }) {
            wakeSessionUntilMs = SystemClock.elapsedRealtime() + 7_000L
            lastExecutedSummary = "👂 'मीरा' सक्रिय — बोलें (Silent Ready 7s)..."
            onLiveUpdate?.invoke()
            updateLiveNotification()
            scheduleRestart(120L)
            return
        }

        intentParser.airGapLocalOnly = airGapLocalOnly
        serviceScope.launch {
            var chosenResult: JarvisCommandResult? = null
            var chosenPhrase = primaryPhrase

            for (cand in matches) {
                val cleaned = stripWakeWord(cand).ifEmpty { cand }
                val res = intentParser.parseCommand(cleaned, isSpeakerVerified = isOwnerVoiceVerified, systemControl = systemControl)
                if (chosenResult == null) {
                    chosenResult = res
                    chosenPhrase = cand
                }
                if (res.intent != "UNKNOWN") {
                    chosenResult = res
                    chosenPhrase = cand
                    break
                }
            }

            val result = chosenResult ?: return@launch
            lastHeardPhrase = chosenPhrase

            if (result.intent == "VOICE_SECURITY_ALERT") {
                wakeSessionUntilMs = 0L
                lastExecutedSummary = "UNVERIFIED VOICE BLOCKED!"
                onLiveUpdate?.invoke()
                voiceAuthManager.dispatchUnverifiedVoiceAlert(chosenPhrase)
                scheduleRestart(1800L)
                return@launch
            }

            if (result.intent == "TURN_OFF_MEERA") {
                wakeSessionUntilMs = 0L
                pendingDisambigUntilMs = 0L
                pendingDisambigOptions = emptyList()
                pendingDisambigResult = null
                findMyPhoneManager.stopAlert()
                lastExecutedSummary = "🛑 Meera turned OFF by voice command"
                onLiveUpdate?.invoke()
                updateLiveNotification()
                speakReply(result.spokenFeedback)
                mainHandler.postDelayed({
                    isServiceRunning = false
                    stopSelf()
                }, 1600L)
                return@launch
            }

            if (result.intent == "SECURITY_BLOCKED") {
                wakeSessionUntilMs = 0L
                lastExecutedSummary = "🛡️ Blocked: ${result.spokenFeedback}"
                onLiveUpdate?.invoke()
                updateLiveNotification()
                speakReply(result.spokenFeedback)
                return@launch
            }

            if (result.intent == "DISAMBIGUATION_NEEDED") {
                pendingDisambigResult = result
                pendingDisambigOptions = result.options
                pendingDisambigUntilMs = SystemClock.elapsedRealtime() + 15_000L
                wakeSessionUntilMs = SystemClock.elapsedRealtime() + 15_000L
                lastExecutedSummary = "❓ ${result.spokenFeedback}"
                onLiveUpdate?.invoke()
                updateLiveNotification()
                speakReply(result.spokenFeedback)
                return@launch
            }

            if (result.intent == "UNKNOWN") {
                lastExecutedSummary = "No valid command: $primaryPhrase"
                onLiveUpdate?.invoke()
                scheduleRestart(250L)
                return@launch
            }

            wakeSessionUntilMs = 0L
            lastExecutedSummary = "⚡ Silent Action: ${result.moduleAction} → ${result.targetPayload}"
            onLiveUpdate?.invoke()
            updateLiveNotification()

            val lockScreenDirectOk = result.intent == "FIND_MY_PHONE" ||
                result.intent == "STOP_ALARM" ||
                result.intent == "TURN_OFF_MEERA" ||
                result.intent == "TIME_DATE_QUERY" ||
                result.intent == "WEB_SEARCH_ANSWER" ||
                result.intent == "ADJUST_VOLUME" ||
                (result.intent == "TOGGLE_SETTING" && result.parameters?.get("setting") == "flashlight")

            // Strictly respect OS Keyguard Lock Screen — never attempt to bypass lock screen
            if (keyguardManager.isKeyguardLocked && !lockScreenDirectOk) {
                lastExecutedSummary = "🔒 फ़ोन लॉक है — कृपया पहले अनलॉक करें"
                onLiveUpdate?.invoke()
                updateLiveNotification()
                speakReply("फ़ोन लॉक है। कृपया पहले फ़ोन अनलॉक करें।")
                return@launch
            }

            MeeraCommandExecutor.execute(
                context = this@MeiraWakeWordService,
                result = result,
                systemControl = systemControl,
                findMyPhoneManager = findMyPhoneManager
            ) { extraMsg ->
                lastExecutedSummary = extraMsg
                onLiveUpdate?.invoke()
                updateLiveNotification()
            }

            val mustSpeakAnswer = result.intent == "TIME_DATE_QUERY" || result.intent == "WEB_SEARCH_ANSWER"
            if ((mustSpeakAnswer || !silentExecutionMode) && result.intent != "FIND_MY_PHONE") {
                speakReply(result.spokenFeedback)
            } else {
                scheduleRestart(250L)
            }
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAlarmIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MeiraWakeWordService::class.java).apply { action = ACTION_STOP_ALARM },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Meera Hands-Free Active (मीरा)")
            .setContentText(lastExecutedSummary)
            .setSmallIcon(R.drawable.ic_meira_orb)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_meira_orb, "Stop Alarm", stopAlarmIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Meera Background Listening",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Meera listening hands-free for voice commands"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // Only use AlarmManager FGS restart on Android < 12; Android 12+ relies safely on START_STICKY + stopWithTask="false"
        if (!KillSwitchManager.isEmergencyKilled && Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            try {
                val restartIntent = Intent(applicationContext, MeiraWakeWordService::class.java)
                val pi = PendingIntent.getForegroundService(
                    applicationContext,
                    2099,
                    restartIntent,
                    PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
                )
                val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, SystemClock.elapsedRealtime() + 800L, pi)
            } catch (e: Throwable) {
                Log.w(TAG, "onTaskRemoved restart skipped: ${e.message}")
            }
        }
    }

    override fun onDestroy() {
        isDestroyed = true
        isServiceRunning = false
        isOverlayVisible = false
        isLockScreenVadActive = false
        activeInstance = null
        super.onDestroy()
        try { stopLockScreenVadMonitor() } catch (_: Throwable) {}
        try { unregisterReceiver(screenWakeReceiver) } catch (_: Throwable) {}
        try { overlayManager.removeOverlay() } catch (_: Throwable) {}
        try { serviceScope.cancel() } catch (_: Throwable) {}
        try { mainHandler.removeCallbacksAndMessages(null) } catch (_: Throwable) {}
        try { speechRecognizer?.destroy() } catch (_: Throwable) {}
        try { tts?.stop(); tts?.shutdown() } catch (_: Throwable) {}
        try { findMyPhoneManager.stopAlert() } catch (_: Throwable) {}
        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (_: Throwable) {}
        onLiveUpdate?.invoke()
        Log.i(TAG, "Meira Wake Word Service destroyed.")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
