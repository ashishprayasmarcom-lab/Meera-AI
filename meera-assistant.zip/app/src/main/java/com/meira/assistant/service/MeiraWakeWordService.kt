package com.meira.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.app.NotificationCompat
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.meira.assistant.phonefinder.FindMyPhoneManager

/**
 * Continuous Background Wake-Word & Voice Service for Meera.
 * Uses PARTIAL_WAKE_LOCK + Android SpeechRecognizer loop to listen for:
 * - "Meera, where are you?" / "मीरा कहाँ हो"
 * - "Find my phone" / "फोन ढूंढो"
 * - "Stop alarm" / "बंद करो"
 */
class MeiraWakeWordService : Service() {

    companion object {
        private const val TAG = "MeiraWakeService"
        private const val CHANNEL_ID = "meira_wake_channel"
        private const val NOTIFICATION_ID = 2001
        const val ACTION_STOP_ALARM = "com.meira.assistant.ACTION_STOP_ALARM"
        const val ACTION_TRIGGER_FIND_PHONE = "com.meira.assistant.ACTION_TRIGGER_FIND_PHONE"
        var isServiceRunning = false
            private set
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var findMyPhoneManager: FindMyPhoneManager
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isDestroyed = false

    override fun onCreate() {
        super.onCreate()
        isServiceRunning = true
        findMyPhoneManager = FindMyPhoneManager(this)

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Meira::ContinuousWakeWordLock"
        ).apply {
            acquire(12 * 60 * 60 * 1000L)
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildForegroundNotification())
        Log.i(TAG, "Meira Wake Word Service started in foreground.")

        mainHandler.post { initAndStartSpeechLoop() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> findMyPhoneManager.stopAlert()
            ACTION_TRIGGER_FIND_PHONE -> findMyPhoneManager.triggerFindPhoneAlert()
        }
        return START_STICKY
    }

    private fun initAndStartSpeechLoop() {
        if (isDestroyed || !SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "SpeechRecognizer not available on this device.")
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {
                    val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    matches?.firstOrNull()?.let { checkPhrase(it) }
                }
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    matches?.firstOrNull()?.let { checkPhrase(it) }
                    scheduleRestart(300L)
                }
                override fun onError(error: Int) {
                    scheduleRestart(1200L)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        startListeningOnce()
    }

    private fun startListeningOnce() {
        if (isDestroyed) return
        try {
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            Log.w(TAG, "Failed starting listener: ${e.message}")
            scheduleRestart(2000L)
        }
    }

    private fun scheduleRestart(delayMs: Long) {
        if (isDestroyed) return
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({ startListeningOnce() }, delayMs)
    }

    private fun checkPhrase(phrase: String) {
        val lower = phrase.lowercase()
        Log.d(TAG, "Wake listener heard: $lower")
        if (lower.contains("band karo") || lower.contains("stop alarm") || lower.contains("chup")) {
            findMyPhoneManager.stopAlert()
        } else if (
            lower.contains("where are you") ||
            lower.contains("find my phone") ||
            lower.contains("kahan ho") ||
            lower.contains("kaha ho") ||
            lower.contains("dhoondo") ||
            lower.contains("dhundo")
        ) {
            findMyPhoneManager.triggerFindPhoneAlert()
        }
    }

    private fun buildForegroundNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stopAlarmIntent = PendingIntent.getService(
            this, 1,
            Intent(this, MeiraWakeWordService::class.java).apply { action = ACTION_STOP_ALARM },
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Meera Active Listening (मीरा)")
            .setContentText("Say 'Meera, kahan ho?' or 'Find my phone'")
            .setSmallIcon(R.drawable.ic_meira_orb)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_meira_orb, "Stop Alarm", stopAlarmIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Meera Background Listening",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Meera responsive to find-phone voice commands"
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        isDestroyed = true
        isServiceRunning = false
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        speechRecognizer?.destroy()
        findMyPhoneManager.stopAlert()
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        Log.i(TAG, "Meira Wake Word Service destroyed.")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
