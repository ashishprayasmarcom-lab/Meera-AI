package com.jarvis.assistant.security

import android.content.Context
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Security & Privacy Controller for Jarvis Autonomous Assistant.
 * Mandates:
 * 1. Hardened package blacklist (Financial, Banking, UPI, and Credential apps).
 * 2. Absolute shielding against reading or typing into password/PIN fields.
 * 3. Strict local air-gap mode with zero cloud telemetry.
 */
object SecurityPolicyManager {

    private const val TAG = "JarvisSecurity"

    // Hardened Blacklist of Protected Financial & Credential Packages
    private val PROTECTED_PACKAGES = hashSetOf(
        // UPI & Payments (India & Global)
        "com.google.android.apps.nbu.paisa.user", // Google Pay
        "net.one97.paytm",                        // Paytm
        "com.phonepe.app",                        // PhonePe
        "in.org.npci.upiapp",                     // BHIM UPI
        "com.whatsapp.payments",                  // WhatsApp UPI entry
        "com.sbi.upi",                            // Yono SBI
        "com.snapwork.hdfc",                      // HDFC Bank
        "com.csam.icici.bank.imobile",            // ICICI iMobile
        "com.chase.sig.android",                  // Chase Bank
        "com.infonow.bofa",                       // Bank of America
        "com.paypal.android.p2pmobile",           // PayPal

        // Password Managers & Authenticator 2FA
        "com.x8bit.bitwarden",                    // Bitwarden
        "com.onepassword.android",                // 1Password
        "com.google.android.apps.authenticator2", // Google Authenticator
        "com.authy.authy",                        // Twilio Authy
        "com.microsoft.msa.authenticator",        // MS Authenticator

        // Crypto Wallets
        "com.binance.dev",                        // Binance
        "io.metamask",                            // MetaMask
        "com.wallet.crypto.trustapp"              // Trust Wallet
    )

    /**
     * Checks if target package is in the sensitive security blacklist.
     * When TRUE: Automation is strictly aborted to prevent screen snooping.
     */
    fun isAppBlacklisted(packageName: String?): Boolean {
        if (packageName.isNullOrBlank()) return false
        val isBlocked = PROTECTED_PACKAGES.contains(packageName.trim().lowercase())
        if (isBlocked) {
          Log.e(TAG, "SECURITY INTERCEPTION: Package '$packageName' is protected. Automation aborted.")
        }
        return isBlocked
    }

    /**
     * Inspects an AccessibilityNodeInfo to guarantee it is NOT a password, PIN, or credential input.
     * Android OS tags password nodes with node.isPassword = true.
     */
    fun isNodeSecureForInteraction(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false

        // Check 1: Android native password flag
        if (node.isPassword) {
            Log.e(TAG, "SECURITY SHIELD: Password field detected. Input rejected.")
            return false
        }

        // Check 2: Inspect view ID or content description for PIN/CVV/Password leaks
        val idRes = node.viewIdResourceName?.lowercase() ?: ""
        val textDesc = (node.contentDescription?.toString() ?: "").lowercase()
        val keywords = listOf("password", "pin", "cvv", "otp", "passcode", "secret", "card_number")

        for (kw in keywords) {
          if (idRes.contains(kw) || textDesc.contains(kw)) {
            Log.e(TAG, "SECURITY SHIELD: Sensitive field '$kw' identified in node hierarchy. Interaction blocked.")
            return false
          }
        }

        return true
    }

    /**
     * Guarantees zero analytics/telemetry data transmission.
     */
    fun sanitizeSpokenTextForLogging(text: String): String {
        // Redacts any 4-16 digit numbers (credit cards, OTPs, phone numbers) before in-memory storage
        return text.replace(Regex("\\b\\d{4,16}\\b"), "[REDACTED_NUMERIC]")
    }
}
