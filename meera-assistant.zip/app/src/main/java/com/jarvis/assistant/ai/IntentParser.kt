package com.jarvis.assistant.ai

import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.jarvis.assistant.security.SecurityPolicyManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

data class JarvisCommandResult(
    @SerializedName("intent") val intent: String,
    @SerializedName("targetApp") val targetApp: String?,
    @SerializedName("action") val action: String,
    @SerializedName("parameters") val parameters: Map<String, Any?>?,
    @SerializedName("spokenFeedback") val spokenFeedback: String,
    @SerializedName("accessibilityServiceSteps") val steps: List<String>?,
    val isLocallyProcessed: Boolean = true,
    val voiceStatus: String = "VERIFIED (Owner)",
    val unlockBiometricMode: String = "Voice Unlocked (Face Lock & Fingerprint Active)",
    val responseStatus: String = "पूरा हुआ",
    val command: String = "",
    val moduleAction: String = "idle.no_action",
    val targetPayload: String = "NO COMMAND, NO ACTION",
    val executionMode: String = "EXPLICIT_VOICE_COMMAND_ONLY"
)

/**
 * Hands-Free Voice-Secured Phone Controller Intent Parser (Hindi, English, Hinglish).
 * Enforces Speaker Match VERIFIED check, NO COMMAND NO ACTION, and covers all 19 explicit voice commands offline.
 */
class IntentParser(
    private val geminiApiKey: String? = null,
    var airGapLocalOnly: Boolean = true
) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    suspend fun parseCommand(
        rawSpeech: String,
        isSpeakerVerified: Boolean = true
    ): JarvisCommandResult = withContext(Dispatchers.IO) {
        val sanitized = SecurityPolicyManager.sanitizeSpokenTextForLogging(rawSpeech.trim())

        if (!isSpeakerVerified) {
            return@withContext JarvisCommandResult(
                intent = "VOICE_SECURITY_ALERT",
                targetApp = null,
                action = "BLOCKED_UNVERIFIED_SPEAKER",
                parameters = emptyMap(),
                spokenFeedback = "अलर्ट: अनजान आवाज़ पहचानी गई। आपकी अनुमति के बिना फ़ोन अनलॉक और किसी भी कार्य को रोक दिया गया है।",
                steps = listOf(
                    "VoiceSpeakerAuthManager: Speaker Match = UNVERIFIED / UNKNOWN",
                    "KeyguardManager: Keep device LOCKED (Face Lock & Fingerprint Active)",
                    "SecurityAlert: Action blocked & alert dispatched"
                ),
                isLocallyProcessed = true,
                voiceStatus = "UNVERIFIED (Alert Sent)",
                unlockBiometricMode = "Locked (Face Lock & Fingerprint Active)",
                responseStatus = "अलर्ट भेजा गया",
                command = sanitized,
                moduleAction = "security.voice_auth_block",
                targetPayload = "Voice Lock Protected — Action Denied"
            )
        }

        if (sanitized.isBlank()) {
            return@withContext parseOfflineAirGap("")
        }

        if (airGapLocalOnly || geminiApiKey.isNullOrEmpty()) {
            return@withContext parseOfflineAirGap(sanitized)
        }

        try {
            return@withContext queryGeminiApi(sanitized)
        } catch (e: Exception) {
            return@withContext parseOfflineAirGap(sanitized)
        }
    }

    private fun parseOfflineAirGap(text: String): JarvisCommandResult {
        val lower = text.lowercase().trim()
        if (lower.isEmpty()) {
            return JarvisCommandResult(
                intent = "UNKNOWN",
                targetApp = null,
                action = "NO_COMMAND_NO_ACTION",
                parameters = emptyMap(),
                spokenFeedback = "कोई स्पष्ट आदेश नहीं मिला। निष्क्रिय हूँ।",
                steps = listOf("NO COMMAND, NO ACTION"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "idle.no_action",
                targetPayload = "NO COMMAND, NO ACTION"
            )
        }

        // Find My Phone / Stop Alarm
        if (lower.contains("where are you") || lower.contains("find my phone") ||
            lower.contains("kahan ho") || lower.contains("kaha ho") ||
            lower.contains("dhoondo") || lower.contains("dhundo")) {
            return JarvisCommandResult(
                intent = "FIND_MY_PHONE",
                targetApp = "system",
                action = "TRIGGER_FIND_MY_PHONE",
                parameters = emptyMap(),
                spokenFeedback = "Main yahan hoon! Alarm aur flashlight chalu kar rahi hoon.",
                steps = listOf("FindMyPhoneManager.triggerFindPhoneAlert()"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.find_my_phone",
                targetPayload = "Alarm Siren + Torch Strobe"
            )
        }

        if (lower.contains("stop alarm") || lower.contains("alarm band") || lower.contains("अलार्म बंद") ||
            lower == "band karo" || lower == "बंद करो") {
            return JarvisCommandResult(
                intent = "STOP_ALARM",
                targetApp = "system",
                action = "STOP_ALARM",
                parameters = emptyMap(),
                spokenFeedback = "अलार्म बंद कर दिया गया है।",
                steps = listOf("FindMyPhoneManager.stopAlert()"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.stop_alarm",
                targetPayload = "Silence Alarm"
            )
        }

        // Sensitive app interception
        val sensitive = listOf("gpay", "paytm", "phonepe", "bank", "password", "otp", "pin")
        if (sensitive.any { lower.contains(it) }) {
            return JarvisCommandResult(
                intent = "SECURITY_BLOCKED",
                targetApp = "com.protected.financial",
                action = "BLOCK_SENSITIVE_APP",
                parameters = mapOf("reason" to "Banking & Password Guard Active"),
                spokenFeedback = "Financial aur password apps me automation security policy ke tehat blocked hai.",
                steps = listOf("SecurityPolicyManager: Intercepted prohibited package access"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "security.blocked",
                targetPayload = "Protected financial/credential target"
            )
        }

        // 1. WhatsApp Commands (read_messages, open_chat, send_message)
        if (lower.contains("whatsapp") || lower.contains("व्हाट्सएप") || lower.contains("व्हाट्सऐप") ||
            lower.contains("वॉट्सऐप") || lower.contains("वाट्सएप") || lower.contains("वट्सअप")) {
            if (lower.contains("पढ़ो") || lower.contains("पढो") || lower.contains("padho") || lower.contains("read")) {
                val contactMatch = Regex("(?:पर|par|of|from|के)\\s+([a-zA-Z0-9_\\u0900-\\u097F+\\s]+?)(?:\\s+(?:के|ke|ki)\\s+(?:मैसेज|message)|$)").find(text)
                val contact = contactMatch?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() } ?: "Friend"
                return JarvisCommandResult(
                    intent = "READ_MESSAGES",
                    targetApp = "whatsapp",
                    action = "READ_WHATSAPP_MESSAGES",
                    parameters = mapOf("contact" to contact),
                    spokenFeedback = "$contact के WhatsApp मैसेज पढ़ रही हूँ।",
                    steps = listOf("VoiceAutomationService.readLatestMessages($contact)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "whatsapp.read_messages",
                    targetPayload = "Contact: $contact"
                )
            }
            if ((lower.contains("चैट") || lower.contains("chat")) &&
                (lower.contains("खोलो") || lower.contains("खोल") || lower.contains("kholo") || lower.contains("open"))) {
                val contactMatch = Regex("(?:पर|par|with|की)\\s+([a-zA-Z0-9_\\u0900-\\u097F+\\s]+?)(?:\\s+(?:की|ki)\\s+(?:चैट|chat)|$)").find(text)
                val contact = contactMatch?.groupValues?.get(1)?.trim()?.takeIf { it.isNotEmpty() } ?: "Friend"
                return JarvisCommandResult(
                    intent = "OPEN_CHAT",
                    targetApp = "whatsapp",
                    action = "OPEN_WHATSAPP_CHAT",
                    parameters = mapOf("contact" to contact),
                    spokenFeedback = "WhatsApp पर $contact की चैट खोल रही हूँ।",
                    steps = listOf("VoiceAutomationService.openWhatsAppChat($contact)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "whatsapp.open_chat",
                    targetPayload = "Contact: $contact"
                )
            }
            if (lower.contains("मैसेज") || lower.contains("message") || lower.contains("भेजो") || lower.contains("भेज") || lower.contains("bhejo") || lower.contains("send")) {
                val parts = text.split(":")
                val msgText = if (parts.size > 1) {
                    parts.drop(1).joinToString(":").trim()
                } else {
                    Regex("(?:भेजो|भेज|bhejo|send|लिखो)\\s+(.+)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)?.trim() ?: "Hello"
                }
                val contactMatch = Regex("(?:पर|par|to)\\s+([a-zA-Z0-9_\\u0900-\\u097F+]+)(?:\\s+(?:को|ko))?").find(text)
                val contact = contactMatch?.groupValues?.get(1)?.trim() ?: "Friend"
                return JarvisCommandResult(
                    intent = "SEND_MESSAGE",
                    targetApp = "whatsapp",
                    action = "SEND_WHATSAPP_MESSAGE",
                    parameters = mapOf("contact" to contact, "messageText" to msgText),
                    spokenFeedback = "WhatsApp पर $contact को मैसेज भेज रही हूँ।",
                    steps = listOf("VoiceAutomationService.automateWhatsAppMessage($contact, $msgText)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "whatsapp.send_message",
                    targetPayload = "Recipient: $contact | Text: \"$msgText\""
                )
            }
            if (lower.contains("खोलो") || lower.contains("खोल") || lower.contains("ओपन") || lower.contains("kholo") || lower.contains("open") || lower.contains("चलाओ")) {
                return JarvisCommandResult(
                    intent = "LAUNCH_APP",
                    targetApp = "whatsapp",
                    action = "OPEN_WHATSAPP_APP",
                    parameters = mapOf("appName" to "whatsapp"),
                    spokenFeedback = "WhatsApp खोल रही हूँ।",
                    steps = listOf("SystemControlManager.launchApp(whatsapp)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "whatsapp.open_app",
                    targetPayload = "App: WhatsApp"
                )
            }
        }

        // 2. Instagram Commands
        if (lower.contains("instagram") || lower.contains("इंस्टाग्राम") || lower.contains("इंस्टा")) {
            if (lower.contains("प्रोफ़ाइल") || lower.contains("प्रोफाइल") || lower.contains("profile")) {
                val match = Regex("(?:पर|par|of)\\s+([a-zA-Z0-9_.]+)").find(text)
                val handle = match?.groupValues?.get(1)?.trim() ?: "instagram"
                return JarvisCommandResult(
                    intent = "OPEN_PROFILE",
                    targetApp = "instagram",
                    action = "OPEN_INSTAGRAM_PROFILE",
                    parameters = mapOf("profileHandle" to handle),
                    spokenFeedback = "Instagram पर @$handle की प्रोफ़ाइल खोल रही हूँ।",
                    steps = listOf("SystemControlManager.openUrl(https://instagram.com/$handle)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "instagram.open_profile",
                    targetPayload = "Profile: @$handle"
                )
            }
            if (lower.contains("मैसेज") || lower.contains("message") || lower.contains("भेजो") || lower.contains("bhejo") || lower.contains("dm")) {
                val parts = text.split(":")
                val msgText = if (parts.size > 1) parts.drop(1).joinToString(":").trim() else "Hi!"
                val match = Regex("(?:पर|par|to)\\s+([a-zA-Z0-9_.]+)").find(text)
                val contact = match?.groupValues?.get(1)?.trim() ?: "User"
                return JarvisCommandResult(
                    intent = "SEND_MESSAGE",
                    targetApp = "instagram",
                    action = "SEND_INSTAGRAM_MESSAGE",
                    parameters = mapOf("contact" to contact, "messageText" to msgText),
                    spokenFeedback = "Instagram पर $contact को मैसेज भेज रही हूँ।",
                    steps = listOf("Launch Instagram DM -> $contact -> $msgText"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "instagram.send_message",
                    targetPayload = "Recipient: $contact | Text: \"$msgText\""
                )
            }
            if (lower.contains("फ़ीड") || lower.contains("फीड") || lower.contains("feed")) {
                return JarvisCommandResult(
                    intent = "OPEN_FEED",
                    targetApp = "instagram",
                    action = "OPEN_INSTAGRAM_FEED",
                    parameters = mapOf("appName" to "instagram"),
                    spokenFeedback = "Instagram फ़ीड खोल रही हूँ।",
                    steps = listOf("SystemControlManager.launchApp(instagram)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "instagram.open_feed",
                    targetPayload = "Instagram Feed"
                )
            }
            if (lower.contains("खोलो") || lower.contains("खोल") || lower.contains("ओपन") || lower.contains("kholo") || lower.contains("open") || lower.contains("चलाओ")) {
                return JarvisCommandResult(
                    intent = "LAUNCH_APP",
                    targetApp = "instagram",
                    action = "OPEN_INSTAGRAM_APP",
                    parameters = mapOf("appName" to "instagram"),
                    spokenFeedback = "Instagram खोल रही हूँ।",
                    steps = listOf("SystemControlManager.launchApp(instagram)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "instagram.open_app",
                    targetPayload = "App: Instagram"
                )
            }
        }

        // 3. Facebook Commands
        if (lower.contains("facebook") || lower.contains("फ़ेसबुक") || lower.contains("फेसबुक")) {
            if (lower.contains("सर्च") || lower.contains("खोज") || lower.contains("search")) {
                val qMatch = Regex("(?:पर|on)\\s+(.+?)(?:\\s+(?:सर्च|खोजो|search)|$)").find(text)
                val query = qMatch?.groupValues?.get(1)?.trim() ?: text
                return JarvisCommandResult(
                    intent = "SEARCH_IN_APP",
                    targetApp = "facebook",
                    action = "FACEBOOK_SEARCH",
                    parameters = mapOf("searchQuery" to query),
                    spokenFeedback = "Facebook पर '$query' सर्च कर रही हूँ।",
                    steps = listOf("SystemControlManager.openUrl(https://www.facebook.com/search/top?q=$query)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "facebook.search",
                    targetPayload = "Query: \"$query\""
                )
            }
            if (lower.contains("मैसेज") || lower.contains("message") || lower.contains("भेजो") || lower.contains("bhejo")) {
                val parts = text.split(":")
                val msgText = if (parts.size > 1) parts.drop(1).joinToString(":").trim() else "Hello!"
                val match = Regex("(?:पर|par|to)\\s+([a-zA-Z0-9_.]+)").find(text)
                val contact = match?.groupValues?.get(1)?.trim() ?: "Friend"
                return JarvisCommandResult(
                    intent = "SEND_MESSAGE",
                    targetApp = "facebook",
                    action = "SEND_FACEBOOK_MESSAGE",
                    parameters = mapOf("contact" to contact, "messageText" to msgText),
                    spokenFeedback = "Facebook पर $contact को मैसेज भेज रही हूँ।",
                    steps = listOf("Launch Facebook/Messenger -> $contact -> $msgText"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "facebook.send_message",
                    targetPayload = "Recipient: $contact | Text: \"$msgText\""
                )
            }
            if (lower.contains("फ़ीड") || lower.contains("फीड") || lower.contains("feed")) {
                return JarvisCommandResult(
                    intent = "OPEN_FEED",
                    targetApp = "facebook",
                    action = "OPEN_FACEBOOK_FEED",
                    parameters = mapOf("appName" to "facebook"),
                    spokenFeedback = "Facebook फ़ीड खोल रही हूँ।",
                    steps = listOf("SystemControlManager.launchApp(facebook)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "facebook.open_feed",
                    targetPayload = "Facebook Feed"
                )
            }
            if (lower.contains("खोलो") || lower.contains("खोल") || lower.contains("ओपन") || lower.contains("kholo") || lower.contains("open") || lower.contains("चलाओ")) {
                return JarvisCommandResult(
                    intent = "LAUNCH_APP",
                    targetApp = "facebook",
                    action = "OPEN_FACEBOOK_APP",
                    parameters = mapOf("appName" to "facebook"),
                    spokenFeedback = "Facebook खोल रही हूँ।",
                    steps = listOf("SystemControlManager.launchApp(facebook)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "facebook.open_app",
                    targetPayload = "App: Facebook"
                )
            }
        }

        // 4. Phone Call Command
        if (lower.contains("कॉल") || lower.contains("फोन लगा") || lower.contains("फ़ोन लगा") ||
            lower.contains("फोन कर") || lower.contains("फ़ोन कर") ||
            lower.contains("call ") || lower.startsWith("call ") || lower.contains("dial ")) {
            val cleaned = text
                .replace(Regex("(को|कॉल करो|कॉल लगाओ|कॉल|फोन लगाओ|फ़ोन लगाओ|फोन करो|फ़ोन करो|call|dial|please)", RegexOption.IGNORE_CASE), "")
                .trim()
            val target = cleaned.ifEmpty { "Dialer" }
            return JarvisCommandResult(
                intent = "MAKE_CALL",
                targetApp = "dialer",
                action = "PHONE_MAKE_CALL",
                parameters = mapOf("contact" to target),
                spokenFeedback = "$target को कॉल लगा रही हूँ।",
                steps = listOf("SystemControlManager.makeCall($target)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "phone.make_call",
                targetPayload = "Target: $target"
            )
        }

        // 5. Alarm & Reminder Commands
        if (lower.contains("अलार्म") || lower.contains("alarm")) {
            val timeMatch = Regex("(\\d{1,2}(?::\\d{2})?\\s*(?:am|pm|बजे|baje)?)", RegexOption.IGNORE_CASE).find(text)
            val timeStr = timeMatch?.value?.trim() ?: "06:30"
            var hour = Regex("(\\d{1,2})").find(timeStr)?.value?.toIntOrNull() ?: 6
            val minute = Regex(":(\\d{2})").find(timeStr)?.groupValues?.get(1)?.toIntOrNull() ?: 0
            if ((lower.contains("शाम") || lower.contains("रात") || lower.contains("pm")) && hour < 12) {
                hour += 12
            }
            return JarvisCommandResult(
                intent = "SET_ALARM",
                targetApp = "clock",
                action = "SYSTEM_SET_ALARM",
                parameters = mapOf("alarmTime" to timeStr, "hour" to hour, "minute" to minute),
                spokenFeedback = "$timeStr का अलार्म सेट कर दिया गया है।",
                steps = listOf("SystemControlManager.setAlarm($hour, $minute)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.set_alarm",
                targetPayload = "Time: $timeStr"
            )
        }

        if (lower.contains("रिमाइंडर") || lower.contains("reminder") || lower.contains("याद दिला")) {
            val reminderText = text.replace(Regex("(का|की|के|रिमाइंडर|लगाओ|सेट करो|याद दिलाओ|reminder|set)", RegexOption.IGNORE_CASE), "").trim().ifEmpty { "Reminder" }
            return JarvisCommandResult(
                intent = "SET_REMINDER",
                targetApp = "clock",
                action = "SYSTEM_SET_REMINDER",
                parameters = mapOf("reminderText" to reminderText),
                spokenFeedback = "रिमाइंडर सेट किया गया: $reminderText",
                steps = listOf("SystemControlManager.setReminder($reminderText)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.set_reminder",
                targetPayload = "Reminder: $reminderText"
            )
        }

        // 6. Reels / Swipe / Scroll / Global OS gestures
        if (lower.contains("next") || lower.contains("agla") || lower.contains("अगला") ||
            lower.contains("नीचे स्क्रॉल") || lower.contains("scroll down") || lower.contains("swipe up")) {
            return JarvisCommandResult(
                intent = "GESTURE_SWIPE",
                targetApp = "instagram",
                action = "SWIPE_NEXT_REEL",
                parameters = mapOf("direction" to "up"),
                spokenFeedback = "आगे स्क्रॉल कर रही हूँ।",
                steps = listOf("VoiceAutomationService: dispatchGesture(SwipeUp, 280ms)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "instagram.swipe_next",
                targetPayload = "Direction: UP (280ms)"
            )
        }

        if (lower.contains("previous") || lower.contains("pichla") || lower.contains("पिछला") ||
            lower.contains("ऊपर स्क्रॉल") || lower.contains("scroll up") || lower.contains("swipe down")) {
            return JarvisCommandResult(
                intent = "GESTURE_SWIPE",
                targetApp = "instagram",
                action = "SWIPE_PREV_REEL",
                parameters = mapOf("direction" to "down"),
                spokenFeedback = "पीछे स्क्रॉल कर रही हूँ।",
                steps = listOf("VoiceAutomationService: dispatchGesture(SwipeDown, 280ms)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "instagram.swipe_previous",
                targetPayload = "Direction: DOWN (280ms)"
            )
        }

        if (lower.contains("back") || lower.contains("peeche") || lower.contains("पीछे") || lower.contains("बैक")) {
            return JarvisCommandResult(
                intent = "GLOBAL_ACTION",
                targetApp = "system",
                action = "GO_BACK",
                parameters = mapOf("type" to "back"),
                spokenFeedback = "वापस जा रही हूँ।",
                steps = listOf("performGlobalAction(GLOBAL_ACTION_BACK)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.global_back",
                targetPayload = "GLOBAL_ACTION_BACK"
            )
        }
        if (lower.contains("home") || lower.contains("होम") || lower.contains("ghar")) {
            return JarvisCommandResult(
                intent = "GLOBAL_ACTION",
                targetApp = "system",
                action = "GO_HOME",
                parameters = mapOf("type" to "home"),
                spokenFeedback = "होम स्क्रीन पर जा रही हूँ।",
                steps = listOf("performGlobalAction(GLOBAL_ACTION_HOME)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.global_home",
                targetPayload = "GLOBAL_ACTION_HOME"
            )
        }
        if (lower.contains("screenshot") || lower.contains("स्क्रीनशॉट")) {
            return JarvisCommandResult(
                intent = "GLOBAL_ACTION",
                targetApp = "system",
                action = "SCREENSHOT",
                parameters = mapOf("type" to "screenshot"),
                spokenFeedback = "स्क्रीनशॉट ले रही हूँ।",
                steps = listOf("performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.screenshot",
                targetPayload = "GLOBAL_ACTION_TAKE_SCREENSHOT"
            )
        }

        // 7. System / YouTube / Spotify Search
        if (lower.contains("सर्च") || lower.contains("खोज") || lower.contains("search") ||
            ((lower.contains("youtube") || lower.contains("यूट्यूब") || lower.contains("spotify")) &&
                (lower.contains("पर") || lower.contains("चलाओ") || lower.contains("play") || lower.contains("सुन")))) {
            val targetSearchApp = when {
                lower.contains("youtube") || lower.contains("यूट्यूब") -> "youtube"
                lower.contains("spotify") -> "spotify"
                else -> "browser"
            }
            val query = text
                .replace(Regex("(youtube|यूट्यूब|spotify|google|गूगल|क्रोम|chrome|पर|में|सर्च करो|सर्च|खोजो|चलाओ|बजाओ|search|play)", RegexOption.IGNORE_CASE), "")
                .trim()
                .ifEmpty { "Trending" }
            return JarvisCommandResult(
                intent = "SEARCH_IN_APP",
                targetApp = targetSearchApp,
                action = "SYSTEM_WEB_SEARCH",
                parameters = mapOf("searchQuery" to query),
                spokenFeedback = "$targetSearchApp पर '$query' सर्च कर रही हूँ।",
                steps = listOf("SystemControlManager.search($targetSearchApp, $query)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.search",
                targetPayload = "App: $targetSearchApp | Query: \"$query\""
            )
        }

        // 8. Auto-Fix Misconfigured Settings ("सेटिंग में जो गड़बड़ है उसे ठीक करो")
        if (lower.contains("गड़बड़") || lower.contains("सुधार") || lower.contains("ठीक कर") || lower.contains("सही कर") ||
            (lower.contains("fix") && (lower.contains("setting") || lower.contains("सेटिंग") || lower.contains("network") || lower.contains("नेटवर्क") || lower.contains("sound") || lower.contains("साउंड")))
        ) {
            val hasAppTarget = lower.contains("whatsapp") || lower.contains("व्हाट्स") || lower.contains("instagram") ||
                lower.contains("इंस्टा") || lower.contains("facebook") || lower.contains("फेसबुक") ||
                lower.contains("youtube") || lower.contains("यूट्यूब") || lower.contains("chrome") ||
                lower.contains("परमिशन") || lower.contains("permission") || lower.contains("नोटि") ||
                lower.contains("notification") || lower.contains("स्टोरेज") || lower.contains("storage")

            if (hasAppTarget) {
                val appTarget = when {
                    lower.contains("whatsapp") || lower.contains("व्हाट्स") -> "WhatsApp"
                    lower.contains("instagram") || lower.contains("इंस्टा") -> "Instagram"
                    lower.contains("facebook") || lower.contains("फेसबुक") -> "Facebook"
                    lower.contains("youtube") || lower.contains("यूट्यूब") -> "YouTube"
                    lower.contains("chrome") || lower.contains("क्रोम") -> "Chrome"
                    else -> "Meera AI"
                }
                val fixArea = when {
                    lower.contains("नोटि") || lower.contains("notification") -> "Notification"
                    lower.contains("स्टोरेज") || lower.contains("storage") -> "Storage"
                    else -> "Permission"
                }
                return JarvisCommandResult(
                    intent = "APP_SETTINGS_FIX",
                    targetApp = appTarget.lowercase(),
                    action = "SYSTEM_APP_SETTINGS_FIX",
                    parameters = mapOf("appName" to appTarget, "setting" to fixArea),
                    spokenFeedback = "$appTarget की $fixArea सेटिंग खोलकर सुधार दी गई है।",
                    steps = listOf("SystemControlManager.openAppSettingsFix($appTarget)"),
                    isLocallyProcessed = true,
                    responseStatus = "सुधारा गया",
                    command = text,
                    moduleAction = "system.app_settings_fix",
                    targetPayload = "App: $appTarget | Section: $fixArea (Fixed)"
                )
            }

            return JarvisCommandResult(
                intent = "FIX_SETTING",
                targetApp = "settings",
                action = "SYSTEM_FIX_SETTING",
                parameters = emptyMap(),
                spokenFeedback = "गड़बड़ सेटिंग (Wi-Fi, DND, वॉल्यूम, ब्राइटनेस) जांचकर ठीक कर दी गई है।",
                steps = listOf("SystemControlManager.fixBrokenSettings()"),
                isLocallyProcessed = true,
                responseStatus = "सुधारा गया",
                command = text,
                moduleAction = "system.fix_setting",
                targetPayload = "Repaired: Device Settings Diagnostics"
            )
        }

        // 9. App Permission / Notification / Storage Settings Open or Fix
        if (lower.contains("परमिशन") || lower.contains("permission") || lower.contains("स्टोरेज") || lower.contains("storage") ||
            ((lower.contains("नोटि") || lower.contains("notification")) && (lower.contains("सेटिंग") || lower.contains("setting")))
        ) {
            val appTarget = when {
                lower.contains("whatsapp") || lower.contains("व्हाट्स") -> "WhatsApp"
                lower.contains("instagram") || lower.contains("इंस्टा") -> "Instagram"
                lower.contains("facebook") || lower.contains("फेसबुक") -> "Facebook"
                lower.contains("youtube") || lower.contains("यूट्यूब") -> "YouTube"
                lower.contains("chrome") || lower.contains("क्रोम") -> "Chrome"
                else -> "Meera AI"
            }
            val fixArea = when {
                lower.contains("नोटि") || lower.contains("notification") -> "Notification"
                lower.contains("स्टोरेज") || lower.contains("storage") -> "Storage"
                else -> "Permission"
            }
            return JarvisCommandResult(
                intent = "APP_SETTINGS_FIX",
                targetApp = appTarget.lowercase(),
                action = "SYSTEM_APP_SETTINGS_FIX",
                parameters = mapOf("appName" to appTarget, "setting" to fixArea),
                spokenFeedback = "$appTarget की $fixArea सेटिंग खोल दी गई है।",
                steps = listOf("SystemControlManager.openAppSettingsFix($appTarget)"),
                isLocallyProcessed = true,
                responseStatus = "सुधारा गया",
                command = text,
                moduleAction = "system.app_settings_fix",
                targetPayload = "App: $appTarget | Section: $fixArea"
            )
        }

        // 10. Open Specific Settings Section (Language, Date-Time, Sound, Display, Network)
        if ((lower.contains("सेटिंग") || lower.contains("setting")) &&
            (lower.contains("भाषा") || lower.contains("language") || lower.contains("डेट") || lower.contains("टाइम") || lower.contains("date") || lower.contains("time") ||
                lower.contains("साउंड") || lower.contains("sound") || lower.contains("डिस्प्ले") || lower.contains("display") ||
                lower.contains("नेटवर्क") || lower.contains("network"))
        ) {
            val section = when {
                lower.contains("भाषा") || lower.contains("language") -> "language"
                lower.contains("डेट") || lower.contains("टाइम") || lower.contains("date") || lower.contains("time") -> "datetime"
                lower.contains("साउंड") || lower.contains("sound") -> "sound"
                lower.contains("डिस्प्ले") || lower.contains("display") -> "display"
                else -> "network"
            }
            return JarvisCommandResult(
                intent = "OPEN_SETTINGS_SECTION",
                targetApp = "settings",
                action = "OPEN_SETTINGS_SECTION",
                parameters = mapOf("settingsSection" to section),
                spokenFeedback = "फ़ोन की $section सेटिंग खोल दी गई है।",
                steps = listOf("SystemControlManager.openSettingsSection($section)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.open_settings_section",
                targetPayload = "Settings Section: $section"
            )
        }

        // 11. Brightness Control
        if (lower.contains("ब्राइटनेस") || lower.contains("brightness") || lower.contains("रोशनी") || lower.contains("उजाला")) {
            val isAuto = lower.contains("ऑटो") || lower.contains("auto")
            val valPct = when {
                isAuto -> -1
                lower.contains("फुल") || lower.contains("full") || lower.contains("बढ़ा") || lower.contains("तेज") || lower.contains("ज़्यादा") -> 95
                lower.contains("कम") || lower.contains("low") || lower.contains("धीम") -> 25
                else -> Regex("(\\d+)").find(lower)?.value?.toIntOrNull() ?: 70
            }
            return JarvisCommandResult(
                intent = "ADJUST_BRIGHTNESS",
                targetApp = "system",
                action = "SET_BRIGHTNESS",
                parameters = mapOf("value" to valPct, "auto" to isAuto),
                spokenFeedback = if (isAuto) "ब्राइटनेस ऑटो मोड पर सेट की गई।" else "ब्राइटनेस $valPct% सेट की गई।",
                steps = listOf(if (isAuto) "SystemControlManager.setBrightnessAuto()" else "SystemControlManager.setBrightness($valPct)"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.set_brightness",
                targetPayload = if (isAuto) "Brightness: Auto" else "Brightness: $valPct%"
            )
        }

        // 12. All 10 System Toggles (Wi-Fi, Bluetooth, Mobile Data, Hotspot, Location, Airplane, DND, Flashlight, Auto-Rotate, Battery Saver)
        val toggleMatches = listOf(
            Triple("hotspot", "Hotspot", listOf("hotspot", "हॉटस्पॉट", "हॉट स्पॉट")),
            Triple("mobile_data", "Mobile Data", listOf("mobile data", "मोबाइल डेटा", "डेटा", "इंटरनेट", "internet data")),
            Triple("location", "Location", listOf("location", "लोकेशन", "gps", "जीपीएस")),
            Triple("airplane_mode", "Airplane Mode", listOf("airplane", "flight mode", "एयरप्लेन", "फ्लाइट मोड", "फ़्लाइट मोड")),
            Triple("dnd", "Do Not Disturb", listOf("dnd", "do not disturb", "डू नॉट डिस्टर्ब")),
            Triple("auto_rotate", "Auto-Rotate", listOf("auto-rotate", "auto rotate", "ऑटो-रोटेट", "ऑटो रोटेट", "रोटेशन", "रोटेट")),
            Triple("battery_saver", "Battery Saver", listOf("battery saver", "बैटरी सेवर", "पावर सेविंग")),
            Triple("flashlight", "Flashlight", listOf("flashlight", "torch", "फ्लैशलाइट", "फ्लैश लाइट", "टॉर्च", "फ्लैश")),
            Triple("wifi", "Wi-Fi", listOf("wifi", "wi-fi", "वाई-फाई", "वाईफाई", "वाई फाई", "वाइफाई")),
            Triple("bluetooth", "Bluetooth", listOf("bluetooth", "ब्लूटूथ", "ब्लू टूथ"))
        )
        for ((key, label, keywords) in toggleMatches) {
            if (keywords.any { lower.contains(it) }) {
                val state = !lower.contains("off") && !lower.contains("band") && !lower.contains("बंद") &&
                    !lower.contains("बुझा") && !lower.contains("ऑफ") && !lower.contains("ऑफ़") && !lower.contains("disable")
                return JarvisCommandResult(
                    intent = "TOGGLE_SETTING",
                    targetApp = "system",
                    action = "TOGGLE_${key.uppercase()}",
                    parameters = mapOf("state" to state, "setting" to key),
                    spokenFeedback = if (state) "$label चालू कर दिया गया है।" else "$label बंद कर दिया गया है।",
                    steps = listOf("SystemControlManager.toggle($key, $state)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "system.toggle_setting",
                    targetPayload = "Setting: $label | State: ${if (state) "ON" else "OFF"}"
                )
            }
        }

        // 13. Volume (Media, Ring, Alarm, Call, Notification)
        if (lower.contains("volume") || lower.contains("sound") || lower.contains("awaaz") ||
            lower.contains("वॉल्यूम") || lower.contains("आवाज") || lower.contains("आवाज़") || lower.contains("साउंड")) {
            val stream = when {
                lower.contains("ring") || lower.contains("रिंग") -> "ring"
                lower.contains("alarm") || lower.contains("अलार्म") -> "alarm"
                lower.contains("call") || lower.contains("कॉल") -> "call"
                lower.contains("notification") || lower.contains("नोटि") -> "notification"
                else -> "media"
            }
            val numFound = Regex("(\\d+)").find(lower)?.value?.toIntOrNull()
            val delta = when {
                numFound != null -> 0
                lower.contains("बढ़ा") || lower.contains("तेज") || lower.contains("ज्यादा") || lower.contains("ज़्यादा") || lower.contains("up") -> 20
                lower.contains("कम") || lower.contains("धीम") || lower.contains("down") -> -20
                else -> 0
            }
            val level = when {
                lower.contains("म्यूट") || lower.contains("mute") || lower.contains("zero") -> 0
                lower.contains("फुल") || lower.contains("full") || lower.contains("max") -> 100
                numFound != null -> numFound.coerceIn(0, 100)
                else -> 70
            }
            return JarvisCommandResult(
                intent = "ADJUST_VOLUME",
                targetApp = "system",
                action = "SET_VOLUME",
                parameters = mapOf("value" to level, "volumeStream" to stream, "delta" to delta),
                spokenFeedback = if (delta != 0) "वॉल्यूम एडजस्ट किया गया।" else "${stream.replaceFirstChar { it.uppercase() }} वॉल्यूम $level% सेट किया गया।",
                steps = listOf("SystemControlManager.setVolume($level, \"$stream\")"),
                isLocallyProcessed = true,
                command = text,
                moduleAction = "system.set_volume",
                targetPayload = if (delta != 0) "Stream: $stream | Delta: $delta%" else "Stream: $stream | Volume: $level%"
            )
        }

        // 14. Launch Any App ("open youtube", "youtube kholo", "यूट्यूब खोलो", "कैमरा चलाओ", "सेटिंग खोलो")
        if (lower.startsWith("open ") || lower.startsWith("launch ") || lower.startsWith("start ") ||
            lower.contains("kholo") || lower.contains("खोलो") || lower.contains("खोल दो") ||
            lower.contains("खोलिए") || lower.contains("चलाओ") || lower.contains("ओपन")) {
            val appName = text
                .replace(Regex("^(open|launch|start)\\s+", RegexOption.IGNORE_CASE), "")
                .replace(Regex("(ऐप खोलो|ऐप खोल दो|ऐप|खोल दो|खोलो|खोलिए|चलाओ|ओपन करो|ओपन|kholo|chalao|meera|meira|app)", RegexOption.IGNORE_CASE), "")
                .trim()
            if (appName.isNotEmpty()) {
                return JarvisCommandResult(
                    intent = "LAUNCH_APP",
                    targetApp = appName,
                    action = "LAUNCH_INSTALLED_APP",
                    parameters = mapOf("appName" to appName),
                    spokenFeedback = "$appName खोल रही हूँ।",
                    steps = listOf("SystemControlManager.launchApp($appName)"),
                    isLocallyProcessed = true,
                    command = text,
                    moduleAction = "system.open_app",
                    targetPayload = "App: $appName"
                )
            }
        }

        // Strict NO COMMAND, NO ACTION Fallback
        return JarvisCommandResult(
            intent = "UNKNOWN",
            targetApp = null,
            action = "NO_COMMAND_NO_ACTION",
            parameters = emptyMap(),
            spokenFeedback = "स्पष्ट वॉयस आदेश नहीं मिला। कोई एक्शन नहीं लिया गया (NO COMMAND, NO ACTION)।",
            steps = listOf("Strict Voice-Only Mode: No unsolicited action triggered."),
            isLocallyProcessed = true,
            command = text,
            moduleAction = "idle.no_action",
            targetPayload = "NO COMMAND, NO ACTION"
        )
    }

    private fun queryGeminiApi(prompt: String): JarvisCommandResult {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-4-hydrogen:generateContent?key=$geminiApiKey"
        val jsonPayload = """
            {
              "contents": [{
                "parts": [{ "text": "Parse into Jarvis JSON: $prompt" }]
              }],
              "generationConfig": {
                "responseMimeType": "application/json"
              }
            }
        """.trimIndent()

        val request = Request.Builder()
            .url(url)
            .post(jsonPayload.toRequestBody("application/json".toMediaType()))
            .build()

        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
            val body = response.body?.string() ?: throw Exception("Empty response")
            val res = gson.fromJson(body, JarvisCommandResult::class.java)
            return res.copy(isLocallyProcessed = false)
        }
    }
}
