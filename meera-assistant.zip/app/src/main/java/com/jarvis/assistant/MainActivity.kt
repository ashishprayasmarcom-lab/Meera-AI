package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.ai.IntentParser
import com.jarvis.assistant.ai.JarvisCommandResult
import com.jarvis.assistant.control.SystemControlManager
import com.jarvis.assistant.overlay.JarvisOverlayManager
import com.jarvis.assistant.security.KillSwitchManager
import com.jarvis.assistant.service.VoiceAutomationService
import com.meira.assistant.control.MeeraCommandExecutor
import com.meira.assistant.phonefinder.FindMyPhoneManager
import com.meira.assistant.security.VoiceSpeakerAuthManager
import com.meira.assistant.service.MeiraWakeWordService
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var systemControl: SystemControlManager
    private lateinit var killSwitchManager: KillSwitchManager
    private lateinit var findMyPhoneManager: FindMyPhoneManager
    private lateinit var overlayManager: JarvisOverlayManager
    private lateinit var voiceAuthManager: VoiceSpeakerAuthManager
    private val intentParser = IntentParser()
    private var resumeTick by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        systemControl = SystemControlManager(this)
        killSwitchManager = KillSwitchManager(this)
        findMyPhoneManager = FindMyPhoneManager(this)
        overlayManager = JarvisOverlayManager(this)
        voiceAuthManager = VoiceSpeakerAuthManager(this)

        startHandsFreeServiceIfReady()

        setContent {
            var isKillSwitchEngaged by remember { mutableStateOf(KillSwitchManager.isEmergencyKilled) }
            var isAirGapMode by remember { mutableStateOf(MeiraWakeWordService.airGapLocalOnly) }
            var requireWakeWord by remember { mutableStateOf(MeiraWakeWordService.requireWakeWord) }
            var isWakeServiceActive by remember { mutableStateOf(MeiraWakeWordService.isServiceRunning) }
            var isOverlayVisible by remember { mutableStateOf(false) }
            var commandInput by remember { mutableStateOf("") }
            var isOwnerVoiceVerified by remember { mutableStateOf(MeiraWakeWordService.isOwnerVoiceVerified) }
            var lastStatus by remember { mutableStateOf("Face Lock & Fingerprint Active · Owner Voice Ready.") }
            var lastHeardLive by remember { mutableStateOf(MeiraWakeWordService.lastHeardPhrase) }
            var lastServiceSummary by remember { mutableStateOf(MeiraWakeWordService.lastExecutedSummary) }
            var lastCommandMeta by remember { mutableStateOf<JarvisCommandResult?>(null) }

            val tick = resumeTick
            var hasMicPerm by remember(tick) { mutableStateOf(checkPerm(Manifest.permission.RECORD_AUDIO)) }
            var hasCallPerm by remember(tick) { mutableStateOf(checkPerm(Manifest.permission.CALL_PHONE)) }
            var hasContactsPerm by remember(tick) { mutableStateOf(checkPerm(Manifest.permission.READ_CONTACTS)) }
            var isAccessibilityOn by remember(tick) { mutableStateOf(VoiceAutomationService.isRunning()) }
            var hasOverlayPerm by remember(tick) { mutableStateOf(Settings.canDrawOverlays(this)) }
            var hasWriteSettings by remember(tick) { mutableStateOf(Settings.System.canWrite(this)) }
            var isBatteryUnrestricted by remember(tick) { mutableStateOf(checkBatteryUnrestricted()) }

            DisposableEffect(Unit) {
                MeiraWakeWordService.onLiveUpdate = {
                    runOnUiThread {
                        isWakeServiceActive = MeiraWakeWordService.isServiceRunning
                        lastHeardLive = MeiraWakeWordService.lastHeardPhrase
                        lastServiceSummary = MeiraWakeWordService.lastExecutedSummary
                    }
                }
                onDispose {
                    MeiraWakeWordService.onLiveUpdate = null
                }
            }

            val permLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) {
                hasMicPerm = checkPerm(Manifest.permission.RECORD_AUDIO)
                hasCallPerm = checkPerm(Manifest.permission.CALL_PHONE)
                hasContactsPerm = checkPerm(Manifest.permission.READ_CONTACTS)
                if (hasMicPerm) {
                    startHandsFreeServiceIfReady()
                    isWakeServiceActive = true
                }
            }

            fun requestCorePermissions() {
                val perms = mutableListOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CONTACTS
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    perms.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    perms.add(Manifest.permission.BLUETOOTH_CONNECT)
                }
                permLauncher.launch(perms.toTypedArray())
            }

            fun runVoiceCommand(spokenText: String) {
                if (spokenText.isBlank()) return
                lifecycleScope.launch {
                    val result = intentParser.parseCommand(spokenText, isSpeakerVerified = isOwnerVoiceVerified)
                    lastCommandMeta = result
                    lastStatus = result.spokenFeedback
                    if (result.intent == "VOICE_SECURITY_ALERT") {
                        voiceAuthManager.dispatchUnverifiedVoiceAlert(spokenText)
                    } else if (result.intent != "UNKNOWN" && result.intent != "KILL_SWITCH") {
                        voiceAuthManager.unlockKeyguardForVerifiedVoice(this@MainActivity)
                        executeOnDevice(result)
                    }
                }
            }

            val voiceLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { res ->
                if (res.resultCode == Activity.RESULT_OK) {
                    val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                    if (!spoken.isNullOrBlank()) {
                        commandInput = spoken
                        runVoiceCommand(spoken)
                    }
                }
            }

            fun launchMicPrompt() {
                if (!hasMicPerm) {
                    requestCorePermissions()
                    return
                }
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("hi", "IN"))
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Meera ko command dein (e.g. YouTube kholo, Flashlight ON)")
                }
                try {
                    voiceLauncher.launch(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Voice input unavailable on this device", Toast.LENGTH_SHORT).show()
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF090D16))
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("MEERA AI OS ASSISTANT (मीरा)", color = Color(0xFF38BDF8), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Always-On Hands-Free · 100% Local Privacy · Find My Phone", color = Color.Gray, fontSize = 11.sp)

                Spacer(Modifier.height(14.dp))

                // LIVE HANDS-FREE STATUS BANNER
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isWakeServiceActive) Color(0xFF064E3B) else Color(0xFF7C2D12)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(
                            text = if (isWakeServiceActive)
                                "HANDS-FREE MIC ACTIVE (बिना टच के सुन रही हूँ)"
                            else
                                "HANDS-FREE LISTENER PAUSED — Mic परमिशन दें या Start दबाएँ",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (lastHeardLive.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text("Last Heard: \"$lastHeardLive\"", color = Color(0xFFA7F3D0), fontSize = 11.sp)
                        }
                        Spacer(Modifier.height(2.dp))
                        Text("Status: $lastServiceSummary", color = Color(0xFFE2E8F0), fontSize = 11.sp)
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 1. VOICE & TEXT COMMAND CENTER
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Hands-Free Voice-Secured Assistant", color = Color(0xFF38BDF8), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(voiceAuthManager.getBiometricCoexistenceStatus(), color = Color(0xFF34D399), fontSize = 10.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    isOwnerVoiceVerified = true
                                    MeiraWakeWordService.isOwnerVoiceVerified = true
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isOwnerVoiceVerified) Color(0xFF10B981) else Color(0xFF1E293B)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Owner (VERIFIED)", fontSize = 11.sp, color = Color.White)
                            }
                            Button(
                                onClick = {
                                    isOwnerVoiceVerified = false
                                    MeiraWakeWordService.isOwnerVoiceVerified = false
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (!isOwnerVoiceVerified) Color(0xFFDC2626) else Color(0xFF1E293B)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Unknown (ALERT)", fontSize = 11.sp, color = Color.White)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(lastStatus, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                        lastCommandMeta?.let { meta ->
                            Spacer(Modifier.height(8.dp))
                            Text("• Voice Status: ${meta.voiceStatus}", color = if (meta.intent == "VOICE_SECURITY_ALERT") Color(0xFFF87171) else Color(0xFF34D399), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("• Unlock & Biometric Mode: ${meta.unlockBiometricMode}", color = Color(0xFF22D3EE), fontSize = 11.sp)
                            Text("• Command: ${meta.command}", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Text("• Module & Action: ${meta.moduleAction}", color = Color(0xFF34D399), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("• Target & Payload: ${meta.targetPayload}", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                            Text("• Status: ${meta.responseStatus}", color = Color(0xFFFBBF24), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(10.dp))

                        OutlinedTextField(
                            value = commandInput,
                            onValueChange = { commandInput = it },
                            placeholder = { Text("Type or speak: YouTube kholo, Rahul ko call karo", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(Modifier.height(10.dp))

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { launchMicPrompt() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("One-Tap Mic", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { runVoiceCommand(commandInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Run Command", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 2. ALWAYS-ON BACKGROUND LISTENER, WAKE-WORD & FIND MY PHONE
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Always-On Background Listener & Orb", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Require 'Meera' Wake-Word Only", color = Color(0xFFE2E8F0), fontSize = 13.sp)
                                Text(
                                    if (requireWakeWord) "Sirf 'Meera ...' bolne par chalegi"
                                    else "OFF: Koi bhi seedha command bina touch ke chalega",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                            Switch(
                                checked = requireWakeWord,
                                onCheckedChange = {
                                    requireWakeWord = it
                                    MeiraWakeWordService.requireWakeWord = it
                                }
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    val svcIntent = Intent(this@MainActivity, MeiraWakeWordService::class.java)
                                    if (isWakeServiceActive) {
                                        stopService(svcIntent)
                                        isWakeServiceActive = false
                                    } else {
                                        if (!hasMicPerm) {
                                            requestCorePermissions()
                                        } else {
                                            ContextCompat.startForegroundService(this@MainActivity, svcIntent)
                                            isWakeServiceActive = true
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isWakeServiceActive) Color(0xFFF59E0B) else Color(0xFF3B82F6)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isWakeServiceActive) "Pause Listener" else "Start Hands-Free", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    if (FindMyPhoneManager.isAlertActive) {
                                        findMyPhoneManager.stopAlert()
                                    } else {
                                        findMyPhoneManager.triggerFindPhoneAlert()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEC4899)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Test/Stop Siren", fontSize = 12.sp)
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (!Settings.canDrawOverlays(this@MainActivity)) {
                                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                } else {
                                    if (isOverlayVisible) {
                                        overlayManager.removeOverlay()
                                        isOverlayVisible = false
                                    } else {
                                        overlayManager.showOverlay { launchMicPrompt() }
                                        isOverlayVisible = true
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isOverlayVisible) "Hide Floating Meera Orb" else "Show Floating Meera Orb")
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 3. ONE-TAP PERMISSIONS CHECKLIST
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Required Permissions Setup (Sirf 1 Baar)", color = Color(0xFF38BDF8), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))

                        Button(
                            onClick = { requestCorePermissions() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasMicPerm && hasCallPerm && hasContactsPerm) Color(0xFF059669) else Color(0xFF0284C7)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                if (hasMicPerm && hasCallPerm && hasContactsPerm)
                                    "1. Mic, Camera, Call & Contacts Granted"
                                else
                                    "1. Grant Mic, Call & Contacts (Required)"
                            )
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAccessibilityOn) Color(0xFF059669) else Color(0xFF2563EB)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isAccessibilityOn) "2. Accessibility Active (WhatsApp & Gestures)" else "2. Enable Accessibility Service")
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                hasOverlayPerm = Settings.canDrawOverlays(this@MainActivity)
                                if (!hasOverlayPerm) {
                                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                } else {
                                    Toast.makeText(this@MainActivity, "Overlay Already Granted!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasOverlayPerm) Color(0xFF059669) else Color(0xFF4F46E5)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (hasOverlayPerm) "3. Floating Window Granted" else "3. Grant Floating Window Permission")
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                if (!nm.isNotificationPolicyAccessGranted) {
                                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                                } else {
                                    Toast.makeText(this@MainActivity, "DND Bypass Already Granted!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("4. Allow DND Bypass (Find My Phone)")
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                if (!Settings.System.canWrite(this@MainActivity)) {
                                    startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                                } else {
                                    Toast.makeText(this@MainActivity, "Modify System Settings Granted!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (hasWriteSettings) Color(0xFF059669) else Color(0xFF334155)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (hasWriteSettings) "5. Modify System Settings Granted" else "5. Allow Brightness & Rotate Control")
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                if (!checkBatteryUnrestricted()) {
                                    try {
                                        startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                                    } catch (_: Exception) {
                                        startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                                    }
                                } else {
                                    Toast.makeText(this@MainActivity, "Battery Unrestricted Already Enabled!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isBatteryUnrestricted) Color(0xFF059669) else Color(0xFF334155)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isBatteryUnrestricted) "6. 24x7 Battery Unrestricted Active" else "6. Allow 24x7 Background Battery")
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 4. EMERGENCY KILL-SWITCH & AIR-GAP MODE
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isKillSwitchEngaged) Color(0xFF7F1D1D) else Color(0xFF1E293B)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            text = if (isKillSwitchEngaged) "KILL-SWITCH ACTIVE (AUTOMATION LOCKED)" else "EMERGENCY KILL-SWITCH",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (isKillSwitchEngaged) {
                                    killSwitchManager.resetKillSwitch()
                                    isKillSwitchEngaged = false
                                } else {
                                    killSwitchManager.triggerEmergencyKillSwitch()
                                    overlayManager.removeOverlay()
                                    isOverlayVisible = false
                                    isKillSwitchEngaged = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isKillSwitchEngaged) Color(0xFF10B981) else Color(0xFFDC2626)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isKillSwitchEngaged) "Re-arm Assistant" else "Trigger Instant Kill-Switch")
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("100% Local Air-Gap Mode", color = Color.White, fontSize = 14.sp)
                            Text("Zero cloud data transmission", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isAirGapMode,
                            onCheckedChange = {
                                isAirGapMode = it
                                intentParser.airGapLocalOnly = it
                                MeiraWakeWordService.airGapLocalOnly = it
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
        startHandsFreeServiceIfReady()
    }

    private fun startHandsFreeServiceIfReady() {
        if (checkPerm(Manifest.permission.RECORD_AUDIO) && !KillSwitchManager.isEmergencyKilled) {
            try {
                val svcIntent = Intent(this, MeiraWakeWordService::class.java)
                ContextCompat.startForegroundService(this, svcIntent)
            } catch (_: Exception) {}
        }
    }

    private fun checkBatteryUnrestricted(): Boolean {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pm.isIgnoringBatteryOptimizations(packageName)
        } else {
            true
        }
    }

    private fun checkPerm(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun executeOnDevice(result: JarvisCommandResult) {
        MeeraCommandExecutor.execute(
            context = this,
            result = result,
            systemControl = systemControl,
            findMyPhoneManager = findMyPhoneManager
        ) { msg ->
            runOnUiThread {
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
