package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarvis.assistant.ai.IntentParser
import com.jarvis.assistant.ai.JarvisCommandResult
import com.jarvis.assistant.control.SystemControlManager
import com.jarvis.assistant.overlay.JarvisOverlayManager
import com.jarvis.assistant.security.KillSwitchManager
import com.jarvis.assistant.service.VoiceAutomationService
import com.meira.assistant.phonefinder.FindMyPhoneManager
import com.meira.assistant.security.VoiceSpeakerAuthManager
import com.meira.assistant.service.MeiraWakeWordService
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : ComponentActivity() {

    private lateinit var systemControl: SystemControlManager
    private lateinit var killSwitchManager: KillSwitchManager
    private lateinit var findMyPhoneManager: FindMyPhoneManager
    private lateinit var overlayManager: JarvisOverlayManager
    private lateinit var voiceAuthManager: VoiceSpeakerAuthManager
    private val intentParser = IntentParser()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        systemControl = SystemControlManager(this)
        killSwitchManager = KillSwitchManager(this)
        findMyPhoneManager = FindMyPhoneManager(this)
        overlayManager = JarvisOverlayManager(this)
        voiceAuthManager = VoiceSpeakerAuthManager(this)

        setContent {
            var isKillSwitchEngaged by remember { mutableStateOf(KillSwitchManager.isEmergencyKilled) }
            var isAirGapMode by remember { mutableStateOf(true) }
            var isWakeServiceActive by remember { mutableStateOf(MeiraWakeWordService.isServiceRunning) }
            var isOverlayVisible by remember { mutableStateOf(false) }
            var commandInput by remember { mutableStateOf("") }
            var isOwnerVoiceVerified by remember { mutableStateOf(true) }
            var lastStatus by remember { mutableStateOf("Face Lock & Fingerprint Active · Owner Voice Ready.") }
            var lastCommandMeta by remember { mutableStateOf<JarvisCommandResult?>(null) }

            var hasMicPerm by remember { mutableStateOf(checkPerm(Manifest.permission.RECORD_AUDIO)) }
            var isAccessibilityOn by remember { mutableStateOf(VoiceAutomationService.isRunning()) }
            var hasOverlayPerm by remember { mutableStateOf(Settings.canDrawOverlays(this)) }

            val permLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) {
                hasMicPerm = checkPerm(Manifest.permission.RECORD_AUDIO)
            }

            fun runVoiceCommand(spokenText: String) {
                if (spokenText.isBlank()) return
                lifecycleScope.launch {
                    val result = intentParser.parseCommand(spokenText, isSpeakerVerified = isOwnerVoiceVerified)
                    lastCommandMeta = result
                    lastStatus = result.spokenFeedback
                    if (result.intent == "VOICE_SECURITY_ALERT") {
                        voiceAuthManager.dispatchUnverifiedVoiceAlert(spokenText)
                    } else if (result.intent != "UNKNOWN" && result.intent != "KILL_SWITCH") {
                        voiceAuthManager.unlockKeyguardForVerifiedVoice(this@MainActivity)
                        executeOnDevice(result)
                    }
                }
            }

            val voiceLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { res ->
                if (res.resultCode == Activity.RESULT_OK) {
                    val spoken = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                    if (!spoken.isNullOrBlank()) {
                        commandInput = spoken
                        runVoiceCommand(spoken)
                    }
                }
            }

            fun launchMicPrompt() {
                if (!hasMicPerm) {
                    val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        perms.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    permLauncher.launch(perms.toTypedArray())
                    return
                }
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("hi", "IN"))
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Meera ko command dein (e.g. Flashlight ON, Open YouTube)")
                }
                try {
                    voiceLauncher.launch(intent)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Voice input unavailable on emulator", Toast.LENGTH_SHORT).show()
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF090D16))
                    .padding(18.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("MEIRA AI OS ASSISTANT (मीरा)", color = Color(0xFF38BDF8), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("100% Local Privacy · Accessibility · Find My Phone", color = Color.Gray, fontSize = 11.sp)

                Spacer(Modifier.height(16.dp))

                // 1. VOICE & TEXT COMMAND CENTER
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Hands-Free Voice-Secured Assistant", color = Color(0xFF38BDF8), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Text(voiceAuthManager.getBiometricCoexistenceStatus(), color = Color(0xFF34D399), fontSize = 10.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { isOwnerVoiceVerified = true },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isOwnerVoiceVerified) Color(0xFF10B981) else Color(0xFF1E293B)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Owner (VERIFIED)", fontSize = 11.sp, color = Color.White)
                            }
                            Button(
                                onClick = { isOwnerVoiceVerified = false },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (!isOwnerVoiceVerified) Color(0xFFDC2626) else Color(0xFF1E293B)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Unknown (ALERT)", fontSize = 11.sp, color = Color.White)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(lastStatus, color = Color(0xFFE2E8F0), fontSize = 12.sp)
                        lastCommandMeta?.let { meta ->
                            Spacer(Modifier.height(8.dp))
                            Text("• Voice Status: ${meta.voiceStatus}", color = if (meta.intent == "VOICE_SECURITY_ALERT") Color(0xFFF87171) else Color(0xFF34D399), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("• Unlock & Biometric Mode: ${meta.unlockBiometricMode}", color = Color(0xFF22D3EE), fontSize = 11.sp)
                            Text("• Command: ${meta.command}", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Text("• Module & Action: ${meta.moduleAction}", color = Color(0xFF34D399), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("• Target & Payload: ${meta.targetPayload}", color = Color(0xFFCBD5E1), fontSize = 11.sp)
                            Text("• Status: ${meta.responseStatus}", color = Color(0xFFFBBF24), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(10.dp))

                        OutlinedTextField(
                            value = commandInput,
                            onValueChange = { commandInput = it },
                            placeholder = { Text("Type: Open WhatsApp, Flashlight ON, Where are you?", fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        Spacer(Modifier.height(10.dp))

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { launchMicPrompt() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF06B6D4)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Mic Speak", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { runVoiceCommand(commandInput) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Run Command", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 2. FIND MY PHONE & FLOATING ORB CONTROLS
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Background Listener & Find My Phone", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    val svcIntent = Intent(this@MainActivity, MeiraWakeWordService::class.java)
                                    if (isWakeServiceActive) {
                                        stopService(svcIntent)
                                        isWakeServiceActive = false
                                    } else {
                                        ContextCompat.startForegroundService(this@MainActivity, svcIntent)
                                        isWakeServiceActive = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isWakeServiceActive) Color(0xFFF59E0B) else Color(0xFF3B82F6)
                                ),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(if (isWakeServiceActive) "Stop Listener" else "Start Listener", fontSize = 12.sp)
                            }

                            Button(
                                onClick = {
                                    if (FindMyPhoneManager.isAlertActive) {
                                        findMyPhoneManager.stopAlert()
                                    } else {
                                        findMyPhoneManager.triggerFindPhoneAlert()
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEC4899)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Test/Stop Siren", fontSize = 12.sp)
                            }
                        }

                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (!Settings.canDrawOverlays(this@MainActivity)) {
                                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                } else {
                                    if (isOverlayVisible) {
                                        overlayManager.removeOverlay()
                                        isOverlayVisible = false
                                    } else {
                                        overlayManager.showOverlay { launchMicPrompt() }
                                        isOverlayVisible = true
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isOverlayVisible) "Hide Floating Meera Orb" else "Show Floating Meera Orb")
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 3. ONE-TAP PERMISSIONS CHECKLIST
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Required Permissions Setup", color = Color(0xFF38BDF8), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(8.dp))

                        Button(
                            onClick = {
                                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                                isAccessibilityOn = VoiceAutomationService.isRunning()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isAccessibilityOn) "Accessibility Active (Tap to manage)" else "1. Enable Accessibility Service")
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                val perms = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    perms.add(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                permLauncher.launch(perms.toTypedArray())
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (hasMicPerm) "Mic & Camera Granted" else "2. Grant Mic & Camera Access")
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                hasOverlayPerm = Settings.canDrawOverlays(this@MainActivity)
                                if (!hasOverlayPerm) {
                                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (hasOverlayPerm) "Overlay Permission Granted" else "3. Grant Floating Window Permission")
                        }
                        Spacer(Modifier.height(6.dp))

                        Button(
                            onClick = {
                                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                                if (!nm.isNotificationPolicyAccessGranted) {
                                    startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
                                } else {
                                    Toast.makeText(this@MainActivity, "DND Bypass Already Granted!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("4. Allow DND Bypass (Find My Phone)")
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                // 4. EMERGENCY KILL-SWITCH & AIR-GAP MODE
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isKillSwitchEngaged) Color(0xFF7F1D1D) else Color(0xFF1E293B)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            text = if (isKillSwitchEngaged) "KILL-SWITCH ACTIVE (AUTOMATION LOCKED)" else "EMERGENCY KILL-SWITCH",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (isKillSwitchEngaged) {
                                    killSwitchManager.resetKillSwitch()
                                    isKillSwitchEngaged = false
                                } else {
                                    killSwitchManager.triggerEmergencyKillSwitch()
                                    overlayManager.removeOverlay()
                                    isOverlayVisible = false
                                    isKillSwitchEngaged = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isKillSwitchEngaged) Color(0xFF10B981) else Color(0xFFDC2626)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isKillSwitchEngaged) "Re-arm Assistant" else "Trigger Instant Kill-Switch")
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF131D31)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("100% Local Air-Gap Mode", color = Color.White, fontSize = 14.sp)
                            Text("Zero cloud data transmission", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isAirGapMode,
                            onCheckedChange = {
                                isAirGapMode = it
                                intentParser.airGapLocalOnly = it
                            }
                        )
                    }
                }
            }
        }
    }

    private fun checkPerm(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun executeOnDevice(result: JarvisCommandResult) {
        if (KillSwitchManager.isEmergencyKilled) return
        val service = VoiceAutomationService.instance

        when (result.intent) {
            "FIND_MY_PHONE" -> findMyPhoneManager.triggerFindPhoneAlert()
            "STOP_ALARM" -> findMyPhoneManager.stopAlert()
            "FIX_SETTING" -> {
                val repaired = systemControl.fixBrokenSettings()
                Toast.makeText(this, "Repaired: ${repaired.joinToString(", ")}", Toast.LENGTH_LONG).show()
            }
            "APP_SETTINGS_FIX" -> {
                val appName = result.parameters?.get("appName")?.toString() ?: "App"
                systemControl.openAppSettingsFix(appName)
            }
            "OPEN_SETTINGS_SECTION" -> {
                val section = result.parameters?.get("settingsSection")?.toString() ?: "network"
                systemControl.openSettingsSection(section)
            }
            "TOGGLE_SETTING" -> {
                val setting = result.parameters?.get("setting")?.toString()
                val state = result.parameters?.get("state") as? Boolean ?: true
                when (setting) {
                    "flashlight" -> systemControl.setFlashlight(state)
                    "wifi" -> systemControl.setWifi(state)
                    "bluetooth" -> systemControl.setBluetooth(state)
                    "mobile_data" -> systemControl.openMobileDataSettings()
                    "hotspot" -> systemControl.openHotspotSettings()
                    "location" -> systemControl.openLocationSettings()
                    "airplane_mode" -> systemControl.openAirplaneModeSettings()
                    "dnd" -> systemControl.setDnd(state)
                    "auto_rotate" -> systemControl.setAutoRotate(state)
                    "battery_saver" -> systemControl.openBatterySaverSettings()
                }
            }
            "ADJUST_VOLUME" -> {
                val value = (result.parameters?.get("value") as? Number)?.toInt() ?: 70
                val stream = result.parameters?.get("volumeStream")?.toString() ?: "media"
                systemControl.setVolume(value, stream)
            }
            "ADJUST_BRIGHTNESS" -> {
                val isAuto = result.parameters?.get("auto") as? Boolean ?: false
                if (isAuto) {
                    systemControl.setBrightnessAuto()
                } else {
                    val value = (result.parameters?.get("value") as? Number)?.toInt() ?: 70
                    systemControl.setBrightness(value)
                }
            }
            "LAUNCH_APP" -> {
                val appName = result.parameters?.get("appName")?.toString() ?: ""
                if (service != null) {
                    service.universalController.launchAppByVoice(this, appName)
                } else {
                    packageManager.getLaunchIntentForPackage(
                        when {
                            appName.contains("whatsapp", true) -> "com.whatsapp"
                            appName.contains("insta", true) -> "com.instagram.android"
                            appName.contains("face", true) -> "com.facebook.katana"
                            else -> ""
                        }
                    )?.let { startActivity(it) }
                }
            }
            "OPEN_FEED" -> {
                val appName = result.targetApp ?: "instagram"
                service?.universalController?.launchAppByVoice(this, appName)
            }
            "OPEN_PROFILE" -> {
                val handle = result.parameters?.get("profileHandle")?.toString() ?: "instagram"
                val url = if (result.targetApp == "facebook") "https://www.facebook.com/$handle" else "https://www.instagram.com/$handle"
                systemControl.openUrl(url)
            }
            "OPEN_CHAT" -> {
                val contact = result.parameters?.get("contact")?.toString() ?: "Friend"
                service?.openWhatsAppChat(contact) { status ->
                    runOnUiThread { Toast.makeText(this, status, Toast.LENGTH_SHORT).show() }
                }
            }
            "READ_MESSAGES" -> {
                val contact = result.parameters?.get("contact")?.toString() ?: "Friend"
                service?.readLatestMessages(contact) { msgs ->
                    runOnUiThread {
                        val summary = if (msgs.isEmpty()) "No recent message nodes found" else msgs.joinToString(" | ")
                        Toast.makeText(this, "$contact: $summary", Toast.LENGTH_LONG).show()
                    }
                }
            }
            "MAKE_CALL" -> {
                val target = result.parameters?.get("contact")?.toString() ?: ""
                if (target.isNotEmpty()) systemControl.makeCall(target)
            }
            "SET_ALARM" -> {
                val hour = (result.parameters?.get("hour") as? Number)?.toInt() ?: 6
                val minute = (result.parameters?.get("minute") as? Number)?.toInt() ?: 30
                systemControl.setAlarm(hour, minute, "Meera Voice Alarm")
            }
            "SET_REMINDER" -> {
                val title = result.parameters?.get("reminderText")?.toString() ?: "Reminder"
                systemControl.setReminder(title)
            }
            "SEARCH_IN_APP" -> {
                val query = result.parameters?.get("searchQuery")?.toString() ?: ""
                if (result.targetApp == "facebook") {
                    systemControl.openUrl("https://www.facebook.com/search/top?q=${Uri.encode(query)}")
                } else {
                    systemControl.openWebSearch(query)
                }
            }
            "GESTURE_SWIPE" -> {
                val dir = result.parameters?.get("direction")?.toString() ?: "up"
                service?.swipeVertical(directionUp = dir == "up")
            }
            "GLOBAL_ACTION" -> {
                when (result.parameters?.get("type")?.toString()) {
                    "back" -> service?.universalController?.goBack()
                    "home" -> service?.universalController?.goHome()
                    "screenshot" -> service?.universalController?.takeScreenshot()
                }
            }
            "SEND_MESSAGE" -> {
                val contact = result.parameters?.get("contact")?.toString() ?: "Friend"
                val msg = result.parameters?.get("messageText")?.toString() ?: "Hello"
                if (result.targetApp == "instagram" || result.targetApp == "facebook") {
                    service?.universalController?.launchAppByVoice(this, result.targetApp ?: "instagram")
                    Toast.makeText(this, "${result.targetApp} DM ready for $contact", Toast.LENGTH_SHORT).show()
                } else {
                    service?.automateWhatsAppMessage(contact, msg) { status ->
                        runOnUiThread { Toast.makeText(this, status, Toast.LENGTH_SHORT).show() }
                    }
                }
            }
        }
    }
}
