package com.jarvis.assistant.security

import android.content.Context
import android.content.Intent
import android.util.Log
import com.jarvis.assistant.overlay.JarvisOverlayManager
import com.jarvis.assistant.service.VoiceAutomationService

/**
 * Hardware & Software Kill-Switch for Jarvis Assistant.
 * When triggered by user:
 * 1. Invokes AccessibilityService.disableSelf() to immediately revoke OS service status.
 * 2. Destroys all WindowManager overlay views.
 * 3. Kills any background coroutines, microphones, or intent parsers.
 */
class KillSwitchManager(private val context: Context) {

    companion object {
        private const val TAG = "JarvisKillSwitch"
        var isEmergencyKilled: Boolean = false
            private set
    }

    /**
     * Instantly terminates all accessibility and automation routines.
     */
    fun triggerEmergencyKillSwitch() {
        Log.w(TAG, "EMERGENCY KILL-SWITCH ENGAGED BY USER!")
        isEmergencyKilled = true

        try {
            // 1. Terminate AccessibilityService via native OS disableSelf() API
            VoiceAutomationService.instance?.let { service ->
                Log.i(TAG, "Calling VoiceAutomationService.disableSelf()...")
                service.disableSelf()
            }

            // 2. Broadcast kill status scoped strictly to our package
            val killIntent = Intent("com.jarvis.assistant.ACTION_KILL_SWITCH_ENGAGED").apply {
                setPackage(context.packageName)
            }
            context.sendBroadcast(killIntent)

        } catch (e: Exception) {
            Log.e(TAG, "Error executing emergency kill-switch", e)
        }
    }

    fun resetKillSwitch() {
        isEmergencyKilled = false
        Log.i(TAG, "Kill-Switch disengaged. User can re-enable Accessibility Service in Settings.")
    }
}
