package com.jarvis.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.assistant.automation.UniversalAppController
import com.jarvis.assistant.security.KillSwitchManager
import com.jarvis.assistant.security.SecurityPolicyManager

/**
 * Hardened Autonomous Accessibility Service for Jarvis AI Assistant.
 * Built with strict privacy & security sandboxing:
 * - Immediate abort if active window belongs to a financial/banking package.
 * - Password & PIN node shielding (zero credential reading).
 * - Emergency self-termination via disableSelf().
 */
class VoiceAutomationService : AccessibilityService() {

    companion object {
        private const val TAG = "JarvisAutomation"
        var instance: VoiceAutomationService? = null
            private set

        fun isRunning(): Boolean = instance != null && !KillSwitchManager.isEmergencyKilled
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var screenWidth: Int = 1080
    private var screenHeight: Int = 2400
    private var currentPackage: String = ""
    lateinit var universalController: UniversalAppController
        private set

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (KillSwitchManager.isEmergencyKilled) {
            Log.w(TAG, "Kill switch is active. Disabling service immediately.")
            disableSelf()
            return
        }
        instance = this
        val metrics: DisplayMetrics = resources.displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        universalController = UniversalAppController(this, screenWidth, screenHeight)
        Log.d(TAG, "Secure VoiceAutomationService connected. Screen: ${screenWidth}x${screenHeight}")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Enforce real-time package boundary checking
        event?.packageName?.let { pkg ->
            currentPackage = pkg.toString()
            if (SecurityPolicyManager.isAppBlacklisted(currentPackage)) {
                // If user switches to banking app, completely purge references
                Log.w(TAG, "User opened protected app '$currentPackage'. Automation locked.")
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.d(TAG, "VoiceAutomationService destroyed")
    }

    // -------------------------------------------------------------
    // 1. SECURE GESTURE AUTOMATION (REELS, SWIPES)
    // -------------------------------------------------------------

    fun swipeVertical(
        directionUp: Boolean = true,
        durationMs: Long = 280L,
        onComplete: (() -> Unit)? = null
    ) {
        if (KillSwitchManager.isEmergencyKilled) {
            Log.e(TAG, "Action rejected: Kill-Switch is active.")
            return
        }
        if (SecurityPolicyManager.isAppBlacklisted(currentPackage)) {
            Log.e(TAG, "Gesture rejected: Protected app in foreground.")
            return
        }

        val centerX = screenWidth / 2f
        val startY = if (directionUp) screenHeight * 0.72f else screenHeight * 0.28f
        val endY = if (directionUp) screenHeight * 0.22f else screenHeight * 0.78f

        val swipePath = Path().apply {
            moveTo(centerX, startY)
            lineTo(centerX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(swipePath, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                onComplete?.invoke()
            }
        }, null)
    }

    // -------------------------------------------------------------
    // 2. PRIVACY-SHIELDED NODE INTERACTION
    // -------------------------------------------------------------

    fun clickNodeSecure(node: AccessibilityNodeInfo?): Boolean {
        if (!SecurityPolicyManager.isNodeSecureForInteraction(node)) {
            return false
        }
        var current = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    fun injectTextSecure(node: AccessibilityNodeInfo?, text: String): Boolean {
        val target = node ?: return false
        // Mandatory password shielding check
        if (!SecurityPolicyManager.isNodeSecureForInteraction(target)) {
            Log.e(TAG, "SECURITY BREACH BLOCKED: Attempted text injection into password/PIN field.")
            return false
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // -------------------------------------------------------------
    // 3. WHATSAPP AUTOMATION MACRO
    // -------------------------------------------------------------

    fun automateWhatsAppMessage(
        contactName: String,
        messageText: String,
        onStatus: (String) -> Unit
    ) {
        if (KillSwitchManager.isEmergencyKilled) {
            onStatus("BLOCKED: Kill-Switch active.")
            return
        }

        onStatus("1/6: Opening WhatsApp...")
        val launchIntent = packageManager.getLaunchIntentForPackage("com.whatsapp")?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } ?: run {
            onStatus("WhatsApp is not installed.")
            return
        }
        startActivity(launchIntent)

        mainHandler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val searchBtn = findNodeRecursive(root) { node ->
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                id.contains("menuitem_search") || id.contains("search_bar") ||
                    (node.isClickable && (desc.contains("search") || desc.contains("खोज")))
            } ?: universalController.findNodeBySemanticRole(root, com.jarvis.assistant.automation.SemanticRole.SEARCH_BUTTON)

            if (searchBtn != null && clickNodeSecure(searchBtn)) {
                mainHandler.postDelayed({
                    val searchEdit = findNodeRecursive(rootInActiveWindow) { node ->
                        node.className == "android.widget.EditText"
                    }
                    if (searchEdit != null) {
                        injectTextSecure(searchEdit, contactName)
                        mainHandler.postDelayed({
                            val contactItem = findNodeRecursive(rootInActiveWindow) { node ->
                                node.text?.contains(contactName, ignoreCase = true) == true
                            }
                            if (contactItem != null) {
                                clickNodeSecure(contactItem)
                                mainHandler.postDelayed({
                                    val messageBox = findNodeRecursive(rootInActiveWindow) { node ->
                                        node.className == "android.widget.EditText" ||
                                        node.viewIdResourceName?.contains("entry") == true
                                    }
                                    if (messageBox != null) {
                                        injectTextSecure(messageBox, messageText)
                                        mainHandler.postDelayed({
                                            val sendBtn = findNodeRecursive(rootInActiveWindow) { node ->
                                                val id = node.viewIdResourceName?.lowercase() ?: ""
                                                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                                                id.contains("send") || (node.isClickable && desc.contains("send"))
                                            }
                                            if (sendBtn != null && clickNodeSecure(sendBtn)) {
                                                onStatus("SUCCESS: Message sent securely.")
                                            }
                                        }, 700)
                                    }
                                }, 1100)
                            }
                        }, 1300)
                    }
                }, 800)
            }
        }, 1500)
    }

    fun openWhatsAppChat(contactName: String, onStatus: (String) -> Unit) {
        if (KillSwitchManager.isEmergencyKilled) {
            onStatus("BLOCKED: Kill-Switch active.")
            return
        }
        onStatus("Opening WhatsApp chat with $contactName...")
        val launchIntent = packageManager.getLaunchIntentForPackage("com.whatsapp")?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } ?: run {
            onStatus("WhatsApp is not installed.")
            return
        }
        startActivity(launchIntent)
        mainHandler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val searchBtn = findNodeRecursive(root) { node ->
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                id.contains("menuitem_search") || id.contains("search_bar") ||
                    (node.isClickable && (desc.contains("search") || desc.contains("खोज")))
            } ?: universalController.findNodeBySemanticRole(root, com.jarvis.assistant.automation.SemanticRole.SEARCH_BUTTON)

            if (searchBtn != null && clickNodeSecure(searchBtn)) {
                mainHandler.postDelayed({
                    val searchEdit = findNodeRecursive(rootInActiveWindow) { node ->
                        node.className == "android.widget.EditText"
                    }
                    if (searchEdit != null) {
                        injectTextSecure(searchEdit, contactName)
                        mainHandler.postDelayed({
                            val contactItem = findNodeRecursive(rootInActiveWindow) { node ->
                                node.text?.contains(contactName, ignoreCase = true) == true
                            }
                            if (contactItem != null && clickNodeSecure(contactItem)) {
                                onStatus("Opened chat with $contactName")
                            }
                        }, 1100)
                    }
                }, 700)
            }
        }, 1400)
    }

    fun readLatestMessages(contactName: String, onMessagesFound: (List<String>) -> Unit) {
        openWhatsAppChat(contactName) {
            mainHandler.postDelayed({
                val root = rootInActiveWindow
                val texts = mutableListOf<String>()
                collectMessageTexts(root, texts)
                onMessagesFound(texts.takeLast(3))
            }, 2200)
        }
    }

    private fun collectMessageTexts(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null || !SecurityPolicyManager.isNodeSecureForInteraction(node)) return
        val idRes = node.viewIdResourceName?.lowercase() ?: ""
        val txt = node.text?.toString()?.trim()
        if (!txt.isNullOrEmpty() && (idRes.contains("message_text") || node.className == "android.widget.TextView")) {
            if (txt.length > 2 && !txt.contains("Type a message", ignoreCase = true)) {
                out.add(txt)
            }
        }
        for (i in 0 until node.childCount) {
            collectMessageTexts(node.getChild(i), out)
        }
    }

    private fun findNodeRecursive(
        root: AccessibilityNodeInfo?,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        val node = root ?: return null
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val result = findNodeRecursive(child, predicate)
            if (result != null) return result
        }
        return null
    }

    // -------------------------------------------------------------
    // 4. EMERGENCY KILL-SWITCH METHOD
    // -------------------------------------------------------------

    fun killServiceInstantly() {
        Log.w(TAG, "killServiceInstantly() triggered. Calling disableSelf().")
        disableSelf()
    }
}
