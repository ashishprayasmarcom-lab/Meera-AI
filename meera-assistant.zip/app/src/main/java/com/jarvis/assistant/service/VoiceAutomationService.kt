package com.jarvis.assistant.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Path
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import com.jarvis.assistant.automation.UniversalAppController
import com.jarvis.assistant.control.SystemControlManager
import com.jarvis.assistant.security.KillSwitchManager
import com.jarvis.assistant.security.SecurityPolicyManager
import com.meira.assistant.service.MeiraWakeWordService

/**
 * Hardened Autonomous Accessibility Service for Jarvis AI Assistant.
 * Built with strict privacy & security sandboxing:
 * - Immediate abort if active window belongs to a financial/banking package.
 * - Password & PIN node shielding (zero credential reading).
 * - Emergency self-termination via disableSelf().
 */
class VoiceAutomationService : AccessibilityService() {

    companion object {
        private const val TAG = "JarvisAutomation"
        var instance: VoiceAutomationService? = null
            private set

        fun isRunning(): Boolean = instance != null && !KillSwitchManager.isEmergencyKilled
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var screenWidth: Int = 1080
    private var screenHeight: Int = 2400
    private var currentPackage: String = ""
    lateinit var universalController: UniversalAppController
        private set

    override fun onCreate() {
        super.onCreate()
        try {
            universalController = UniversalAppController(this, screenWidth, screenHeight)
        } catch (t: Throwable) {
            Log.e(TAG, "Error in onCreate: ${t.message}")
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            if (KillSwitchManager.isEmergencyKilled) {
                Log.w(TAG, "Kill switch is active. Disabling service immediately.")
                disableSelf()
                return
            }
            instance = this
            val metrics: DisplayMetrics = resources.displayMetrics
            screenWidth = metrics.widthPixels.coerceAtLeast(720)
            screenHeight = metrics.heightPixels.coerceAtLeast(1280)
            universalController = UniversalAppController(this, screenWidth, screenHeight)
            Log.d(TAG, "Secure VoiceAutomationService connected. Screen: ${screenWidth}x${screenHeight}")

            // Safely wake background listener when allowed (never throw across Accessibility binder)
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED &&
                !MeiraWakeWordService.isServiceRunning
            ) {
                mainHandler.postDelayed({
                    try {
                        if (!MeiraWakeWordService.isServiceRunning && !KillSwitchManager.isEmergencyKilled) {
                            ContextCompat.startForegroundService(this, Intent(this, MeiraWakeWordService::class.java))
                        }
                    } catch (t: Throwable) {
                        Log.w(TAG, "Deferred wake service start skipped: ${t.message}")
                    }
                }, 400L)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "onServiceConnected recovered safely: ${t.message}")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try {
            // Enforce real-time package boundary checking
            event?.packageName?.let { pkg ->
                currentPackage = pkg.toString()
                if (SecurityPolicyManager.isAppBlacklisted(currentPackage)) {
                    Log.w(TAG, "User opened protected app '$currentPackage'. Automation locked.")
                }
            }
        } catch (_: Throwable) {}
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        mainHandler.removeCallbacksAndMessages(null)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        mainHandler.removeCallbacksAndMessages(null)
        Log.d(TAG, "VoiceAutomationService destroyed")
    }

    // -------------------------------------------------------------
    // 1. SECURE GESTURE AUTOMATION (REELS, SWIPES)
    // -------------------------------------------------------------

    fun swipeVertical(
        directionUp: Boolean = true,
        durationMs: Long = 280L,
        onComplete: (() -> Unit)? = null
    ) {
        if (KillSwitchManager.isEmergencyKilled) {
            Log.e(TAG, "Action rejected: Kill-Switch is active.")
            return
        }
        if (SecurityPolicyManager.isAppBlacklisted(currentPackage)) {
            Log.e(TAG, "Gesture rejected: Protected app in foreground.")
            return
        }

        val centerX = screenWidth / 2f
        val startY = if (directionUp) screenHeight * 0.78f else screenHeight * 0.24f
        val endY = if (directionUp) screenHeight * 0.18f else screenHeight * 0.80f

        val swipePath = Path().apply {
            moveTo(centerX, startY)
            lineTo(centerX, endY)
        }

        val stroke = GestureDescription.StrokeDescription(swipePath, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                onComplete?.invoke()
            }
        }, null)
    }

    // -------------------------------------------------------------
    // 2. PRIVACY-SHIELDED NODE INTERACTION
    // -------------------------------------------------------------

    fun clickNodeSecure(node: AccessibilityNodeInfo?): Boolean {
        if (!SecurityPolicyManager.isNodeSecureForInteraction(node)) {
            return false
        }
        var current = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    fun injectTextSecure(node: AccessibilityNodeInfo?, text: String): Boolean {
        val target = node ?: return false
        // Mandatory password shielding check
        if (!SecurityPolicyManager.isNodeSecureForInteraction(target)) {
            Log.e(TAG, "SECURITY BREACH BLOCKED: Attempted text injection into password/PIN field.")
            return false
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // -------------------------------------------------------------
    // 3. WHATSAPP AUTOMATION MACRO
    // -------------------------------------------------------------

    private fun resolveWhatsAppPackage(): String? {
        return listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull { pkg ->
            packageManager.getLaunchIntentForPackage(pkg) != null
        }
    }

    private fun findWhatsAppSendButton(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        return findNodeRecursive(root) { node ->
            val id = node.viewIdResourceName?.lowercase() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            id.contains("send") ||
                (node.isClickable && (desc == "send" || desc.contains("send") || desc.contains("भेज")))
        } ?: root?.let {
            universalController.findNodeBySemanticRole(it, com.jarvis.assistant.automation.SemanticRole.SEND_BUTTON)
        }
    }

    private fun attemptSendInWhatsAppChat(
        messageText: String,
        attempt: Int = 0,
        onStatus: (String) -> Unit
    ) {
        val root = rootInActiveWindow
        val sendBtn = findWhatsAppSendButton(root)
        if (sendBtn != null && clickNodeSecure(sendBtn)) {
            onStatus("SUCCESS: WhatsApp message sent silently.")
            return
        }

        val messageBox = findNodeRecursive(root) { node ->
            val id = node.viewIdResourceName?.lowercase() ?: ""
            (node.className == "android.widget.EditText" && (id.contains("entry") || !id.contains("search"))) ||
                id.contains("entry")
        }
        if (messageBox != null) {
            val currentTxt = messageBox.text?.toString()?.trim() ?: ""
            if (!currentTxt.equals(messageText.trim(), ignoreCase = true)) {
                injectTextSecure(messageBox, messageText)
            }
            mainHandler.postDelayed({
                val sendAfter = findWhatsAppSendButton(rootInActiveWindow)
                if (sendAfter != null && clickNodeSecure(sendAfter)) {
                    onStatus("SUCCESS: WhatsApp message sent silently.")
                } else if (attempt < 2) {
                    attemptSendInWhatsAppChat(messageText, attempt + 1, onStatus)
                }
            }, 650L)
        } else if (attempt < 3) {
            mainHandler.postDelayed({
                attemptSendInWhatsAppChat(messageText, attempt + 1, onStatus)
            }, 750L)
        }
    }

    fun automateWhatsAppMessage(
        contactName: String,
        messageText: String,
        onStatus: (String) -> Unit
    ) {
        if (KillSwitchManager.isEmergencyKilled) {
            onStatus("BLOCKED: Kill-Switch active.")
            return
        }

        val waPkg = resolveWhatsAppPackage() ?: run {
            onStatus("WhatsApp is not installed.")
            return
        }

        // Fast direct path: if phone number resolves from Contacts, jump straight to chat & auto-click Send
        val resolvedPhone = try {
            SystemControlManager(this).resolveContactPhone(contactName)
        } catch (_: Exception) {
            null
        }?.filter { it.isDigit() }

        if (!resolvedPhone.isNullOrEmpty() && resolvedPhone.length >= 7) {
            val cleanNum = if (resolvedPhone.length == 10) "91$resolvedPhone" else resolvedPhone
            try {
                val directIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://api.whatsapp.com/send?phone=$cleanNum&text=${Uri.encode(messageText)}")
                ).apply {
                    setPackage(waPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                startActivity(directIntent)
                onStatus("Sending WhatsApp message directly to $contactName...")
                mainHandler.postDelayed({
                    attemptSendInWhatsAppChat(messageText, 0, onStatus)
                }, 1450L)
                return
            } catch (_: Exception) {}
        }

        // UI Search fallback path (works even without Contacts permission or for WhatsApp-only nicknames)
        onStatus("1/6: Opening WhatsApp...")
        val launchIntent = packageManager.getLaunchIntentForPackage(waPkg)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        } ?: return
        startActivity(launchIntent)

        fun trySearchAndSend(retry: Int) {
            val root = rootInActiveWindow
            if (root == null) {
                if (retry < 2) mainHandler.postDelayed({ trySearchAndSend(retry + 1) }, 700L)
                return
            }
            val searchBtn = findNodeRecursive(root) { node ->
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                id.contains("menuitem_search") || id.contains("search_bar") ||
                    (node.isClickable && (desc.contains("search") || desc.contains("खोज")))
            } ?: universalController.findNodeBySemanticRole(root, com.jarvis.assistant.automation.SemanticRole.SEARCH_BUTTON)

            if (searchBtn != null && clickNodeSecure(searchBtn)) {
                mainHandler.postDelayed({
                    val searchEdit = findNodeRecursive(rootInActiveWindow) { node ->
                        node.className == "android.widget.EditText"
                    }
                    if (searchEdit != null) {
                        injectTextSecure(searchEdit, contactName)
                        mainHandler.postDelayed({
                            // Skip EditText itself so we click the actual contact row
                            val contactItem = findNodeRecursive(rootInActiveWindow) { node ->
                                node.className != "android.widget.EditText" &&
                                    node.text?.contains(contactName, ignoreCase = true) == true
                            }
                            if (contactItem != null && clickNodeSecure(contactItem)) {
                                mainHandler.postDelayed({
                                    attemptSendInWhatsAppChat(messageText, 0, onStatus)
                                }, 950L)
                            }
                        }, 1250L)
                    }
                }, 700L)
            } else if (retry < 2) {
                mainHandler.postDelayed({ trySearchAndSend(retry + 1) }, 700L)
            }
        }

        mainHandler.postDelayed({ trySearchAndSend(0) }, 1350L)
    }

    fun openWhatsAppChat(contactName: String, onStatus: (String) -> Unit) {
        if (KillSwitchManager.isEmergencyKilled) {
            onStatus("BLOCKED: Kill-Switch active.")
            return
        }
        val waPkg = resolveWhatsAppPackage() ?: run {
            onStatus("WhatsApp is not installed.")
            return
        }
        onStatus("Opening WhatsApp chat with $contactName...")
        val launchIntent = packageManager.getLaunchIntentForPackage(waPkg)?.apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } ?: return
        startActivity(launchIntent)
        mainHandler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val searchBtn = findNodeRecursive(root) { node ->
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                id.contains("menuitem_search") || id.contains("search_bar") ||
                    (node.isClickable && (desc.contains("search") || desc.contains("खोज")))
            } ?: universalController.findNodeBySemanticRole(root, com.jarvis.assistant.automation.SemanticRole.SEARCH_BUTTON)

            if (searchBtn != null && clickNodeSecure(searchBtn)) {
                mainHandler.postDelayed({
                    val searchEdit = findNodeRecursive(rootInActiveWindow) { node ->
                        node.className == "android.widget.EditText"
                    }
                    if (searchEdit != null) {
                        injectTextSecure(searchEdit, contactName)
                        mainHandler.postDelayed({
                            val contactItem = findNodeRecursive(rootInActiveWindow) { node ->
                                node.className != "android.widget.EditText" &&
                                    node.text?.contains(contactName, ignoreCase = true) == true
                            }
                            if (contactItem != null && clickNodeSecure(contactItem)) {
                                onStatus("Opened chat with $contactName")
                            }
                        }, 1100L)
                    }
                }, 700L)
            }
        }, 1400L)
    }

    fun readLatestMessages(contactName: String, onMessagesFound: (List<String>) -> Unit) {
        openWhatsAppChat(contactName) {
            mainHandler.postDelayed({
                val root = rootInActiveWindow
                val texts = mutableListOf<String>()
                collectMessageTexts(root, texts)
                onMessagesFound(texts.takeLast(3))
            }, 2200)
        }
    }

    private fun collectMessageTexts(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null || !SecurityPolicyManager.isNodeSecureForInteraction(node)) return
        val idRes = node.viewIdResourceName?.lowercase() ?: ""
        val txt = node.text?.toString()?.trim()
        if (!txt.isNullOrEmpty() && (idRes.contains("message_text") || node.className == "android.widget.TextView")) {
            if (txt.length > 2 && !txt.contains("Type a message", ignoreCase = true)) {
                out.add(txt)
            }
        }
        for (i in 0 until node.childCount) {
            collectMessageTexts(node.getChild(i), out)
        }
    }

    private fun findNodeRecursive(
        root: AccessibilityNodeInfo?,
        predicate: (AccessibilityNodeInfo) -> Boolean
    ): AccessibilityNodeInfo? {
        val node = root ?: return null
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            val result = findNodeRecursive(child, predicate)
            if (result != null) return result
        }
        return null
    }

    fun autoClickFirstYouTubeResult() {
        if (KillSwitchManager.isEmergencyKilled) return
        try { SystemControlManager(this).ensureMediaUnmuted() } catch (_: Exception) {}

        val ensureUnmuteAndPlayYouTube = {
            val r = rootInActiveWindow
            val p = r?.packageName?.toString()?.lowercase() ?: ""
            if (r != null && p.contains("youtube") && !SecurityPolicyManager.isAppBlacklisted(p)) {
                val unmuteNode = findNodeRecursive(r) { node ->
                    val id = node.viewIdResourceName?.lowercase() ?: ""
                    val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                    val txt = node.text?.toString()?.lowercase() ?: ""
                    node.isClickable && (
                        desc.contains("unmute") || txt.contains("unmute") ||
                            desc.contains("tap to unmute") || txt.contains("tap to unmute") ||
                            id.contains("unmute")
                    )
                }
                if (unmuteNode != null) clickNodeSecure(unmuteNode)

                val playNode = findNodeRecursive(r) { node ->
                    val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                    node.isClickable && (desc == "play" || desc == "play video" || desc.contains("play video"))
                }
                if (playNode != null) clickNodeSecure(playNode)
            }
        }

        mainHandler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val pkg = root.packageName?.toString()?.lowercase() ?: ""
            if (SecurityPolicyManager.isAppBlacklisted(pkg) || !pkg.contains("youtube")) return@postDelayed

            val candidate = findNodeRecursive(root) { node ->
                val id = node.viewIdResourceName?.lowercase() ?: ""
                val rect = android.graphics.Rect()
                node.getBoundsInScreen(rect)
                val belowHeader = rect.top > (screenHeight * 0.16f) && rect.height() > 130
                node.isClickable && belowHeader &&
                    (id.contains("thumbnail") || id.contains("video") || id.contains("title") ||
                        (node.childCount > 0 && rect.width() > screenWidth * 0.45f))
            }
            if (candidate != null) {
                clickNodeSecure(candidate)
            }
            mainHandler.postDelayed({ ensureUnmuteAndPlayYouTube() }, 1200L)
            mainHandler.postDelayed({ ensureUnmuteAndPlayYouTube() }, 2500L)
        }, 1500L)
    }

    fun autoPlayAndUnmuteInstagram(openReelsTab: Boolean = false) {
        if (KillSwitchManager.isEmergencyKilled) return
        try { SystemControlManager(this).ensureMediaUnmuted() } catch (_: Exception) {}

        val runInstagramPass = { trySwitchToReels: Boolean ->
            val root = rootInActiveWindow
            val pkg = root?.packageName?.toString()?.lowercase() ?: ""
            if (root != null && pkg.contains("instagram") && !SecurityPolicyManager.isAppBlacklisted(pkg)) {
                try { SystemControlManager(this).ensureMediaUnmuted() } catch (_: Exception) {}

                if (trySwitchToReels) {
                    val reelsTab = findNodeRecursive(root) { node ->
                        val id = node.viewIdResourceName?.lowercase() ?: ""
                        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                        val txt = node.text?.toString()?.lowercase() ?: ""
                        node.isClickable && (id.contains("clips_tab") || desc == "reels" || desc.contains("reels") || txt == "reels")
                    }
                    if (reelsTab != null) {
                        clickNodeSecure(reelsTab)
                    }
                }

                val unmuteNode = findNodeRecursive(root) { node ->
                    val id = node.viewIdResourceName?.lowercase() ?: ""
                    val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                    val txt = node.text?.toString()?.lowercase() ?: ""
                    (node.isClickable && (
                        desc.contains("sound off") || desc.contains("muted") ||
                            desc.contains("tap for sound") || desc.contains("turn on sound") ||
                            desc.contains("unmute") || txt.contains("tap for sound") ||
                            id.contains("audio_icon") || id.contains("volume_indicator") || id.contains("mute")
                    ))
                }
                if (unmuteNode != null) {
                    clickNodeSecure(unmuteNode)
                }

                val playBtn = findNodeRecursive(root) { node ->
                    val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                    node.isClickable && (desc == "play" || desc.contains("play video") || desc.contains("play reel"))
                }
                if (playBtn != null) {
                    clickNodeSecure(playBtn)
                }
            }
        }

        mainHandler.postDelayed({ runInstagramPass(openReelsTab) }, 1400L)
        mainHandler.postDelayed({ runInstagramPass(false) }, 2600L)
    }

    fun ensureActiveMediaUnmuted() {
        if (KillSwitchManager.isEmergencyKilled) return
        try { SystemControlManager(this).ensureMediaUnmuted() } catch (_: Exception) {}
        mainHandler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed
            val pkg = root.packageName?.toString()?.lowercase() ?: ""
            if (SecurityPolicyManager.isAppBlacklisted(pkg)) return@postDelayed
            val unmute = findNodeRecursive(root) { node ->
                val desc = node.contentDescription?.toString()?.lowercase() ?: ""
                val txt = node.text?.toString()?.lowercase() ?: ""
                node.isClickable && (
                    desc.contains("unmute") || txt.contains("unmute") ||
                        desc.contains("sound off") || desc.contains("muted") ||
                        desc.contains("tap for sound")
                )
            }
            if (unmute != null) clickNodeSecure(unmute)
        }, 700L)
    }

    // -------------------------------------------------------------
    // 4. EMERGENCY KILL-SWITCH METHOD
    // -------------------------------------------------------------

    fun killServiceInstantly() {
        Log.w(TAG, "killServiceInstantly() triggered. Calling disableSelf().")
        disableSelf()
    }
}
