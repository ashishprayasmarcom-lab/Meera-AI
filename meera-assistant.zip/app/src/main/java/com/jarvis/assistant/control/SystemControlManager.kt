package com.jarvis.assistant.control

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.SearchManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.KeyEvent

/**
 * System and Hardware Controller for Meera Complete Hands-Free Voice-Controlled Phone & Settings Assistant.
 * Works both from MainActivity and Background Service (without requiring AccessibilityService for apps, calls, settings, or search).
 */
class SystemControlManager(private val context: Context) {

    companion object {
        private const val TAG = "JarvisSystemControl"
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private fun startActivitySafely(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val accService = com.jarvis.assistant.service.VoiceAutomationService.instance
        if (accService != null) {
            try {
                accService.startActivity(intent)
                return
            } catch (_: Exception) {}
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val pi = PendingIntent.getActivity(
                    context,
                    (System.currentTimeMillis() and 0x7FFF).toInt(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                pi.send()
            } catch (_: Exception) {
                throw e
            }
        }
    }

    fun launchApp(spokenAppName: String): Boolean {
        val clean = spokenAppName.trim().lowercase()
        if (clean.isEmpty()) return false

        // Direct system screens
        if (clean.contains("setting") || clean.contains("सेटिंग")) {
            return openSettingsAction(Settings.ACTION_SETTINGS)
        }
        if (clean.contains("camera") || clean.contains("कैमरा")) {
            return try {
                startActivitySafely(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                true
            } catch (_: Exception) { false }
        }
        if (clean.contains("dialer") || clean.contains("phone") && !clean.contains("phonepe") && !clean.contains("फोनपे") || clean == "फोन") {
            return try {
                startActivitySafely(Intent(Intent.ACTION_DIAL))
                true
            } catch (_: Exception) { false }
        }

        val pm = context.packageManager
        val knownPackages = listOf(
            listOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप", "वट्सअप", "वाट्सअप") to listOf("com.whatsapp", "com.whatsapp.w4b"),
            listOf("instagram", "इंस्टाग्राम", "इंस्टा ग्राम", "इंस्टा", "insta") to listOf("com.instagram.android", "com.instagram.lite"),
            listOf("facebook", "फेसबुक", "फ़ेसबुक", "फेस बुक", "फ़ेस बुक", "fb", "एफबी") to listOf("com.facebook.katana", "com.facebook.lite"),
            listOf("paytm", "पेटीएम", "पे टी एम", "पेटियम", "पेटीम") to listOf("net.one97.paytm", "com.paytmmall"),
            listOf("phonepe", "phone pe", "फोनपे", "फ़ोनपे", "फोन पे", "फ़ोन पे") to listOf("com.phonepe.app"),
            listOf("google pay", "gpay", "g pay", "जीपे", "जी पे", "गूगल पे", "गूगलपे") to listOf("com.google.android.apps.nbu.paisa.user"),
            listOf("bhim", "भीम") to listOf("in.org.npci.upiapp"),
            listOf("cred", "क्रेड") to listOf("com.dreamplug.androidapp"),
            listOf("youtube music", "yt music", "यूट्यूब म्यूजिक") to listOf("com.google.android.apps.youtube.music"),
            listOf("youtube", "यूट्यूब", "यू ट्यूब") to listOf("com.google.android.youtube"),
            listOf("chrome", "क्रोम", "ब्राउज़र", "browser") to listOf("com.android.chrome"),
            listOf("google", "गूगल") to listOf("com.google.android.googlequicksearchbox"),
            listOf("spotify", "स्पॉटिफ़ाई", "स्पॉटिफाई") to listOf("com.spotify.music"),
            listOf("play store", "प्ले स्टोर", "प्लेस्टोर") to listOf("com.android.vending"),
            listOf("maps", "मैप्स", "मैप", "नक्शा") to listOf("com.google.android.apps.maps"),
            listOf("gmail", "जीमेल", "ईमेल", "email") to listOf("com.google.android.gm"),
            listOf("photos", "फोटो", "फ़ोटो", "गैलरी", "gallery") to listOf("com.google.android.apps.photos", "com.miui.gallery", "com.sec.android.gallery3d", "com.coloros.gallery3d", "com.vivo.gallery"),
            listOf("telegram", "टेलीग्राम") to listOf("org.telegram.messenger"),
            listOf("snapchat", "स्नैपचैट") to listOf("com.snapchat.android"),
            listOf("amazon", "अमेज़न", "अमेजन") to listOf("in.amazon.mShop.android.shopping", "com.amazon.mShop.android.shopping"),
            listOf("flipkart", "फ्लिपकार्ट", "फ़्लिपकार्ट") to listOf("com.flipkart.android"),
            listOf("meesho", "मीशो") to listOf("com.meesho.supply"),
            listOf("zomato", "ज़ोमैटो", "जोमैटो") to listOf("com.application.zomato"),
            listOf("swiggy", "स्विगी") to listOf("in.swiggy.android"),
            listOf("jiotv", "jio tv", "जियो टीवी", "जियोटीवी") to listOf("com.jio.jioplay.tv"),
            listOf("jiocinema", "jio cinema", "जियो सिनेमा") to listOf("com.jio.media.ondemand"),
            listOf("myjio", "my jio", "माई जियो", "माय जियो") to listOf("com.jio.myjio"),
            listOf("jiosaavn", "saavn", "जियो सावन", "सावन") to listOf("com.jio.media.jiobeats"),
            listOf("hotstar", "हॉटस्टार", "डिज़्नी") to listOf("in.startv.hotstar"),
            listOf("netflix", "नेटफ्लिक्स") to listOf("com.netflix.mediaclient"),
            listOf("truecaller", "ट्रूकॉलर") to listOf("com.truecaller"),
            listOf("calculator", "कैलकुलेटर") to listOf("com.google.android.calculator", "com.miui.calculator", "com.sec.android.app.popupcalculator"),
            listOf("clock", "alarm", "घड़ी") to listOf("com.google.android.deskclock", "com.android.deskclock"),
            listOf("contacts", "कॉन्टैक्ट") to listOf("com.google.android.contacts", "com.android.contacts"),
            listOf("messages", "sms", "मैसेज") to listOf("com.google.android.apps.messaging", "com.android.mms"),
            listOf("files", "फाइल", "फ़ाइल") to listOf("com.google.android.apps.nbu.files")
        )

        for ((aliases, pkgs) in knownPackages) {
            if (aliases.any { clean.contains(it) }) {
                for (pkg in pkgs) {
                    pm.getLaunchIntentForPackage(pkg)?.let { intent ->
                        startActivitySafely(intent)
                        return true
                    }
                }
            }
        }

        // Query ALL launcher activities (works reliably across MIUI, Vivo, Realme, Jio & Android 11-15)
        try {
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val activities = pm.queryIntentActivities(launcherIntent, 0)
            for (ri in activities) {
                val label = ri.loadLabel(pm).toString().lowercase()
                val pkg = ri.activityInfo.packageName
                if (label == clean || label.contains(clean) || clean.contains(label) ||
                    pkg.lowercase().contains(clean.replace(" ", ""))) {
                    val directIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                        setClassName(pkg, ri.activityInfo.name)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    }
                    startActivitySafely(directIntent)
                    return true
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "queryIntentActivities fallback error: ${e.message}")
        }

        // Last resort: Installed applications metadata scan
        return try {
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in packages) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label == clean || label.contains(clean) || clean.contains(label)) {
                    pm.getLaunchIntentForPackage(app.packageName)?.let { intent ->
                        startActivitySafely(intent)
                        return true
                    }
                }
            }
            false
        } catch (e: Exception) {
            Log.e(TAG, "launchApp error: ${e.message}")
            false
        }
    }

    fun setFlashlight(enable: Boolean): Boolean {
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList[0]

            cameraManager.setTorchMode(cameraId, enable)
            Log.d(TAG, "Flashlight set to: $enable")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle flashlight", e)
            false
        }
    }

    fun setVolume(percent: Int, stream: String = "media"): Int {
        val clamped = percent.coerceIn(0, 100)
        val audioStream = when (stream.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            "notification" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        val maxVolume = audioManager.getStreamMaxVolume(audioStream)
        val targetVolume = (clamped * maxVolume) / 100
        audioManager.setStreamVolume(
            audioStream,
            targetVolume,
            AudioManager.FLAG_SHOW_UI or AudioManager.FLAG_PLAY_SOUND
        )
        return clamped
    }

    fun adjustRelativeVolume(deltaPercent: Int, stream: String = "media"): Int {
        val audioStream = when (stream.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            "notification" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        val maxVol = audioManager.getStreamMaxVolume(audioStream).coerceAtLeast(1)
        val currentPct = (audioManager.getStreamVolume(audioStream) * 100) / maxVol
        return setVolume((currentPct + deltaPercent).coerceIn(0, 100), stream)
    }

    private fun promptWriteSettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
            }
            startActivitySafely(intent)
            true
        } catch (_: Exception) {
            openSettingsAction(Settings.ACTION_DISPLAY_SETTINGS)
        }
    }

    fun setBrightness(percent: Int): Boolean {
        if (!Settings.System.canWrite(context)) {
            Log.w(TAG, "WRITE_SETTINGS permission not granted — opening grant page")
            promptWriteSettings()
            return false
        }
        val clamped = percent.coerceIn(5, 100)
        val brightnessValue = (clamped * 255) / 100

        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                brightnessValue
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write screen brightness", e)
            false
        }
    }

    fun setBrightnessAuto(): Boolean {
        if (!Settings.System.canWrite(context)) {
            promptWriteSettings()
            return false
        }
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enable auto brightness", e)
            false
        }
    }

    @Suppress("DEPRECATION")
    fun setWifi(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                wifiManager.isWifiEnabled = enable
                true
            } else {
                startActivitySafely(Intent(Settings.Panel.ACTION_WIFI))
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Wi-Fi", e)
            openSettingsAction(Settings.ACTION_WIFI_SETTINGS)
        }
    }

    @Suppress("DEPRECATION")
    fun setBluetooth(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (enable) {
                    openSettingsAction(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                } else {
                    openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS)
                }
            } else {
                val adapter = BluetoothAdapter.getDefaultAdapter() ?: return openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS)
                val ok = if (enable) adapter.enable() else adapter.disable()
                if (!ok) openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS) else true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Bluetooth", e)
            openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
    }

    fun setDnd(enable: Boolean): Boolean {
        return try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(
                    if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                    else NotificationManager.INTERRUPTION_FILTER_ALL
                )
                true
            } else {
                openSettingsAction(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle DND", e)
            false
        }
    }

    fun setAutoRotate(enable: Boolean): Boolean {
        if (!Settings.System.canWrite(context)) {
            promptWriteSettings()
            return false
        }
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.ACCELEROMETER_ROTATION,
                if (enable) 1 else 0
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Auto-Rotate", e)
            false
        }
    }

    fun openSettingsAction(action: String): Boolean {
        return try {
            startActivitySafely(Intent(action))
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open settings action: $action", e)
            false
        }
    }

    fun openMobileDataSettings(): Boolean = openSettingsAction(Settings.ACTION_DATA_ROAMING_SETTINGS)
    fun openHotspotSettings(): Boolean = openSettingsAction(Settings.ACTION_WIRELESS_SETTINGS)
    fun openLocationSettings(): Boolean = openSettingsAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
    fun openAirplaneModeSettings(): Boolean = openSettingsAction(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
    fun openBatterySaverSettings(): Boolean = openSettingsAction(Settings.ACTION_BATTERY_SAVER_SETTINGS)

    /**
     * Scans & auto-repairs misconfigured settings (DND, low Media/Ring volume, dim brightness, Wi-Fi connectivity).
     */
    fun fixBrokenSettings(): List<String> {
        val repaired = mutableListOf<String>()

        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted &&
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
            ) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                repaired.add("Do Not Disturb -> OFF")
            }
        } catch (_: Exception) {}

        val mediaMax = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val mediaPct = (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) / mediaMax
        if (mediaPct < 30) {
            setVolume(75, "media")
            repaired.add("Media Volume -> 75%")
        }

        val ringMax = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING).coerceAtLeast(1)
        val ringPct = (audioManager.getStreamVolume(AudioManager.STREAM_RING) * 100) / ringMax
        if (ringPct < 30) {
            setVolume(80, "ring")
            repaired.add("Ring Volume -> 80%")
        }

        if (Settings.System.canWrite(context)) {
            val curBright = try {
                Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            } catch (_: Exception) {
                180
            }
            if (curBright < 55) {
                setBrightness(70)
                repaired.add("Brightness -> 70%")
            }
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && !wifiManager.isWifiEnabled) {
            wifiManager.isWifiEnabled = true
            repaired.add("Wi-Fi -> ON")
        }

        if (repaired.isEmpty()) {
            setVolume(75, "media")
            if (Settings.System.canWrite(context)) setBrightness(70)
            repaired.add("Audio & Display Profiles -> Verified & Optimized")
        }

        return repaired
    }

    fun openAppSettingsFix(appName: String): Boolean {
        val lower = appName.lowercase()
        val pkg = when {
            lower.contains("whatsapp") || lower.contains("व्हाट्स") || lower.contains("वॉट्स") -> "com.whatsapp"
            lower.contains("insta") || lower.contains("इंस्टा") -> "com.instagram.android"
            lower.contains("face") || lower.contains("फेसबुक") || lower.contains("फ़ेसबुक") -> "com.facebook.katana"
            lower.contains("youtube") || lower.contains("यूट्यूब") -> "com.google.android.youtube"
            lower.contains("chrome") || lower.contains("क्रोम") -> "com.android.chrome"
            lower.contains("spotify") -> "com.spotify.music"
            lower.contains("gmail") || lower.contains("जीमेल") -> "com.google.android.gm"
            else -> context.packageName
        }
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", pkg, null)
            }
            startActivitySafely(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open app settings for $pkg", e)
            openSettingsAction(Settings.ACTION_APPLICATION_SETTINGS)
        }
    }

    fun openSettingsSection(section: String): Boolean {
        val action = when (section.lowercase()) {
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "datetime" -> Settings.ACTION_DATE_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            else -> Settings.ACTION_WIRELESS_SETTINGS
        }
        return openSettingsAction(action)
    }

    fun findMatchingContacts(nameQuery: String): List<Pair<String, String>> {
        val clean = nameQuery.trim().lowercase()
        if (clean.length < 2) return emptyList()
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return emptyList()
        }
        val results = mutableListOf<Pair<String, String>>()
        val seenDigits = hashSetOf<String>()
        try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )
            cursor?.use { c ->
                while (c.moveToNext()) {
                    val displayName = c.getString(0)?.trim() ?: continue
                    val number = c.getString(1)?.trim() ?: continue
                    val nameLower = displayName.lowercase()
                    if (nameLower.contains(clean) || clean.contains(nameLower)) {
                        val digits = number.filter { it.isDigit() }.takeLast(10)
                        if (digits.isNotEmpty() && seenDigits.add(digits)) {
                            results.add(displayName to number)
                            if (results.size >= 5) break
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Contacts multi-match lookup failed: ${e.message}")
        }
        return results
    }

    fun resolveContactPhone(nameOrNumber: String): String? {
        val digitsOnly = nameOrNumber.filter { it.isDigit() || it == '+' }
        if (digitsOnly.length >= 3) return digitsOnly
        return findMatchingContacts(nameOrNumber).firstOrNull()?.second
    }

    fun makeCall(target: String): Boolean {
        return try {
            val resolved = resolveContactPhone(target)
            if (resolved != null) {
                val hasCallPerm = context.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                val action = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
                val intent = Intent(action, Uri.parse("tel:${Uri.encode(resolved)}"))
                startActivitySafely(intent)
                true
            } else {
                // Open dialer so user can pick contact if contact name didn't match or permission pending
                startActivitySafely(Intent(Intent.ACTION_DIAL))
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Call failed: ${e.message}")
            false
        }
    }

    fun openWhatsAppDirect(contactOrNumber: String, message: String? = null): Boolean {
        val resolved = resolveContactPhone(contactOrNumber)?.filter { it.isDigit() }
        val waPkg = listOf("com.whatsapp", "com.whatsapp.w4b").firstOrNull {
            context.packageManager.getLaunchIntentForPackage(it) != null
        }
        return try {
            if (!resolved.isNullOrEmpty() && resolved.length >= 7) {
                val cleanNum = if (resolved.length == 10) "91$resolved" else resolved
                val url = if (!message.isNullOrBlank()) {
                    "https://api.whatsapp.com/send?phone=$cleanNum&text=${Uri.encode(message)}"
                } else {
                    "https://api.whatsapp.com/send?phone=$cleanNum"
                }
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    if (waPkg != null) setPackage(waPkg)
                }
                startActivitySafely(intent)
                true
            } else {
                launchApp("whatsapp")
            }
        } catch (_: Exception) {
            launchApp("whatsapp")
        }
    }

    fun ensureMediaUnmuted() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            } else {
                @Suppress("DEPRECATION")
                audioManager.setStreamMute(AudioManager.STREAM_MUSIC, false)
            }
            val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (curVol == 0 || (curVol * 100) / maxVol < 45) {
                val targetVol = ((65 * maxVol) / 100).coerceAtLeast(1)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
            }
        } catch (e: Exception) {
            Log.w(TAG, "ensureMediaUnmuted note: ${e.message}")
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String = "Meera Alarm"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            }
            startActivitySafely(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Set alarm failed: ${e.message}")
            false
        }
    }

    fun setReminder(title: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, title)
                putExtra(AlarmClock.EXTRA_LENGTH, 1800)
            }
            startActivitySafely(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Set reminder failed: ${e.message}")
            false
        }
    }

    fun openYouTubeSearch(query: String): Boolean {
        ensureMediaUnmuted()
        return openUrl("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
    }

    fun openSpotifySearch(query: String): Boolean {
        ensureMediaUnmuted()
        return openUrl("https://open.spotify.com/search/${Uri.encode(query)}")
    }

    /**
     * Tries Android's MEDIA_PLAY_FROM_SEARCH for instant playback in YouTube / Spotify,
     * falling back to YouTube search results (paired with Accessibility auto-tap + auto-unmute).
     */
    fun playMediaOnYouTubeOrMusic(query: String, preferSpotify: Boolean = false): String {
        ensureMediaUnmuted()
        val cleanQuery = query.ifBlank { "latest hindi hit songs" }
        val targetPkg = if (preferSpotify) "com.spotify.music" else "com.google.android.youtube"
        try {
            val mediaIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                putExtra(SearchManager.QUERY, cleanQuery)
                if (context.packageManager.getLaunchIntentForPackage(targetPkg) != null) {
                    setPackage(targetPkg)
                }
            }
            startActivitySafely(mediaIntent)
            return "MEDIA_INTENT"
        } catch (_: Exception) {}

        return if (preferSpotify) {
            openSpotifySearch(cleanQuery)
            "SPOTIFY_SEARCH"
        } else {
            openYouTubeSearch(cleanQuery)
            "YOUTUBE_SEARCH"
        }
    }

    fun sendMediaPlayPause(): Boolean {
        return try {
            val now = android.os.SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openWebSearch(query: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
            }
            startActivitySafely(intent)
            true
        } catch (e: Exception) {
            openUrl("https://www.google.com/search?q=${Uri.encode(query)}")
        }
    }

    fun openUrl(url: String): Boolean {
        return try {
            startActivitySafely(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getBatteryLevel(): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }
}
