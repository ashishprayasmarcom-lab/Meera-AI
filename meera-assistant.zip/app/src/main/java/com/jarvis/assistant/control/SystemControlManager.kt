package com.jarvis.assistant.control

import android.Manifest
import android.app.NotificationManager
import android.app.SearchManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import com.jarvis.assistant.security.SecurityPolicyManager

/**
 * System and Hardware Controller for Meera Complete Hands-Free Voice-Controlled Phone & Settings Assistant.
 * Works both from MainActivity and Background Service (without requiring AccessibilityService for apps, calls, settings, or search).
 */
class SystemControlManager(private val context: Context) {

    companion object {
        private const val TAG = "JarvisSystemControl"
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    fun launchApp(spokenAppName: String): Boolean {
        val clean = spokenAppName.trim().lowercase()
        if (clean.isEmpty()) return false

        // Direct system screens
        if (clean.contains("setting") || clean.contains("सेटिंग")) {
            return openSettingsAction(Settings.ACTION_SETTINGS)
        }
        if (clean.contains("camera") || clean.contains("कैमरा")) {
            return try {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            } catch (_: Exception) { false }
        }
        if (clean.contains("dialer") || clean.contains("phone") || clean.contains("फोन")) {
            return try {
                val intent = Intent(Intent.ACTION_DIAL).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(intent)
                true
            } catch (_: Exception) { false }
        }

        val pm = context.packageManager
        val knownPackages = listOf(
            listOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "वाट्सएप") to "com.whatsapp",
            listOf("instagram", "इंस्टाग्राम", "इंस्टा", "insta") to "com.instagram.android",
            listOf("facebook", "फेसबुक", "फ़ेसबुक", "fb") to "com.facebook.katana",
            listOf("youtube", "यूट्यूब") to "com.google.android.youtube",
            listOf("chrome", "क्रोम") to "com.android.chrome",
            listOf("google", "गूगल") to "com.google.android.googlequicksearchbox",
            listOf("spotify", "स्पॉटिफ़ाई") to "com.spotify.music",
            listOf("play store", "प्ले स्टोर") to "com.android.vending",
            listOf("maps", "मैप्स", "नक्शा") to "com.google.android.apps.maps",
            listOf("gmail", "जीमेल") to "com.google.android.gm",
            listOf("photos", "गैलरी", "gallery") to "com.google.android.apps.photos",
            listOf("telegram", "टेलीग्राम") to "org.telegram.messenger",
            listOf("snapchat", "स्नैपचैट") to "com.snapchat.android"
        )

        for ((aliases, pkg) in knownPackages) {
            if (aliases.any { clean.contains(it) }) {
                if (SecurityPolicyManager.isAppBlacklisted(pkg)) return false
                pm.getLaunchIntentForPackage(pkg)?.let { intent ->
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    return true
                }
            }
        }

        // Fallback: Fuzzy match ALL installed launchable apps
        return try {
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (app in packages) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label == clean || label.contains(clean) || clean.contains(label)) {
                    if (SecurityPolicyManager.isAppBlacklisted(app.packageName)) return false
                    pm.getLaunchIntentForPackage(app.packageName)?.let { intent ->
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        return true
                    }
                }
            }
            false
        } catch (e: Exception) {
            Log.e(TAG, "launchApp error: ${e.message}")
            false
        }
    }

    fun setFlashlight(enable: Boolean): Boolean {
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                chars.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList[0]

            cameraManager.setTorchMode(cameraId, enable)
            Log.d(TAG, "Flashlight set to: $enable")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle flashlight", e)
            false
        }
    }

    fun setVolume(percent: Int, stream: String = "media"): Int {
        val clamped = percent.coerceIn(0, 100)
        val audioStream = when (stream.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            "notification" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        val maxVolume = audioManager.getStreamMaxVolume(audioStream)
        val targetVolume = (clamped * maxVolume) / 100
        audioManager.setStreamVolume(
            audioStream,
            targetVolume,
            AudioManager.FLAG_SHOW_UI or AudioManager.FLAG_PLAY_SOUND
        )
        return clamped
    }

    fun adjustRelativeVolume(deltaPercent: Int, stream: String = "media"): Int {
        val audioStream = when (stream.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            "call" -> AudioManager.STREAM_VOICE_CALL
            "notification" -> AudioManager.STREAM_NOTIFICATION
            else -> AudioManager.STREAM_MUSIC
        }
        val maxVol = audioManager.getStreamMaxVolume(audioStream).coerceAtLeast(1)
        val currentPct = (audioManager.getStreamVolume(audioStream) * 100) / maxVol
        return setVolume((currentPct + deltaPercent).coerceIn(0, 100), stream)
    }

    private fun promptWriteSettings(): Boolean {
        return try {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (_: Exception) {
            openSettingsAction(Settings.ACTION_DISPLAY_SETTINGS)
        }
    }

    fun setBrightness(percent: Int): Boolean {
        if (!Settings.System.canWrite(context)) {
            Log.w(TAG, "WRITE_SETTINGS permission not granted — opening grant page")
            promptWriteSettings()
            return false
        }
        val clamped = percent.coerceIn(5, 100)
        val brightnessValue = (clamped * 255) / 100

        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS,
                brightnessValue
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write screen brightness", e)
            false
        }
    }

    fun setBrightnessAuto(): Boolean {
        if (!Settings.System.canWrite(context)) {
            promptWriteSettings()
            return false
        }
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.SCREEN_BRIGHTNESS_MODE,
                Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to enable auto brightness", e)
            false
        }
    }

    @Suppress("DEPRECATION")
    fun setWifi(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                wifiManager.isWifiEnabled = enable
                true
            } else {
                val panelIntent = Intent(Settings.Panel.ACTION_WIFI).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(panelIntent)
                true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Wi-Fi", e)
            openSettingsAction(Settings.ACTION_WIFI_SETTINGS)
        }
    }

    @Suppress("DEPRECATION")
    fun setBluetooth(enable: Boolean): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (enable) {
                    openSettingsAction(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                } else {
                    openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS)
                }
            } else {
                val adapter = BluetoothAdapter.getDefaultAdapter() ?: return openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS)
                val ok = if (enable) adapter.enable() else adapter.disable()
                if (!ok) openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS) else true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Bluetooth", e)
            openSettingsAction(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
    }

    fun setDnd(enable: Boolean): Boolean {
        return try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(
                    if (enable) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                    else NotificationManager.INTERRUPTION_FILTER_ALL
                )
                true
            } else {
                openSettingsAction(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle DND", e)
            false
        }
    }

    fun setAutoRotate(enable: Boolean): Boolean {
        if (!Settings.System.canWrite(context)) {
            promptWriteSettings()
            return false
        }
        return try {
            Settings.System.putInt(
                context.contentResolver,
                Settings.System.ACCELEROMETER_ROTATION,
                if (enable) 1 else 0
            )
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to toggle Auto-Rotate", e)
            false
        }
    }

    fun openSettingsAction(action: String): Boolean {
        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open settings action: $action", e)
            false
        }
    }

    fun openMobileDataSettings(): Boolean = openSettingsAction(Settings.ACTION_DATA_ROAMING_SETTINGS)
    fun openHotspotSettings(): Boolean = openSettingsAction(Settings.ACTION_WIRELESS_SETTINGS)
    fun openLocationSettings(): Boolean = openSettingsAction(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
    fun openAirplaneModeSettings(): Boolean = openSettingsAction(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
    fun openBatterySaverSettings(): Boolean = openSettingsAction(Settings.ACTION_BATTERY_SAVER_SETTINGS)

    /**
     * Scans & auto-repairs misconfigured settings (DND, low Media/Ring volume, dim brightness, Wi-Fi connectivity).
     */
    fun fixBrokenSettings(): List<String> {
        val repaired = mutableListOf<String>()

        try {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.isNotificationPolicyAccessGranted &&
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL
            ) {
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                repaired.add("Do Not Disturb -> OFF")
            }
        } catch (_: Exception) {}

        val mediaMax = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val mediaPct = (audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) / mediaMax
        if (mediaPct < 30) {
            setVolume(75, "media")
            repaired.add("Media Volume -> 75%")
        }

        val ringMax = audioManager.getStreamMaxVolume(AudioManager.STREAM_RING).coerceAtLeast(1)
        val ringPct = (audioManager.getStreamVolume(AudioManager.STREAM_RING) * 100) / ringMax
        if (ringPct < 30) {
            setVolume(80, "ring")
            repaired.add("Ring Volume -> 80%")
        }

        if (Settings.System.canWrite(context)) {
            val curBright = try {
                Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS)
            } catch (_: Exception) {
                180
            }
            if (curBright < 55) {
                setBrightness(70)
                repaired.add("Brightness -> 70%")
            }
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && !wifiManager.isWifiEnabled) {
            wifiManager.isWifiEnabled = true
            repaired.add("Wi-Fi -> ON")
        }

        if (repaired.isEmpty()) {
            setVolume(75, "media")
            if (Settings.System.canWrite(context)) setBrightness(70)
            repaired.add("Audio & Display Profiles -> Verified & Optimized")
        }

        return repaired
    }

    fun openAppSettingsFix(appName: String): Boolean {
        val lower = appName.lowercase()
        val pkg = when {
            lower.contains("whatsapp") || lower.contains("व्हाट्स") || lower.contains("वॉट्स") -> "com.whatsapp"
            lower.contains("insta") || lower.contains("इंस्टा") -> "com.instagram.android"
            lower.contains("face") || lower.contains("फेसबुक") || lower.contains("फ़ेसबुक") -> "com.facebook.katana"
            lower.contains("youtube") || lower.contains("यूट्यूब") -> "com.google.android.youtube"
            lower.contains("chrome") || lower.contains("क्रोम") -> "com.android.chrome"
            lower.contains("spotify") -> "com.spotify.music"
            lower.contains("gmail") || lower.contains("जीमेल") -> "com.google.android.gm"
            else -> context.packageName
        }
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", pkg, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to open app settings for $pkg", e)
            openSettingsAction(Settings.ACTION_APPLICATION_SETTINGS)
        }
    }

    fun openSettingsSection(section: String): Boolean {
        val action = when (section.lowercase()) {
            "language" -> Settings.ACTION_LOCALE_SETTINGS
            "datetime" -> Settings.ACTION_DATE_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            else -> Settings.ACTION_WIRELESS_SETTINGS
        }
        return openSettingsAction(action)
    }

    fun resolveContactPhone(nameOrNumber: String): String? {
        val digitsOnly = nameOrNumber.filter { it.isDigit() || it == '+' }
        if (digitsOnly.length >= 3) return digitsOnly

        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return null
        }

        return try {
            val cursor = context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ),
                null,
                null,
                null
            )
            cursor?.use { c ->
                val targetLower = nameOrNumber.trim().lowercase()
                while (c.moveToNext()) {
                    val name = c.getString(0)?.lowercase() ?: ""
                    val num = c.getString(1) ?: ""
                    if (name.contains(targetLower) || targetLower.contains(name)) {
                        return num
                    }
                }
            }
            null
        } catch (e: Exception) {
            Log.w(TAG, "Contacts lookup failed: ${e.message}")
            null
        }
    }

    fun makeCall(target: String): Boolean {
        return try {
            val resolved = resolveContactPhone(target)
            if (resolved != null) {
                val hasCallPerm = context.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
                val action = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
                val intent = Intent(action, Uri.parse("tel:${Uri.encode(resolved)}")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                true
            } else {
                // Open dialer so user can pick contact if contact name didn't match or permission pending
                val intent = Intent(Intent.ACTION_DIAL).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Call failed: ${e.message}")
            false
        }
    }

    fun openWhatsAppDirect(contactOrNumber: String, message: String? = null): Boolean {
        val resolved = resolveContactPhone(contactOrNumber)?.filter { it.isDigit() || it == '+' }
        return try {
            if (!resolved.isNullOrEmpty()) {
                val cleanNum = resolved.removePrefix("+")
                val url = if (!message.isNullOrBlank()) {
                    "https://api.whatsapp.com/send?phone=$cleanNum&text=${Uri.encode(message)}"
                } else {
                    "https://api.whatsapp.com/send?phone=$cleanNum"
                }
                openUrl(url)
            } else {
                launchApp("whatsapp")
            }
        } catch (_: Exception) {
            launchApp("whatsapp")
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String = "Meera Alarm"): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                putExtra(AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(AlarmClock.EXTRA_MESSAGE, label)
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Set alarm failed: ${e.message}")
            false
        }
    }

    fun setReminder(title: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, title)
                putExtra(AlarmClock.EXTRA_LENGTH, 1800)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Set reminder failed: ${e.message}")
            false
        }
    }

    fun openYouTubeSearch(query: String): Boolean {
        return openUrl("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
    }

    fun openSpotifySearch(query: String): Boolean {
        return openUrl("https://open.spotify.com/search/${Uri.encode(query)}")
    }

    fun openWebSearch(query: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                putExtra(SearchManager.QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            openUrl("https://www.google.com/search?q=${Uri.encode(query)}")
        }
    }

    fun openUrl(url: String): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getBatteryLevel(): Int {
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }
}
