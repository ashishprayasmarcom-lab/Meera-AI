package com.jarvis.assistant.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Path
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import com.jarvis.assistant.security.SecurityPolicyManager

enum class SemanticRole {
    SEARCH_INPUT,
    SEARCH_BUTTON,
    SEND_BUTTON,
    LIKE_BUTTON,
    SCROLLABLE_CONTAINER,
    PLAY_PAUSE_BUTTON
}

/**
 * Universal App & Gesture Controller for Android.
 * Autonomously controls ANY installed app on the smartphone:
 * 1. Dynamic Package Resolution: Maps spoken name ("Spotify", "Instagram", "Reddit") to package.
 * 2. Semantic UI Discovery: Finds search bars, buttons, and text fields in ANY arbitrary app.
 * 3. Universal Gesture Engine: Swipes, scrolls, taps, and double-taps anywhere on screen.
 * 4. Global System Navigation: Home, Back, Recents, Notifications, and Screenshots.
 * 5. App Lifecycle: Dynamic launch and uninstallation prompts.
 */
class UniversalAppController(
    private val service: AccessibilityService,
    private val screenWidth: Int = 1080,
    private val screenHeight: Int = 2400
) {

    companion object {
        private const val TAG = "JarvisUniversal"
    }

    // -------------------------------------------------------------
    // 1. DYNAMIC UNIVERSAL APP RESOLUTION & LAUNCH
    // -------------------------------------------------------------

    /**
     * Finds and launches ANY installed app by spoken name (e.g., "Spotify", "Netflix", "Zomato").
     * Uses PackageManager to fuzzy-match installed application labels.
     */
    fun launchAppByVoice(context: Context, spokenAppName: String): Boolean {
        val pm = context.packageManager
        val cleanName = spokenAppName.trim().lowercase()

        // 1. Check all launcher activities via Intent query (most reliable on modern OEM Android ROMs)
        try {
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val activities = pm.queryIntentActivities(launcherIntent, 0)
            for (ri in activities) {
                val label = ri.loadLabel(pm).toString().lowercase()
                val pkg = ri.activityInfo.packageName
                if (label == cleanName || label.contains(cleanName) || cleanName.contains(label) ||
                    pkg.lowercase().contains(cleanName.replace(" ", ""))) {
                    val launch = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_LAUNCHER)
                        setClassName(pkg, ri.activityInfo.name)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    }
                    context.startActivity(launch)
                    Log.i(TAG, "Universally launched '$pkg' via launcher activity for '$spokenAppName'")
                    return true
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Launcher query fallback error: ${e.message}")
        }

        // 2. Fallback: Installed applications list
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (app in packages) {
            val label = pm.getApplicationLabel(app).toString().lowercase()
            if (label == cleanName || label.contains(cleanName) || cleanName.contains(label)) {
                val intent = pm.getLaunchIntentForPackage(app.packageName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent != null) {
                    context.startActivity(intent)
                    Log.i(TAG, "Universally launched '${app.packageName}' for voice command '$spokenAppName'")
                    return true
                }
            }
        }

        Log.w(TAG, "No installed app matched voice name: '$spokenAppName'")
        return false
    }

    /**
     * Prompts system uninstallation dialog for specified app
     */
    fun promptUninstallApp(context: Context, appName: String): Boolean {
        val pm = context.packageManager
        val cleanName = appName.trim().lowercase()
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val target = packages.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(cleanName)
        } ?: return false

        val uninstallIntent = Intent(Intent.ACTION_DELETE).apply {
            data = Uri.parse("package:${target.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(uninstallIntent)
        return true
    }

    // -------------------------------------------------------------
    // 2. DYNAMIC SEMANTIC UI DISCOVERY IN ARBITRARY APPS
    // -------------------------------------------------------------

    /**
     * Crawls active window tree to discover nodes by their semantic role in ANY app.
     */
    fun findNodeBySemanticRole(root: AccessibilityNodeInfo?, role: SemanticRole): AccessibilityNodeInfo? {
        if (root == null) return null

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val text = (node.text?.toString() ?: "").lowercase()
            val desc = (node.contentDescription?.toString() ?: "").lowercase()
            val idRes = (node.viewIdResourceName ?: "").lowercase()
            val className = (node.className?.toString() ?: "").lowercase()

            val isMatch = when (role) {
                SemanticRole.SEARCH_INPUT -> {
                    className.contains("edittext") &&
                    (text.contains("search") || desc.contains("search") || idRes.contains("search") ||
                     text.contains("find") || desc.contains("find") || text.isEmpty())
                }
                SemanticRole.SEARCH_BUTTON -> {
                    node.isClickable &&
                    (desc.contains("search") || idRes.contains("search") || text.contains("search") ||
                     desc.contains("magnify") || idRes.contains("magnify"))
                }
                SemanticRole.SEND_BUTTON -> {
                    node.isClickable &&
                    (desc.contains("send") || idRes.contains("send") || text.contains("send") ||
                     desc.contains("submit") || idRes.contains("submit"))
                }
                SemanticRole.LIKE_BUTTON -> {
                    node.isClickable &&
                    (desc.contains("like") || idRes.contains("like") || desc.contains("heart") ||
                     idRes.contains("heart") || text.contains("like"))
                }
                SemanticRole.SCROLLABLE_CONTAINER -> {
                    node.isScrollable || className.contains("scrollview") ||
                    className.contains("recyclerview") || className.contains("listview")
                }
                SemanticRole.PLAY_PAUSE_BUTTON -> {
                    node.isClickable &&
                    (desc.contains("play") || desc.contains("pause") || idRes.contains("play") ||
                     idRes.contains("pause"))
                }
            }

            if (isMatch) return node

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return null
    }

    // -------------------------------------------------------------
    // 3. UNIVERSAL GESTURE ENGINE (DISPATCH GESTURES IN ANY APP)
    // -------------------------------------------------------------

    /**
     * Performs a vertical scroll in any active app.
     */
    fun scroll(down: Boolean = true, durationMs: Long = 320L, onComplete: (() -> Unit)? = null) {
        val centerX = screenWidth / 2f
        val startY = if (down) screenHeight * 0.70f else screenHeight * 0.30f
        val endY = if (down) screenHeight * 0.30f else screenHeight * 0.70f

        val path = Path().apply {
            moveTo(centerX, startY)
            lineTo(centerX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke()
            }
        }, null)
    }

    /**
     * Universal Double Tap (e.g. to like an Instagram post, YouTube video, or zoom)
     */
    fun doubleTap(x: Float = screenWidth / 2f, y: Float = screenHeight / 2f, onComplete: (() -> Unit)? = null) {
        val path1 = Path().apply { moveTo(x, y) }
        val stroke1 = GestureDescription.StrokeDescription(path1, 0L, 50L)

        val path2 = Path().apply { moveTo(x, y) }
        val stroke2 = GestureDescription.StrokeDescription(path2, 100L, 50L)

        val gesture = GestureDescription.Builder()
            .addStroke(stroke1)
            .addStroke(stroke2)
            .build()

        service.dispatchGesture(gesture, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke()
            }
        }, null)
    }

    // -------------------------------------------------------------
    // 4. GLOBAL SYSTEM ACTIONS (ANY SCREEN)
    // -------------------------------------------------------------

    fun goBack(): Boolean = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    fun goHome(): Boolean = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
    fun openRecents(): Boolean = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
    fun openNotifications(): Boolean = service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
    fun takeScreenshot(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT)
        } else {
            false
        }
    }
}
